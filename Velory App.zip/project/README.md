# Velory - Complete Payment Integration

This project now includes a comprehensive payment system supporting multiple payment providers with a focus on India and global markets.

## Features

### 🔐 Authentication
- Email/password authentication
- User profiles with avatars
- Protected routes

### 📋 Task Management
- Create, read, update, delete tasks
- Task completion tracking
- Importance and deadline management
- Automatic task statistics

### 😊 Mood Tracking
- Daily mood entries
- Calendar view integration
- Mood history and analytics

### ✍️ Writeups System
- Multiple writeup types (journal, creative, thoughts, gratitude, goals, autobiography)
- Rich text editing with TipTap
- Tag-based organization
- Search functionality

### 📺 Media Tracking
- Track books and TV shows
- Progress monitoring
- Status management (pending, ongoing, completed)
- Genre categorization

### 🏆 Achievements
- Custom user achievements
- Icon and description support
- Achievement management

### 💳 Payment System
- **Multiple Payment Providers**: Razorpay, Stripe, PayPal, PhonePe, Paytm, Cashfree
- **Global Coverage**: Support for 40+ countries and 15+ currencies
- **India-Focused**: Optimized for Indian payment methods (UPI, Net Banking, Wallets)
- **Smart Routing**: Automatic provider selection based on user location
- **Secure Processing**: Industry-standard security and encryption

## Payment Providers

### For India 🇮🇳
- **Razorpay**: Cards, UPI, Net Banking, Wallets, EMI
- **PhonePe**: UPI, Wallet, Cards
- **Paytm**: Wallet, UPI, Cards, Net Banking
- **Cashfree**: UPI, Cards, Net Banking, Wallets

### For Global Markets 🌍
- **Stripe**: Cards, Apple Pay, Google Pay, Link (40+ countries)
- **PayPal**: PayPal Wallet, PayPal Credit (200+ countries)

## Supported Payment Methods

### 🇮🇳 India
- **UPI** (Unified Payments Interface) - Most popular
- **Credit/Debit Cards** (Visa, Mastercard, RuPay)
- **Net Banking** (All major banks)
- **Digital Wallets** (Paytm, PhonePe, Google Pay, etc.)
- **EMI** (Equated Monthly Installments)

### 🌍 Global
- **Credit/Debit Cards** (Visa, Mastercard, Amex)
- **Digital Wallets** (Apple Pay, Google Pay, PayPal)
- **Buy Now Pay Later** (PayPal Credit)

## Supported Countries & Currencies

### Countries (40+)
India, United States, United Kingdom, Canada, Australia, Germany, France, Italy, Spain, Netherlands, Belgium, Austria, Switzerland, Sweden, Norway, Denmark, Finland, Ireland, Portugal, Luxembourg, Greece, Cyprus, Malta, Slovenia, Slovakia, Estonia, Latvia, Lithuania, Poland, Czech Republic, Hungary, Romania, Bulgaria, Croatia, Japan, Singapore, Hong Kong, Malaysia, Thailand, Philippines, Indonesia, UAE, Saudi Arabia, Brazil, Mexico, Argentina, Chile, Colombia, Peru, Uruguay

### Currencies (15+)
INR, USD, EUR, GBP, CAD, AUD, JPY, SGD, HKD, MYR, AED, SAR, BRL, MXN, ARS, CLP, COP, PEN, UYU

## Database Schema

The backend uses Supabase with the following main tables:

- **profiles** - User profile information
- **tasks** - Task management with deadlines and completion tracking
- **mood_entries** - Daily mood tracking
- **writeups** - All writing content with type categorization
- **trackers** - Custom media trackers
- **media_items** - Individual media items with progress tracking
- **achievements** - User achievements
- **subscription_plans** - Available subscription plans
- **user_subscriptions** - User subscription status
- **subscription_usage** - Usage tracking and limits
- **coupon_codes** - Discount and promotional codes

## Setup Instructions

### 1. Create a Supabase Project
- Go to [supabase.com](https://supabase.com)
- Create a new project
- Note your project URL and anon key

### 2. Configure Environment Variables
```bash
cp .env.example .env
# Edit .env with your credentials
```

### 3. Payment Provider Setup

#### Razorpay (India)
1. Sign up at [razorpay.com](https://razorpay.com)
2. Get your Key ID and Key Secret from the dashboard
3. Add to `.env` file

#### Stripe (Global)
1. Sign up at [stripe.com](https://stripe.com)
2. Get your publishable and secret keys
3. Add to `.env` file

#### PayPal (Global)
1. Sign up at [developer.paypal.com](https://developer.paypal.com)
2. Create an app and get client ID and secret
3. Add to `.env` file

#### PhonePe (India)
1. Contact PhonePe for merchant onboarding
2. Get merchant ID and salt key
3. Add to `.env` file

#### Paytm (India)
1. Sign up at [business.paytm.com](https://business.paytm.com)
2. Get merchant ID and key
3. Add to `.env` file

#### Cashfree (India)
1. Sign up at [cashfree.com](https://cashfree.com)
2. Get app ID and secret key
3. Add to `.env` file

### 4. Run Database Migrations
- The migration files in `supabase/migrations/` will set up your database schema
- Run them in order through the Supabase dashboard or CLI

### 5. Enable Authentication
- In Supabase dashboard, go to Authentication > Settings
- Configure email authentication
- Disable email confirmation for development (optional)

### 6. Set up Storage (Optional)
- Create a storage bucket named "avatars" for profile pictures
- Configure appropriate policies for authenticated users

## Payment Flow

1. **User selects a plan** on the subscription page
2. **Location detection** determines available payment methods
3. **Payment method selection** shows relevant options for the user's country
4. **Provider routing** automatically selects the best payment provider
5. **Secure processing** handles the payment through the chosen provider
6. **Subscription activation** updates the user's plan upon successful payment

## Security Features

- **PCI DSS Compliance** through certified payment providers
- **Tokenization** of sensitive payment data
- **3D Secure** authentication for card payments
- **Fraud detection** and prevention
- **Encrypted data transmission** (TLS 1.2+)
- **No storage** of payment credentials on our servers

## API Structure

The payment system is organized into modules:

- `PaymentManager` - Main orchestrator for payment operations
- `PaymentProviders` - Individual provider implementations
- `PaymentMethodSelector` - UI component for method selection
- `PaymentDialog` - Secure payment processing interface

## Development

```bash
npm install
npm run dev
```

The app will automatically handle authentication, subscription management, and payment processing.

## Testing

### Test Cards (Sandbox Mode)

#### Razorpay
- **Success**: 4111 1111 1111 1111
- **Failure**: 4000 0000 0000 0002

#### Stripe
- **Success**: 4242 4242 4242 4242
- **3D Secure**: 4000 0000 0000 3220

#### PayPal
- Use PayPal sandbox accounts for testing

### Test UPI IDs (India)
- **Success**: success@razorpay
- **Failure**: failure@razorpay

## Production Deployment

1. **Switch to production mode** in environment variables
2. **Update payment provider credentials** to live keys
3. **Configure webhooks** for payment status updates
4. **Set up monitoring** for payment failures and fraud detection
5. **Implement proper logging** for audit trails

## Support

For payment-related issues:
- Check provider documentation
- Review transaction logs
- Contact provider support for payment failures
- Monitor webhook deliveries

## Compliance

This payment system is designed to comply with:
- **PCI DSS** (Payment Card Industry Data Security Standard)
- **RBI Guidelines** (Reserve Bank of India) for Indian payments
- **GDPR** (General Data Protection Regulation) for EU users
- **PSD2** (Payment Services Directive 2) for European payments

## License

This project is licensed under the MIT License.