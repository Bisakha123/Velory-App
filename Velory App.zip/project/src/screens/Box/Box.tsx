import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Crown, X, Heart } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { Checkbox } from "../../components/ui/checkbox";
import { format, isBefore, isAfter, addMonths, subMonths, differenceInHours, isToday, isTomorrow, startOfDay } from "date-fns";
import { useNavigate } from "react-router-dom";
import { tasksApi, moodsApi, type Task, type MoodEntry } from '../../lib/api';
import { useAuthContext } from '../../components/AuthProvider';
import { useProfile } from '../../hooks/useProfile';
import { useSubscription } from '../../hooks/useSubscription';
import { RewardedAdButton } from '../../components/RewardedAdButton';
import { useAdMob } from '../../hooks/useAdMob';

const moods = [
  { 
    image: "https://res.cloudinary.com/db6un9uvp/image/upload/v1745821510/Emoji_love_p24sik.png", 
    label: "Happy", 
    dateImage: "https://res.cloudinary.com/db6un9uvp/image/upload/v1745821510/Calendar_love_c25ddr.png" 
  },
  { 
    image: "https://res.cloudinary.com/db6un9uvp/image/upload/v1745821510/Emoji_normal_nwaaoy.png", 
    label: "Normal", 
    dateImage: "https://res.cloudinary.com/db6un9uvp/image/upload/v1745821510/Calendar_normal_p1dpdb.png" 
  },
  { 
    image: "https://res.cloudinary.com/db6un9uvp/image/upload/v1745821510/Emoji_sad_xkki0z.png", 
    label: "Sad", 
    dateImage: "https://res.cloudinary.com/db6un9uvp/image/upload/v1745821511/Calendar_sad_gm1eil.png" 
  },
  { 
    image: "https://res.cloudinary.com/db6un9uvp/image/upload/v1745821510/Emoji_angry_qy7ibh.png", 
    label: "Angry", 
    dateImage: "https://res.cloudinary.com/db6un9uvp/image/upload/v1745821510/Calendar_angry_fj508y.png" 
  },
];

export const Box = (): JSX.Element => {
  const navigate = useNavigate();
  const { user } = useAuthContext();
  const { profile } = useProfile();
  const { canUseMotivationalPopups, isFree } = useSubscription();
  const { isNative, showInterstitial } = useAdMob();
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [moodMap, setMoodMap] = useState<{ [key: string]: string }>({});
  const [tasks, setTasks] = useState<Task[]>([]);
  const [taskIndex, setTaskIndex] = useState(0);
  const [showMotivation, setShowMotivation] = useState(false);
  const [showSupportDialog, setShowSupportDialog] = useState(false);
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [error, setError] = useState<string | null>(null);
  const [moodSaving, setMoodSaving] = useState(false);

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  // Update current time every minute for real-time filtering
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000); // Update every minute

    return () => clearInterval(timer);
  }, []);

  const checkConnectivity = async (): Promise<boolean> => {
    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      if (!supabaseUrl) {
        throw new Error('Supabase URL not configured');
      }
      
      const response = await fetch(`${supabaseUrl}/rest/v1/`, {
        method: 'HEAD',
        headers: {
          'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY || '',
        },
      });
      
      return response.ok || response.status === 401; // 401 is expected without proper auth
    } catch (error) {
      console.error('Connectivity check failed:', error);
      return false;
    }
  };

  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);

      console.log('Loading data for user:', user?.id);
      console.log('Supabase URL:', import.meta.env.VITE_SUPABASE_URL);
      console.log('Supabase Key present:', !!import.meta.env.VITE_SUPABASE_ANON_KEY);
      
      // Check connectivity first
      const isConnected = await checkConnectivity();
      if (!isConnected) {
        throw new Error('Unable to connect to the server. Please check your internet connection.');
      }
      
      // Load all tasks and mood entries from Supabase
      const [tasksData, moodsData] = await Promise.all([
        tasksApi.getTasks().catch(err => {
          console.error('Error loading tasks:', err);
          throw new Error(`Failed to load tasks: ${err.message}`);
        }),
        moodsApi.getMoodEntries().catch(err => {
          console.error('Error loading moods:', err);
          throw new Error(`Failed to load moods: ${err.message}`);
        })
      ]);
      
      console.log('Loaded tasks:', tasksData.length);
      console.log('Loaded moods:', moodsData.length);
      
      setTasks(tasksData);
      
      // Convert mood entries to mood map
      const moodMapData: { [key: string]: string } = {};
      moodsData.forEach(entry => {
        moodMapData[entry.date] = entry.mood;
      });
      setMoodMap(moodMapData);
    } catch (error) {
      console.error('Error loading data:', error);
      
      let errorMessage = 'Failed to load data. ';
      
      if (error instanceof TypeError && error.message.includes('fetch')) {
        errorMessage += 'Please check your internet connection and try again.';
      } else if (error instanceof Error) {
        errorMessage += error.message;
      } else {
        errorMessage += 'An unexpected error occurred.';
      }
      
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const checkMotivationPopup = () => {
      // Only show motivational popups for Pro users
      if (!canUseMotivationalPopups()) return;

      const lastShownStr = localStorage.getItem('lastMotivationShown');
      const lastShownCount = localStorage.getItem('motivationShowCount');
      const now = new Date();
      const today = now.toDateString();

      if (!lastShownStr || !lastShownCount || new Date(lastShownStr).toDateString() !== today) {
        // Reset for new day
        localStorage.setItem('motivationShowCount', '0');
        localStorage.setItem('lastMotivationShown', now.toISOString());
        setShowMotivation(true);
      } else {
        const count = parseInt(lastShownCount, 10);
        if (count < 2) {
          const lastShown = new Date(lastShownStr);
          const hoursSinceLastShown = differenceInHours(now, lastShown);
          
          if (hoursSinceLastShown >= 6) {
            localStorage.setItem('motivationShowCount', (count + 1).toString());
            localStorage.setItem('lastMotivationShown', now.toISOString());
            setShowMotivation(true);
          }
        }
      }
    };

    checkMotivationPopup();
  }, [canUseMotivationalPopups]);

  const handleMoodSelect = async (label: string) => {
    const dateKey = format(selectedDate, "yyyy-MM-dd");
    
    try {
      setMoodSaving(true);
      setError(null);
      
      console.log('Attempting to save mood:', { dateKey, label });
      
      // Validate mood label
      const validMoods = ['Happy', 'Normal', 'Sad', 'Angry'];
      if (!validMoods.includes(label)) {
        throw new Error(`Invalid mood: ${label}`);
      }
      
      await moodsApi.setMood(dateKey, label as MoodEntry['mood']);
      
      // Update local state immediately for better UX
      setMoodMap(prev => ({ ...prev, [dateKey]: label }));
      
      console.log('Mood saved successfully');
    } catch (error) {
      console.error('Error setting mood:', error);
      
      let errorMessage = 'Failed to save mood. ';
      
      if (error instanceof Error) {
        if (error.message.includes('not authenticated')) {
          errorMessage += 'Please log in again.';
        } else if (error.message.includes('network') || error.message.includes('fetch')) {
          errorMessage += 'Please check your internet connection.';
        } else {
          errorMessage += error.message;
        }
      } else {
        errorMessage += 'Please try again.';
      }
      
      setError(errorMessage);
      
      // Show user-friendly error message
      alert(errorMessage + '\n\nPlease check:\n• Your internet connection\n• Supabase project is active\n• Environment variables are correct');
    } finally {
      setMoodSaving(false);
    }
  };

  const handleTaskComplete = async (taskId: string) => {
    try {
      await tasksApi.completeTask(taskId);
      await loadData(); // Refresh data
      setTaskIndex(0);
    } catch (error) {
      console.error('Error completing task:', error);
      setError('Failed to complete task. Please try again.');
    }
  };

  const handlePrevMonth = () => {
    setCurrentMonth(prev => subMonths(prev, 1));
    setSelectedDate(new Date());
  };

  const handleNextMonth = () => {
    setCurrentMonth(prev => addMonths(prev, 1));
    setSelectedDate(new Date());
  };

  const handleTaskSlide = (direction: 'left' | 'right') => {
    const criticalTasks = getCriticalTasks();
    if (criticalTasks.length <= 1) return;
    
    if (direction === 'right') {
      setTaskIndex(prev => (prev + 1) % criticalTasks.length);
    } else {
      setTaskIndex(prev => (prev - 1 + criticalTasks.length) % criticalTasks.length);
    }
  };

  const handleRetry = () => {
    if (user) {
      loadData();
    }
  };

  const handleSupportClick = () => {
    setShowSupportDialog(true);
  };

  const handleSupportAd = async () => {
    if (isNative) {
      // Show interstitial ad on mobile
      try {
        await showInterstitial();
        setShowSupportDialog(false);
        // Show thank you message
        setTimeout(() => {
          alert('Thank you for supporting us! Your help means a lot! 💖');
        }, 1000);
      } catch (error) {
        console.error('Error showing ad:', error);
        alert('Unable to show ad at the moment. Thank you for your support anyway! 💖');
        setShowSupportDialog(false);
      }
    } else {
      // For web, just show thank you message
      setShowSupportDialog(false);
      alert('Thank you for your support! On mobile devices, you can watch ads to help us improve the app! 💖');
    }
  };

  // Get urgent tasks to show on home screen - only for Plus and Pro users
  const getCriticalTasks = () => {
    // Free users don't see urgent tasks on home screen
    if (isFree()) return [];

    const now = currentTime;
    
    return tasks
      .filter(task => {
        // Don't show completed tasks
        if (task.completed) return false;
        
        const taskDeadline = new Date(task.deadline);
        const hoursUntilDeadline = differenceInHours(taskDeadline, now);
        
        // Show tasks that are due within 4 hours (including overdue tasks up to 1 hour past deadline)
        return hoursUntilDeadline <= 4 && hoursUntilDeadline > -1;
      })
      .sort((a, b) => {
        const aDeadline = new Date(a.deadline);
        const bDeadline = new Date(b.deadline);
        const aHours = differenceInHours(aDeadline, now);
        const bHours = differenceInHours(bDeadline, now);
        
        // Sort by urgency: most urgent first
        // 1. Overdue tasks first (negative hours, closest to 0)
        // 2. Then by closest deadline (smallest positive hours)
        // 3. Important tasks get priority within same time range
        
        if (aHours < 0 && bHours >= 0) return -1; // Overdue tasks first
        if (bHours < 0 && aHours >= 0) return 1;
        
        if (aHours < 0 && bHours < 0) {
          // Both overdue, show most recently overdue first
          return bHours - aHours;
        }
        
        // Both upcoming, show soonest first, with important tasks prioritized
        if (Math.abs(aHours - bHours) < 0.5) { // Within 30 minutes
          if (a.important && !b.important) return -1;
          if (b.important && !a.important) return 1;
        }
        
        return aHours - bHours; // Soonest deadline first
      })
      .slice(0, 3); // Show only top 3 most urgent tasks
  };

  const criticalTasks = getCriticalTasks();

  const daysOfWeek = ["S", "M", "T", "W", "T", "F", "S"];

  const renderCalendarDays = () => {
    const start = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1);
    const end = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0);
    const days = [];
    const startDay = start.getDay();

    for (let i = 0; i < startDay; i++) days.push(null);
    for (let i = 1; i <= end.getDate(); i++) days.push(i);

    return days.map((day, idx) => {
      if (!day) return <div key={idx} />;
      
      const currentDate = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), day);
      const dateKey = format(currentDate, "yyyy-MM-dd");
      const selectedMood = moodMap[dateKey];
      const mood = moods.find(m => m.label === selectedMood);
      const isToday = format(new Date(), "yyyy-MM-dd") === dateKey;
      const isSelected = format(selectedDate, "yyyy-MM-dd") === dateKey;

      return (
        <div 
          key={idx} 
          className={`relative flex items-center justify-center h-8 w-8 cursor-pointer min-h-touch min-w-touch ${
            isSelected ? "border-2 border-[#8B4769] rounded-full" : ""
          }`}
          onClick={() => setSelectedDate(currentDate)}
        >
          <span className="text-[#8B4769] font-medium z-10 text-sm">{day}</span>
          {mood && (
            <img
              src={mood.dateImage}
              alt={mood.label}
              className={`absolute inset-0 w-full h-full object-contain ${
                mood.label === "Normal" || mood.label === "Angry" ? "opacity-80" : ""
              }`}
              style={{ transform: "scale(0.9)" }}
            />
          )}
        </div>
      );
    });
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-[#FEE2E2] flex items-center justify-center">
        <div className="text-[#8B4769] text-xl font-semibold">Loading...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="fixed inset-0 bg-[#FEE2E2] flex items-center justify-center p-4">
        <div className="bg-[#FFEDED] rounded-3xl p-6 max-w-md w-full">
          <h2 className="text-[#8B4769] text-xl font-semibold mb-4 text-center">Connection Error</h2>
          <p className="text-[#8B4769] text-center mb-4">{error}</p>
          <div className="text-[#8B4769] text-sm mb-4">
            <p className="mb-2">Please check:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>Your internet connection</li>
              <li>Supabase project is active</li>
              <li>Environment variables are correct</li>
            </ul>
          </div>
          <Button 
            onClick={handleRetry}
            className="w-full bg-[#8B4769] text-white hover:bg-[#7A3F5E] min-h-touch"
          >
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-[#FEE2E2] overflow-hidden">
      <div className="h-full overflow-y-auto px-4 py-4 flex flex-col gap-4 font-['Quicksand'] max-w-md mx-auto">
        {showMotivation && canUseMotivationalPopups() && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-[#FFEDED] p-6 rounded-3xl relative max-w-xs w-full">
              <button
                onClick={() => setShowMotivation(false)}
                className="absolute top-2 right-2 text-[#8B4769] min-h-touch min-w-touch flex items-center justify-center"
              >
                <X className="w-5 h-5" />
              </button>
              <p className="text-[#8B4769] text-xl font-semibold text-center">
                You're doing amazing! Keep going! 🌟
              </p>
            </div>
          </div>
        )}

        <div className="flex justify-between items-center">
          <img 
            src={profile?.avatar_url || 'https://res.cloudinary.com/db6un9uvp/image/upload/v1745916296/default_avatar_kq7bxn.png'} 
            alt="Profile" 
            className="w-10 h-10 rounded-full object-cover border-2 border-[#8B4769]/20" 
          />
          <h1 className="text-[#8B4769] text-2xl font-semibold">My Velory</h1>
          <div className="flex items-center gap-2">
            <Button 
              variant="ghost" 
              onClick={handleSupportClick}
              className="text-[#8B4769] min-h-touch min-w-touch"
              title="Support Us"
            >
              <Heart className="w-6 h-6" />
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => navigate("/subscription", { state: { fromNavigation: true } })}
              className="text-[#8B4769] min-h-touch min-w-touch"
            >
              <Crown className="w-6 h-6" />
            </Button>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <div className="bg-[#FFEDED] rounded-3xl p-4 sm:p-6">
            <h2 className="text-[#8B4769] text-lg sm:text-xl font-semibold text-center mb-4">
              Select your mood today:
            </h2>
            <div className="flex justify-center gap-4 sm:gap-6 mb-4">
              {moods.map((mood) => (
                <button
                  key={mood.label}
                  onClick={() => handleMoodSelect(mood.label)}
                  disabled={moodSaving}
                  className={`w-10 h-10 sm:w-12 sm:h-12 transition-opacity min-h-touch min-w-touch ${moodSaving ? 'opacity-50 cursor-not-allowed' : 'hover:scale-110'}`}
                >
                  <img src={mood.image} alt={mood.label} className="w-full h-full object-contain" />
                </button>
              ))}
            </div>
            
            {moodSaving && (
              <div className="text-center text-[#8B4769] text-sm mb-2">
                Saving mood...
              </div>
            )}
            
            <h2 className="text-[#8B4769] text-xl sm:text-2xl font-semibold text-center mb-4">
              {format(selectedDate, "EEE, MMM d")}
            </h2>

            <div className="bg-[#FCE9EA] rounded-2xl p-3 sm:p-4">
              <div className="flex justify-between items-center mb-4">
                <Button 
                  variant="ghost" 
                  onClick={handlePrevMonth}
                  className="text-[#8B4769] min-h-touch min-w-touch"
                >
                  ←
                </Button>
                <span className="text-[#8B4769] font-semibold text-sm sm:text-base">
                  {format(currentMonth, "MMMM yyyy")}
                </span>
                <Button 
                  variant="ghost" 
                  onClick={handleNextMonth}
                  className="text-[#8B4769] min-h-touch min-w-touch"
                >
                  →
                </Button>
              </div>

              <div className="grid grid-cols-7 gap-1 sm:gap-2 mb-2">
                {daysOfWeek.map((day) => (
                  <div key={day} className="text-center text-[#96536F] font-semibold text-xs sm:text-sm">
                    {day}
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-7 gap-1 sm:gap-2">
                {renderCalendarDays()}
              </div>
            </div>
          </div>

          {/* Urgent Tasks Section - Only for Plus and Pro users */}
          {criticalTasks.length > 0 && (
            <div className="bg-[#FFEDED] rounded-3xl p-4 sm:p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-[#8B4769] text-lg sm:text-xl font-semibold">Urgent Tasks</h2>
                <span className="text-sm text-[#8B4769]/70">
                  {criticalTasks.length} task{criticalTasks.length !== 1 ? 's' : ''}
                </span>
              </div>
              <AnimatePresence mode="wait">
                <motion.div
                  key={criticalTasks[taskIndex]?.id || 'empty'}
                  initial={{ opacity: 0, x: 300 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -300 }}
                  className="flex items-start gap-3"
                  drag="x"
                  dragConstraints={{ left: 0, right: 0 }}
                  onDragEnd={(e, { offset }) => {
                    if (offset.x > 100) {
                      handleTaskSlide('left');
                    } else if (offset.x < -100) {
                      handleTaskSlide('right');
                    }
                  }}
                >
                  {criticalTasks[taskIndex] && (
                    <>
                      <Checkbox
                        checked={false}
                        onCheckedChange={() => handleTaskComplete(criticalTasks[taskIndex].id)}
                        className="w-3.5 h-3.5 border-2 border-[#8B4769] rounded-sm mt-1 flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start gap-2 mb-1 flex-wrap">
                          <h3 className="text-[#8B4769] text-lg sm:text-xl font-semibold flex-1 min-w-0 break-words">{criticalTasks[taskIndex].title}</h3>
                          <div className="flex gap-1 flex-wrap">
                            {criticalTasks[taskIndex].important && (
                              <span className="bg-red-100 text-red-600 text-xs px-2 py-1 rounded-full font-medium whitespace-nowrap">
                                Important
                              </span>
                            )}
                            {(() => {
                              const hoursLeft = differenceInHours(new Date(criticalTasks[taskIndex].deadline), currentTime);
                              if (hoursLeft < 0) {
                                return (
                                  <span className="bg-red-200 text-red-700 text-xs px-2 py-1 rounded-full font-medium whitespace-nowrap">
                                    Overdue
                                  </span>
                                );
                              } else if (hoursLeft <= 1) {
                                return (
                                  <span className="bg-orange-100 text-orange-600 text-xs px-2 py-1 rounded-full font-medium whitespace-nowrap">
                                    Due Soon
                                  </span>
                                );
                              }
                              return null;
                            })()}
                          </div>
                        </div>
                        <p className="text-[#8B4769] font-medium mb-2 text-sm sm:text-base break-words">{criticalTasks[taskIndex].description}</p>
                        <div className="text-xs sm:text-sm text-[#8B4769]/70">
                          Due: {isToday(new Date(criticalTasks[taskIndex].deadline)) 
                            ? `Today at ${format(new Date(criticalTasks[taskIndex].deadline), 'h:mm a')}`
                            : isTomorrow(new Date(criticalTasks[taskIndex].deadline))
                            ? `Tomorrow at ${format(new Date(criticalTasks[taskIndex].deadline), 'h:mm a')}`
                            : format(new Date(criticalTasks[taskIndex].deadline), 'MMM d, h:mm a')
                          }
                        </div>
                      </div>
                    </>
                  )}
                </motion.div>
              </AnimatePresence>
              
              {criticalTasks.length > 1 && (
                <div className="flex justify-center gap-2 mt-4">
                  {criticalTasks.map((_, idx) => (
                    <div
                      key={idx}
                      className={`w-2 h-2 rounded-full ${
                        idx === taskIndex ? "bg-[#8B4769]" : "bg-[#8B4769]/30"
                      }`}
                    />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        <div className="mt-auto pt-4 flex justify-evenly">
          <Button 
            variant="ghost" 
            onClick={() => navigate("/tasks")}
            className="text-[#8B4769] flex flex-col items-center min-h-touch min-w-touch p-2"
          >
            <img 
              src="https://res.cloudinary.com/db6un9uvp/image/upload/v1745823849/tasks_qauze9.png" 
              alt="Tasks" 
              className="w-5 h-5 sm:w-6 sm:h-6 object-contain" 
            />
            <span className="text-xs sm:text-sm font-medium">Tasks</span>
          </Button>
          <Button 
            variant="ghost" 
            onClick={() => navigate("/writeups")}
            className="text-[#8B4769] flex flex-col items-center min-h-touch min-w-touch p-2"
          >
            <img 
              src="https://res.cloudinary.com/db6un9uvp/image/upload/v1745823849/writeups_fyimtz.png" 
              alt="Writeups" 
              className="w-5 h-5 sm:w-6 sm:h-6 object-contain" 
            />
            <span className="text-xs sm:text-sm font-medium">Writeups</span>
          </Button>
          <Button 
            variant="ghost" 
            onClick={() => navigate("/trackers")}
            className="text-[#8B4769] flex flex-col items-center min-h-touch min-w-touch p-2"
          >
            <img 
              src="https://res.cloudinary.com/db6un9uvp/image/upload/v1745823849/trackers_nzsqcd.png" 
              alt="Trackers" 
              className="w-5 h-5 sm:w-6 sm:h-6 object-contain" 
            />
            <span className="text-xs sm:text-sm font-medium">Trackers</span>
          </Button>
          <Button 
            variant="ghost" 
            onClick={() => navigate("/profile")}
            className="text-[#8B4769] flex flex-col items-center min-h-touch min-w-touch p-2"
          >
            <img 
              src="https://res.cloudinary.com/db6un9uvp/image/upload/v1745823849/profile_lpfdmk.png" 
              alt="Profile" 
              className="w-5 h-5 sm:w-6 sm:h-6 object-contain" 
            />
            <span className="text-xs sm:text-sm font-medium">Profile</span>
          </Button>
        </div>

        {/* Support Us Dialog */}
        <Dialog open={showSupportDialog} onOpenChange={setShowSupportDialog}>
          <DialogContent className="w-[95vw] max-w-[400px] bg-white rounded-3xl p-6">
            <DialogHeader>
              <DialogTitle className="text-center text-xl font-semibold text-[#8B4769] mb-3 flex items-center justify-center gap-2">
                <Heart className="w-6 h-6 text-red-500" />
                Support Velory
              </DialogTitle>
            </DialogHeader>
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-gradient-to-br from-pink-400 to-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <p className="text-[#8B4769]/80 mb-4">
                Help us improve Velory and keep it free! Your support helps us add new features and provide better service.
              </p>
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 mb-4">
                <p className="text-blue-800 text-sm">
                  <strong>How it helps:</strong> Ad revenue allows us to keep developing new features, fix bugs faster, and maintain our servers without charging users.
                </p>
              </div>
              
              {isNative ? (
                <div className="space-y-3">
                  <Button
                    onClick={handleSupportAd}
                    className="w-full bg-gradient-to-r from-pink-500 to-red-500 text-white hover:from-pink-600 hover:to-red-600 py-3"
                  >
                    <Heart className="w-4 h-4 mr-2" />
                    Watch Ad to Support Us
                  </Button>
                  <p className="text-xs text-[#8B4769]/60">
                    This will show a short ad and help us improve the app
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="bg-orange-50 p-3 rounded-lg border border-orange-200">
                    <p className="text-orange-800 text-sm">
                      <strong>Mobile Feature:</strong> Ad support is available in our mobile app. Download Velory from the app store to help support us!
                    </p>
                  </div>
                  <Button
                    onClick={() => setShowSupportDialog(false)}
                    className="w-full bg-[#8B4769] text-white hover:bg-[#96536F] py-3"
                  >
                    <Heart className="w-4 h-4 mr-2" />
                    Thanks for Your Support!
                  </Button>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setShowSupportDialog(false)}
                className="w-full border-[#8B4769] text-[#8B4769]"
              >
                Maybe Later
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};