import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Pencil, Plus, MoreVertical, Trash2, Crown, Lock } from 'lucide-react';
import { Button } from "../../components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { Checkbox } from "../../components/ui/checkbox";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../../components/ui/dropdown-menu";
import { format, differenceInHours, isToday, isBefore, startOfDay } from 'date-fns';
import { tasksApi, type Task } from '../../lib/api';
import { useAuthContext } from '../../components/AuthProvider';
import { useNotifications } from '../../hooks/useNotifications';
import { useSubscription } from '../../hooks/useSubscription';
import { useAdMob } from '../../hooks/useAdMob';
import { SubscriptionGate, UsageLimit } from '../../components/SubscriptionGate';

const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export const Tasks = (): JSX.Element => {
  const navigate = useNavigate();
  const { user } = useAuthContext();
  const { scheduleTaskReminders, clearTaskNotifications, permission } = useNotifications();
  const { checkLimit, incrementUsage, getLimit, isUnlimited, subscriptionData } = useSubscription();
  const { isNative, showInterstitial } = useAdMob();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddTask, setShowAddTask] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [completedTasksCount, setCompletedTasksCount] = useState(0);
  const [newTask, setNewTask] = useState<Partial<Task>>({
    title: "",
    description: "",
    deadline: new Date().toISOString(),
    repeat_days: [],
    tag: "",
    important: false
  });
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [upgradeMessage, setUpgradeMessage] = useState('');

  // Load tasks from Supabase
  useEffect(() => {
    if (user) {
      loadTasks();
      // Load completed tasks count from localStorage
      const savedCount = localStorage.getItem('completedTasksCount');
      if (savedCount) {
        setCompletedTasksCount(parseInt(savedCount, 10));
      }
    }
  }, [user]);

  // Update current time every minute for real-time color updates
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000); // Update every minute

    return () => clearInterval(timer);
  }, []);

  const loadTasks = async () => {
    try {
      setLoading(true);
      const data = await tasksApi.getTasks();
      setTasks(data);
    } catch (error) {
      console.error('Error loading tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  const getTaskUrgencyColor = (deadline: string): string => {
    const hoursLeft = differenceInHours(new Date(deadline), currentTime);
    
    if (hoursLeft <= 1) {
      return "bg-red-200"; // Red tint for ≤1 hour
    } else if (hoursLeft <= 4) {
      return "bg-white"; // White for >1 hour to ≤4 hours
    } else {
      return "bg-green-200"; // Green tint for >4 hours
    }
  };

  const showInterstitialAdForTasks = async () => {
    if (isNative && completedTasksCount > 0 && completedTasksCount % 5 === 0) {
      try {
        console.log(`Showing interstitial ad after ${completedTasksCount} completed tasks`);
        await showInterstitial();
      } catch (error) {
        console.error('Error showing interstitial ad:', error);
      }
    }
  };

  const handleTaskComplete = async (taskId: string) => {
    try {
      await tasksApi.completeTask(taskId);
      
      // Clear notifications for completed task
      clearTaskNotifications(taskId);
      
      // Increment completed tasks count
      const newCount = completedTasksCount + 1;
      setCompletedTasksCount(newCount);
      localStorage.setItem('completedTasksCount', newCount.toString());
      
      // Show interstitial ad every 5 completed tasks
      await showInterstitialAdForTasks();
      
      await loadTasks(); // Refresh the list
    } catch (error) {
      console.error('Error completing task:', error);
    }
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setNewTask({
      title: task.title,
      description: task.description,
      deadline: task.deadline,
      repeat_days: task.repeat_days,
      tag: task.tag,
      important: task.important
    });
    setShowAddTask(true);
  };

  const handleDeleteTask = async (taskId: string) => {
    try {
      await tasksApi.deleteTask(taskId);
      
      // Clear notifications for deleted task
      clearTaskNotifications(taskId);
      
      await loadTasks(); // Refresh the list
    } catch (error) {
      console.error('Error deleting task:', error);
    }
  };

  // Check if user can create a new task
  const canCreateTask = async (isImportant: boolean = false) => {
    const resourceType = isImportant ? 'important_tasks' : 'daily_tasks';
    const canCreate = await checkLimit(resourceType);
    
    if (!canCreate) {
      const limit = getLimit(resourceType);
      const taskType = isImportant ? 'important' : 'daily';
      setUpgradeMessage(
        `You've reached your ${taskType} task limit of ${limit} tasks. Upgrade to ${subscriptionData?.plan?.id === 'free' ? 'Velory Plus' : 'Velory Pro'} for ${isImportant ? (subscriptionData?.plan?.id === 'free' ? '20' : 'unlimited') : (subscriptionData?.plan?.id === 'free' ? '30' : 'unlimited')} ${taskType} tasks.`
      );
      setShowUpgradeDialog(true);
      return false;
    }
    
    return true;
  };

  // Filter pending tasks - remove expired tasks unless they're important
  const sortedPendingTasks = tasks
    .filter(task => {
      if (task.completed) return false;
      
      // Keep important tasks even if expired
      if (task.important) return true;
      
      // Remove non-important tasks that have passed their deadline
      return !isBefore(new Date(task.deadline), currentTime);
    })
    .sort((a, b) => {
      // Sort by importance first, then by deadline
      if (a.important && !b.important) return -1;
      if (!a.important && b.important) return 1;
      return new Date(a.deadline).getTime() - new Date(b.deadline).getTime();
    });

  // Filter completed tasks (only from today)
  const completedTasks = tasks
    .filter(task => task.completed && task.completed_at && isToday(new Date(task.completed_at)))
    .sort((a, b) => new Date(b.deadline).getTime() - new Date(a.deadline).getTime());

  const handleSaveTask = async () => {
    if (!newTask.title || !user?.id) return;
    
    // Check limits before creating/updating
    if (!editingTask) {
      const canCreate = await canCreateTask(newTask.important);
      if (!canCreate) return;
    }
    
    try {
      const taskData = {
        title: newTask.title,
        description: newTask.description || "",
        deadline: newTask.deadline || new Date().toISOString(),
        repeat_days: newTask.repeat_days || [],
        tag: newTask.tag || "",
        important: newTask.important || false,
        completed: false,
        user_id: user.id
      };

      let savedTask: Task;
      if (editingTask) {
        savedTask = await tasksApi.updateTask(editingTask.id, taskData);
        
        // Clear old notifications and schedule new ones
        clearTaskNotifications(editingTask.id);
      } else {
        savedTask = await tasksApi.createTask(taskData);
        
        // Increment usage for new tasks
        const resourceType = newTask.important ? 'important_tasks' : 'daily_tasks';
        await incrementUsage(resourceType);
      }
      
      // Schedule notifications for the task if permissions are granted
      if (permission.granted) {
        scheduleTaskReminders(savedTask);
      }
      
      await loadTasks(); // Refresh the list
      setShowAddTask(false);
      setNewTask({
        title: "",
        description: "",
        deadline: new Date().toISOString(),
        repeat_days: [],
        tag: "",
        important: false
      });
      setEditingTask(null);
    } catch (error) {
      console.error('Error saving task:', error);
    }
  };

  const toggleDay = (day: string) => {
    const repeat = newTask.repeat_days || [];
    
    if (repeat.includes(day)) {
      setNewTask({
        ...newTask,
        repeat_days: repeat.filter(d => d !== day)
      });
    } else {
      setNewTask({
        ...newTask,
        repeat_days: [...repeat, day]
      });
    }
  };

  // Get current usage counts
  const dailyTasksCount = tasks.filter(task => !task.completed && !task.important).length;
  const importantTasksCount = tasks.filter(task => task.important && !task.completed).length;
  const dailyTasksLimit = getLimit('daily_tasks');
  const importantTasksLimit = getLimit('important_tasks');

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FEE2E2] flex items-center justify-center">
        <div className="text-[#8B4769] text-xl font-semibold">Loading tasks...</div>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen bg-[#FEE2E2] bg-cover bg-center"
      style={{ backgroundImage: 'url("https://res.cloudinary.com/db6un9uvp/image/upload/v1745826910/Tasks_bg_yjndjm.png")' }}
    >
      <div className="h-full max-w-md mx-auto px-4 py-4 font-['Quicksand']">
        <div className="flex items-center justify-between mb-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate(-1)}
            className="text-[#8B4769] -ml-3 min-h-touch min-w-touch"
          >
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <Button 
            variant="ghost" 
            onClick={() => navigate("/subscription", { state: { fromNavigation: true } })}
            className="text-[#8B4769] min-h-touch min-w-touch"
          >
            <Crown className="w-6 h-6" />
          </Button>
        </div>

        {/* Usage Limits Display */}
        <div className="mb-4 space-y-2">
          {!isUnlimited('daily_tasks') && (
            <UsageLimit
              resourceType="Daily Tasks"
              current={dailyTasksCount}
              limit={dailyTasksLimit}
              unit="tasks"
            />
          )}
          {!isUnlimited('important_tasks') && (
            <UsageLimit
              resourceType="Important Tasks"
              current={importantTasksCount}
              limit={importantTasksLimit}
              unit="tasks"
            />
          )}
        </div>

        {/* Task completion progress indicator */}
        {isNative && (
          <div className="mb-4">
            <div className="bg-white/80 rounded-xl p-3 border-2 border-[#8B4769]/20">
              <div className="flex items-center justify-between text-sm">
                <span className="text-[#8B4769] font-medium">Tasks Completed</span>
                <span className="text-[#8B4769]/70">{completedTasksCount} total</span>
              </div>
              <div className="mt-2 text-xs text-[#8B4769]/60">
                {completedTasksCount > 0 && completedTasksCount % 5 === 0 
                  ? "🎉 You've earned an ad reward!" 
                  : `${5 - (completedTasksCount % 5)} more tasks until next ad reward`
                }
              </div>
            </div>
          </div>
        )}

        <Tabs defaultValue="pending" className="w-full">
          <TabsList className="w-full mb-4 bg-white/80 rounded-full">
            <TabsTrigger value="pending" className="flex-1 rounded-full">
              Pending ({sortedPendingTasks.length})
            </TabsTrigger>
            <TabsTrigger value="done" className="flex-1 rounded-full">
              Done ({completedTasks.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pending">
            {sortedPendingTasks.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-[60vh]">
                <p className="text-[#8B4769] text-2xl font-semibold text-center">Hurray, no tasks for today!</p>
              </div>
            ) : (
              <div className="space-y-4">
                {sortedPendingTasks.map(task => (
                  <div 
                    key={task.id} 
                    className={`${getTaskUrgencyColor(task.deadline)} rounded-xl p-4 flex items-start gap-3 transition-colors duration-300`}
                  >
                    <Checkbox
                      checked={task.completed}
                      onCheckedChange={() => handleTaskComplete(task.id)}
                      className="w-3.5 h-3.5 border-2 border-[#8B4769] rounded-sm mt-1 flex-shrink-0"
                    />
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <h3 className="text-lg font-semibold">{task.title}</h3>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 min-h-touch min-w-touch">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleEditTask(task)}>
                              <Pencil className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleDeleteTask(task.id)}
                              className="text-red-600"
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                      {task.description && (
                        <p className="text-sm text-gray-600 mb-2">{task.description}</p>
                      )}
                      <div className="flex gap-2 mt-2">
                        <span className="text-sm bg-[#8B4769]/10 px-2 py-1 rounded-full">
                          {format(new Date(task.deadline), "MMM d, h:mm a")}
                        </span>
                        {task.tag && (
                          <span className="text-sm bg-[#8B4769]/10 px-2 py-1 rounded-full">
                            {task.tag}
                          </span>
                        )}
                        {task.important && (
                          <span className="text-sm bg-red-100 px-2 py-1 rounded-full text-red-600">
                            Important
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="done">
            {completedTasks.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-[60vh]">
                <p className="text-[#8B4769] text-2xl font-semibold text-center">No completed tasks yet!</p>
              </div>
            ) : (
              <div className="space-y-4">
                {completedTasks.map(task => (
                  <div key={task.id} className="bg-white/50 rounded-xl p-4 flex items-start gap-3">
                    <Checkbox checked={true} className="w-3.5 h-3.5 border-2 border-[#8B4769] rounded-sm mt-1 flex-shrink-0" />
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold line-through">{task.title}</h3>
                      {task.description && (
                        <p className="text-sm text-gray-600 mb-2 line-through">{task.description}</p>
                      )}
                      <div className="flex gap-2 mt-2">
                        <span className="text-sm bg-[#8B4769]/10 px-2 py-1 rounded-full line-through">
                          {format(new Date(task.deadline), "MMM d, h:mm a")}
                        </span>
                        {task.tag && (
                          <span className="text-sm bg-[#8B4769]/10 px-2 py-1 rounded-full line-through">
                            {task.tag}
                          </span>
                        )}
                        <span className="text-sm bg-green-100 px-2 py-1 rounded-full text-green-600">
                          Completed at {task.completed_at ? format(new Date(task.completed_at), "h:mm a") : ""}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        <Button 
          onClick={async () => {
            const canCreate = await canCreateTask(false);
            if (canCreate) {
              setEditingTask(null);
              setNewTask({
                title: "",
                description: "",
                deadline: new Date().toISOString(),
                repeat_days: [],
                tag: "",
                important: false
              });
              setShowAddTask(true);
            }
          }}
          className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-[#96536F] hover:bg-[#8B4769] transition-colors min-h-touch min-w-touch"
        >
          <Plus className="w-6 h-6 text-white" />
        </Button>

        {/* Upgrade Dialog */}
        <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
          <DialogContent className="w-[95vw] max-w-[400px] bg-white rounded-3xl p-6">
            <DialogHeader>
              <DialogTitle className="text-center text-xl font-semibold text-[#8B4769] mb-3">Upgrade Required</DialogTitle>
            </DialogHeader>
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lock className="w-8 h-8 text-white" />
              </div>
              <p className="text-[#8B4769]/80 mb-6">{upgradeMessage}</p>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setShowUpgradeDialog(false)}
                  className="flex-1 border-[#8B4769] text-[#8B4769]"
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    setShowUpgradeDialog(false);
                    navigate('/subscription');
                  }}
                  className="flex-1 bg-[#8B4769] text-white hover:bg-[#96536F]"
                >
                  <Crown className="w-4 h-4 mr-2" />
                  Upgrade
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={showAddTask} onOpenChange={setShowAddTask}>
          <DialogContent className="w-[95vw] max-w-[400px] max-h-[90vh] overflow-y-auto bg-white rounded-3xl p-4">
            <DialogHeader>
              <DialogTitle className="text-xl font-semibold mb-4 text-center">
                {editingTask ? 'Edit Task' : 'Add New Task'}
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-3">
              <input
                type="text"
                placeholder="Task Name"
                className="w-full p-3 rounded-2xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#8B4769] text-sm"
                value={newTask.title}
                onChange={e => setNewTask({ ...newTask, title: e.target.value })}
              />

              <textarea
                placeholder="Description (optional)"
                className="w-full p-3 rounded-2xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#8B4769] min-h-[60px] text-sm resize-none"
                value={newTask.description}
                onChange={e => setNewTask({ ...newTask, description: e.target.value })}
              />

              <input
                type="datetime-local"
                className="w-full p-3 rounded-2xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#8B4769] text-sm"
                value={newTask.deadline ? format(new Date(newTask.deadline), "yyyy-MM-dd'T'HH:mm") : ''}
                onChange={e => setNewTask({ ...newTask, deadline: new Date(e.target.value).toISOString() })}
              />

              <input
                type="text"
                placeholder="Tag (optional)"
                className="w-full p-3 rounded-2xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#8B4769] text-sm"
                value={newTask.tag}
                onChange={e => setNewTask({ ...newTask, tag: e.target.value })}
              />

              <div>
                <p className="font-medium mb-2 text-sm">Repeat on:</p>
                <div className="grid grid-cols-7 gap-1">
                  {daysOfWeek.map((day, index) => (
                    <button
                      key={day}
                      className={`h-8 text-xs rounded-xl border ${
                        newTask.repeat_days?.includes(day)
                          ? 'bg-[#8B4769] text-white'
                          : 'border-gray-200'
                      }`}
                      onClick={() => toggleDay(day)}
                    >
                      {day}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Checkbox
                  checked={newTask.important}
                  onCheckedChange={async (checked) => {
                    if (checked && !editingTask) {
                      const canCreate = await canCreateTask(true);
                      if (!canCreate) return;
                    }
                    setNewTask({ ...newTask, important: !!checked });
                  }}
                  className="rounded-lg"
                />
                <span className="text-sm">Important</span>
                {newTask.important && !isUnlimited('important_tasks') && (
                  <span className="text-xs text-orange-600 bg-orange-100 px-2 py-1 rounded-full">
                    Uses important task slot
                  </span>
                )}
              </div>

              {/* Notification info */}
              {permission.granted && (
                <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                  <p className="text-blue-800 text-xs">
                    🔔 You'll receive notifications 1 hour, 30 minutes, and 5 minutes before the deadline.
                  </p>
                </div>
              )}

              <div className="flex gap-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowAddTask(false);
                    setEditingTask(null);
                    setNewTask({
                      title: "",
                      description: "",
                      deadline: new Date().toISOString(),
                      repeat_days: [],
                      tag: "",
                      important: false
                    });
                  }}
                  className="flex-1 rounded-2xl h-10 text-sm min-h-touch"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSaveTask}
                  className="flex-1 bg-[#8B4769] text-white rounded-2xl h-10 hover:bg-[#96536F] text-sm min-h-touch"
                >
                  {editingTask ? 'Save Changes' : 'Add'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};