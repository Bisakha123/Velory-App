import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Card, CardContent } from "../../components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import { Button } from "../../components/ui/button";
import { motion } from 'framer-motion';
import {
  Feather,
  Star,
  PenTool,
  User,
  Target,
  ArrowLeft,
  Crown
} from 'lucide-react';

const categories = {
  me: [
    { title: 'Thoughts Journal', icon: Feather, path: '/writeups/thoughts' },
    { title: 'Gratitude Log', icon: Star, path: '/writeups/gratitude' },
    { title: 'Creative Writing', icon: PenTool, path: '/writeups/creative' },
  ],
  journey: [
    { title: 'Autobiography', icon: User, path: '/writeups/autobiography' },
    { title: 'Journal', icon: PenTool, path: '/writeups/journal' },
    { title: 'Goals', icon: Target, path: '/writeups/goals' },
  ],
};

interface SectionProps {
  title: string;
  items: Array<{
    title: string;
    icon: React.ElementType;
    path: string;
  }>;
}

export const Writeups = (): JSX.Element => {
  const navigate = useNavigate();
  const location = useLocation();
  const defaultTab = location.state?.tab || 'me';

  return (
    <div 
      className="min-h-screen bg-[#FEE2E2] bg-cover bg-center px-4 py-4 font-['Quicksand']"
      style={{ 
        backgroundImage: 'url("https://res.cloudinary.com/db6un9uvp/image/upload/v1745916294/Writeups_bg_krorce.png")',
        backgroundBlendMode: 'multiply',
        backgroundColor: 'rgba(0, 0, 0, 0.2)'
      }}
    >
      <div className="flex items-center justify-between mb-6">
        <Button 
          variant="ghost" 
          onClick={() => navigate(-1)}
          className="text-[#8B4769] -ml-3"
        >
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <motion.h1
          className="text-3xl font-bold text-[#8B4769]"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          Writeups
        </motion.h1>
        <Button 
          variant="ghost" 
          onClick={() => navigate("/subscription", { state: { fromNavigation: true } })}
          className="text-[#8B4769]"
        >
          <Crown className="w-6 h-6" />
        </Button>
      </div>

      <Tabs defaultValue={defaultTab} className="w-full max-w-xl mx-auto">
        <TabsList className="w-full mb-8 bg-[#8B4769]/10 backdrop-blur rounded-xl border-2 border-[#8B4769]/20">
          <TabsTrigger value="me" className="flex-1 text-[#8B4769] font-semibold">Me</TabsTrigger>
          <TabsTrigger value="journey" className="flex-1 text-[#8B4769] font-semibold">My Journey</TabsTrigger>
        </TabsList>

        <div className="space-y-6">
          <TabsContent value="me">
            <Section title="Me" items={categories.me} navigate={navigate} />
          </TabsContent>
          <TabsContent value="journey">
            <Section title="My Journey" items={categories.journey} navigate={navigate} />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
};

const Section: React.FC<SectionProps & { navigate: (path: string) => void }> = ({ title, items, navigate }) => (
  <div className="space-y-4">
    <h2 className="text-xl font-semibold text-[#8B4769]">{title}</h2>
    <div className="grid grid-cols-2 gap-4">
      {items.map(({ title, icon: Icon, path }) => (
        <motion.div
          key={title}
          whileHover={{ scale: 1.03 }}
          transition={{ type: 'spring', stiffness: 300 }}
          onClick={() => navigate(path, { state: { tab: title.includes('Goals') ? 'journey' : 'me' } })}
        >
          <Card className="rounded-2xl bg-[#8B4769]/10 backdrop-blur shadow-lg cursor-pointer hover:shadow-xl transition-shadow duration-300 border-2 border-[#8B4769]/20">
            <CardContent className="p-4 flex flex-col items-center text-[#8B4769] gap-2">
              <Icon className="w-6 h-6" />
              <span className="text-center font-semibold">{title}</span>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  </div>
);