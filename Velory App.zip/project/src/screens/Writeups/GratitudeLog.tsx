import React, { useState, useEffect } from 'react';
import { Plus, Eye, ArrowLeft, Crown, Lock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { motion } from "framer-motion";
import { writeupsApi, type Writeup } from '../../lib/api';
import { useAuthContext } from '../../components/AuthProvider';
import { useSubscription } from '../../hooks/useSubscription';
import { UsageLimit } from '../../components/SubscriptionGate';
import { format } from 'date-fns';

interface GratitudeEntry {
  date: string;
  gratitude: string[];
}

export const GratitudeLog = () => {
  const navigate = useNavigate();
  const { user } = useAuthContext();
  const { checkLimit, incrementUsage, getLimit, isUnlimited } = useSubscription();
  const [entries, setEntries] = useState<Writeup[]>([]);
  const [loading, setLoading] = useState(true);
  const [todayEntry, setTodayEntry] = useState<string[]>(['']);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedEntry, setSelectedEntry] = useState<Writeup | null>(null);
  const [todayExistingEntry, setTodayExistingEntry] = useState<Writeup | null>(null);
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [wordCounts, setWordCounts] = useState<number[]>([0]);

  const todayDate = new Date().toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  useEffect(() => {
    if (user) {
      loadEntries();
    }
  }, [user]);

  const loadEntries = async () => {
    try {
      setLoading(true);
      const data = await writeupsApi.getWriteups('gratitude');
      setEntries(data);
      
      // Check if there's an entry for today
      const today = format(new Date(), 'yyyy-MM-dd');
      const existing = data.find((e) => 
        format(new Date(e.created_at), 'yyyy-MM-dd') === today
      );
      
      if (existing) {
        const gratitudeData = parseGratitudeContent(existing.content);
        setTodayEntry(gratitudeData.gratitude);
        setWordCounts(gratitudeData.gratitude.map(item => countWords(item)));
        setTodayExistingEntry(existing);
        setIsEditing(true);
      } else {
        setTodayEntry(['']);
        setWordCounts([0]);
        setTodayExistingEntry(null);
        setIsEditing(false);
      }
    } catch (error) {
      console.error('Error loading gratitude entries:', error);
    } finally {
      setLoading(false);
    }
  };

  const parseGratitudeContent = (content: string): GratitudeEntry => {
    try {
      return JSON.parse(content);
    } catch {
      return { date: todayDate, gratitude: [content] };
    }
  };

  const countWords = (text: string): number => {
    return text.trim().split(/\s+/).filter(word => word.length > 0).length;
  };

  const getTotalWordCount = (): number => {
    return wordCounts.reduce((total, count) => total + count, 0);
  };

  const canCreateGratitude = async () => {
    const canCreate = await checkLimit('gratitude_days');
    if (!canCreate) {
      setShowUpgradeDialog(true);
      return false;
    }
    return true;
  };

  const gratitudeWordLimit = getLimit('gratitude_words_per_day');
  const isAtWordLimit = gratitudeWordLimit > 0 && getTotalWordCount() >= gratitudeWordLimit;

  const handleItemChange = (index: number, value: string) => {
    const wordCount = countWords(value);
    const otherWordCounts = wordCounts.filter((_, i) => i !== index);
    const totalOtherWords = otherWordCounts.reduce((total, count) => total + count, 0);
    
    // If word limit is set and would be exceeded, don't allow the change
    if (gratitudeWordLimit > 0 && (wordCount + totalOtherWords) > gratitudeWordLimit) {
      return;
    }
    
    const updated = [...todayEntry];
    updated[index] = value;
    setTodayEntry(updated);
    
    const updatedWordCounts = [...wordCounts];
    updatedWordCounts[index] = wordCount;
    setWordCounts(updatedWordCounts);
  };

  const handleSave = async () => {
    if (!todayEntry.some((g) => g.trim() !== '') || !user?.id) return;

    // Check limits for new entries
    if (!todayExistingEntry) {
      const canCreate = await canCreateGratitude();
      if (!canCreate) return;
    }

    try {
      const gratitudeData = {
        type: 'gratitude' as const,
        title: `Gratitude - ${todayDate}`,
        content: JSON.stringify({
          date: todayDate,
          gratitude: todayEntry.filter(g => g.trim() !== '')
        }),
        tags: [],
        metadata: {},
        user_id: user.id
      };

      if (todayExistingEntry) {
        // Update existing entry for today
        await writeupsApi.updateWriteup(todayExistingEntry.id, gratitudeData);
      } else {
        // Create new entry for today
        await writeupsApi.createWriteup(gratitudeData);
        // Increment usage for new gratitude days
        await incrementUsage('gratitude_days');
      }

      await loadEntries(); // Refresh the list
    } catch (error) {
      console.error('Error saving gratitude entry:', error);
    }
  };

  const handleAddMore = () => {
    setTodayEntry([...todayEntry, '']);
    setWordCounts([...wordCounts, 0]);
  };

  const handleStartEditing = () => {
    setIsEditing(false);
  };

  const gratitudeLimit = getLimit('gratitude_days');
  const currentCount = entries.length;

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FEE2E2] flex items-center justify-center">
        <div className="text-[#8B4769] text-xl font-semibold">Loading gratitude log...</div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-cover bg-center p-4 font-['Quicksand']"
      style={{
        backgroundImage:
          "url('https://res.cloudinary.com/db6un9uvp/image/upload/v1745916296/Autobiography_bg_fyshzv.png')",
        backgroundBlendMode: 'multiply',
        backgroundColor: 'rgba(0, 0, 0, 0.2)'
      }}
    >
      <div className="flex items-center justify-between mb-8">
        <Button 
          variant="ghost" 
          onClick={() => navigate(-1)}
          className="text-white -ml-3"
        >
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <Button 
          variant="ghost" 
          onClick={() => navigate("/subscription", { state: { fromNavigation: true } })}
          className="text-white"
        >
          <Crown className="w-6 h-6" />
        </Button>
      </div>

      <motion.div 
        className="text-center mb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-4xl font-extrabold text-white mb-2 tracking-wide font-['Indie Flower']">
          Gratitude Log
        </h1>
        <div className="flex items-center justify-center gap-3">
          <div className="h-0.5 w-12 bg-gradient-to-r from-transparent via-pink-400 to-transparent" />
          <span className="text-pink-300">✨</span>
          <div className="h-0.5 w-12 bg-gradient-to-r from-transparent via-pink-400 to-transparent" />
        </div>
      </motion.div>

      <div className="max-w-2xl mx-auto">
        {/* Usage Limit Display */}
        {!isUnlimited('gratitude_days') && (
          <div className="mb-6">
            <UsageLimit
              resourceType="Gratitude Days"
              current={currentCount}
              limit={gratitudeLimit}
              unit="days"
            />
          </div>
        )}

        {!selectedEntry && (
          <div className="bg-white/80 shadow-lg rounded-2xl p-6 mb-6 border-2 border-[#8B4769]/20">
            <div className="flex items-center justify-between mb-4">
              <div className="text-sm text-[#8B4769] font-semibold">Today - {todayDate}</div>
              {gratitudeWordLimit > 0 && (
                <div className="text-sm text-[#8B4769]/70">
                  <span className={isAtWordLimit ? 'text-red-600 font-medium' : ''}>
                    {getTotalWordCount()}/{gratitudeWordLimit} words
                  </span>
                </div>
              )}
            </div>
            {isEditing ? (
              <div className="space-y-3">
                <div className="text-[#8B4769] font-medium mb-3">Your gratitude for today:</div>
                {todayEntry.map((item, index) => (
                  <div
                    key={index}
                    className="bg-[#8B4769]/5 rounded-xl p-4 text-[#8B4769]"
                  >
                    {item}
                  </div>
                ))}
                <div className="text-right">
                  <Button
                    onClick={handleStartEditing}
                    variant="outline"
                    className="border-[#8B4769] text-[#8B4769] hover:bg-[#8B4769]/10"
                  >
                    Edit Today's Entry
                  </Button>
                </div>
              </div>
            ) : (
              <>
                <div className="font-semibold mb-4 text-[#8B4769]">
                  {todayExistingEntry ? 'Update your gratitude for today:' : 'What are you grateful for today?'}
                </div>
                {todayEntry.map((item, index) => (
                  <div key={index} className="mb-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-[#8B4769]/70">Gratitude {index + 1}</span>
                      {gratitudeWordLimit > 0 && (
                        <span className="text-xs text-[#8B4769]/50">
                          {wordCounts[index]} words
                        </span>
                      )}
                    </div>
                    <input
                      type="text"
                      value={item}
                      onChange={(e) => handleItemChange(index, e.target.value)}
                      placeholder={`Gratitude ${index + 1}`}
                      className={`w-full px-4 py-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50 ${
                        isAtWordLimit ? 'border-red-300' : ''
                      }`}
                    />
                  </div>
                ))}
                
                {isAtWordLimit && (
                  <div className="bg-red-50 border border-red-200 p-3 rounded-lg mb-4">
                    <div className="text-red-600 text-sm font-medium">
                      Word limit reached ({gratitudeWordLimit} words). Please reduce your content to continue.
                    </div>
                  </div>
                )}
                
                <div className="flex justify-between items-center mt-6">
                  <Button
                    variant="ghost"
                    onClick={handleAddMore}
                    disabled={isAtWordLimit}
                    className="text-[#8B4769] hover:bg-[#8B4769]/10"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add more
                  </Button>
                  <div className="flex gap-2">
                    {todayExistingEntry && (
                      <Button
                        variant="outline"
                        onClick={() => setIsEditing(true)}
                        className="border-[#8B4769] text-[#8B4769] hover:bg-[#8B4769]/10"
                      >
                        Cancel
                      </Button>
                    )}
                    <Button
                      onClick={handleSave}
                      className="bg-[#8B4769] text-white hover:bg-[#96536F]"
                      disabled={!todayEntry.some(entry => entry.trim() !== '') || !user?.id || isAtWordLimit}
                    >
                      {todayExistingEntry ? 'Update' : 'Save'}
                    </Button>
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {selectedEntry ? (
          <div className="bg-white/80 shadow-lg rounded-2xl p-6 border-2 border-[#8B4769]/20">
            <div className="flex justify-between items-center mb-4">
              <div className="text-[#8B4769] font-semibold">
                {format(new Date(selectedEntry.created_at), 'dd MMM yyyy')}
              </div>
              <Button
                variant="ghost"
                onClick={() => setSelectedEntry(null)}
                className="text-[#8B4769]"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </div>
            <div className="space-y-3">
              {parseGratitudeContent(selectedEntry.content).gratitude.map((item, index) => (
                <div
                  key={index}
                  className="bg-[#8B4769]/5 rounded-xl p-4 text-[#8B4769]"
                >
                  {item}
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {entries
              .filter(entry => {
                // Don't show today's entry in the list since it's shown above
                const today = format(new Date(), 'yyyy-MM-dd');
                const entryDate = format(new Date(entry.created_at), 'yyyy-MM-dd');
                return entryDate !== today;
              })
              .map((entry, idx) => (
                <motion.div
                  key={entry.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: idx * 0.1 }}
                  className="bg-white/80 shadow-lg rounded-2xl p-4 flex justify-between items-center border-2 border-[#8B4769]/20"
                >
                  <div className="text-[#8B4769] font-medium">
                    {format(new Date(entry.created_at), 'dd MMM yyyy')}
                  </div>
                  <Button
                    variant="ghost"
                    onClick={() => setSelectedEntry(entry)}
                    className="text-[#8B4769]"
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    View
                  </Button>
                </motion.div>
              ))}
          </div>
        )}

        {/* Upgrade Dialog */}
        <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
          <DialogContent className="w-[95vw] max-w-[400px] bg-white rounded-3xl p-6">
            <DialogHeader>
              <DialogTitle className="text-center text-xl font-semibold text-[#8B4769] mb-3">Upgrade Required</DialogTitle>
            </DialogHeader>
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lock className="w-8 h-8 text-white" />
              </div>
              <p className="text-[#8B4769]/80 mb-6">
                You've reached your gratitude limit of {gratitudeLimit} days. Upgrade to Velory Plus for 20 days or Pro for unlimited.
              </p>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setShowUpgradeDialog(false)}
                  className="flex-1 border-[#8B4769] text-[#8B4769]"
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    setShowUpgradeDialog(false);
                    navigate('/subscription');
                  }}
                  className="flex-1 bg-[#8B4769] text-white hover:bg-[#96536F]"
                >
                  <Crown className="w-4 h-4 mr-2" />
                  Upgrade
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};