import React, { useState, useRef } from 'react';
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { Checkbox } from "../../components/ui/checkbox";
import { motion } from "framer-motion";
import { 
  Download, 
  Upload, 
  HardDrive, 
  CheckCircle, 
  AlertCircle, 
  X,
  FileText,
  User,
  Target,
  Bookmark,
  Trophy,
  Heart
} from 'lucide-react';
import { useBackup } from '../../hooks/useBackup';

interface BackupRestoreProps {
  onClose: () => void;
}

export const BackupRestore: React.FC<BackupRestoreProps> = ({ onClose }) => {
  const {
    loading,
    error,
    createAndSaveBackup,
    restoreFromFile,
    clearError
  } = useBackup();

  const [showBackupOptions, setShowBackupOptions] = useState(false);
  const [restoreResult, setRestoreResult] = useState<any>(null);
  
  const [backupOptions, setBackupOptions] = useState({
    includeProfile: true,
    includeTasks: true,
    includeMoods: true,
    includeWriteups: true,
    includeTrackers: true,
    includeAchievements: true
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleCreateBackup = async () => {
    try {
      await createAndSaveBackup(backupOptions);
      setShowBackupOptions(false);
      alert('Backup saved to your device successfully!');
    } catch (error) {
      console.error('Backup error:', error);
      alert(`Failed to create backup: ${error.message}`);
    }
  };

  const handleRestoreFromFile = async (file: File) => {
    try {
      const result = await restoreFromFile(file);
      setRestoreResult(result);
    } catch (error) {
      console.error('Restore error:', error);
      alert(`Failed to restore: ${error.message}`);
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      handleRestoreFromFile(file);
    }
  };

  const dataTypes = [
    { key: 'profile', label: 'Profile', icon: User, description: 'Username, bio, avatar' },
    { key: 'tasks', label: 'Tasks', icon: CheckCircle, description: 'All your tasks and deadlines' },
    { key: 'moods', label: 'Moods', icon: Heart, description: 'Daily mood entries' },
    { key: 'writeups', label: 'Writeups', icon: FileText, description: 'Journal, goals, creative writing' },
    { key: 'trackers', label: 'Trackers', icon: Bookmark, description: 'Media trackers and progress' },
    { key: 'achievements', label: 'Achievements', icon: Trophy, description: 'Personal achievements' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-[#8B4769]">Backup & Restore</h2>
        <Button variant="ghost" onClick={onClose} className="text-[#8B4769]">
          <X className="w-5 h-5" />
        </Button>
      </div>

      {/* Error Display */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-red-600" />
          <span className="text-red-700 flex-1">{error}</span>
          <Button variant="ghost" size="sm" onClick={clearError} className="text-red-600">
            <X className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* Local Backup Section */}
      <div className="bg-white/80 rounded-2xl p-6 border-2 border-[#8B4769]/20">
        <div className="flex items-center gap-3 mb-4">
          <HardDrive className="w-6 h-6 text-gray-600" />
          <h3 className="text-lg font-semibold text-[#8B4769]">Local Backup</h3>
        </div>

        <p className="text-[#8B4769]/80 mb-6">
          Create a backup file on your device to save all your data. You can restore this backup later or transfer it to another device.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Button
            onClick={() => setShowBackupOptions(true)}
            disabled={loading}
            className="bg-[#8B4769] text-white hover:bg-[#96536F] h-auto py-4"
          >
            <Download className="w-5 h-5 mr-3" />
            <div className="text-left">
              <div className="font-medium">Create Backup</div>
              <div className="text-xs opacity-80">Download backup file</div>
            </div>
          </Button>

          <Button
            onClick={() => fileInputRef.current?.click()}
            disabled={loading}
            variant="outline"
            className="border-[#8B4769] text-[#8B4769] h-auto py-4"
          >
            <Upload className="w-5 h-5 mr-3" />
            <div className="text-left">
              <div className="font-medium">Restore Backup</div>
              <div className="text-xs opacity-80">Upload backup file</div>
            </div>
          </Button>
        </div>

        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileSelect}
          accept=".json"
          className="hidden"
        />

        <div className="mt-6 bg-blue-50 p-4 rounded-lg border border-blue-200">
          <h4 className="font-medium text-blue-800 mb-2">💡 Backup Tips:</h4>
          <ul className="text-sm text-blue-700 space-y-1">
            <li>• Create regular backups to keep your data safe</li>
            <li>• Store backup files in a secure location (cloud storage, external drive)</li>
            <li>• Backup files contain all your personal data - keep them private</li>
            <li>• You can restore backups on any device with Velory</li>
          </ul>
        </div>
      </div>

      {/* Backup Options Dialog */}
      <Dialog open={showBackupOptions} onOpenChange={setShowBackupOptions}>
        <DialogContent className="w-[95vw] max-w-[450px] max-h-[85vh] overflow-y-auto bg-[#FEE2E2]/95">
          <DialogHeader>
            <DialogTitle className="text-[#8B4769]">Backup Options</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <p className="text-[#8B4769]/80 text-sm">Select what data to include in your backup:</p>
            
            <div className="space-y-2">
              {dataTypes.map(({ key, label, icon: Icon, description }) => (
                <div key={key} className="flex items-start gap-3 p-2 bg-white/50 rounded-lg">
                  <Checkbox
                    checked={backupOptions[key as keyof typeof backupOptions]}
                    onCheckedChange={(checked) => 
                      setBackupOptions(prev => ({ ...prev, [key]: !!checked }))
                    }
                    className="mt-1"
                  />
                  <Icon className="w-4 h-4 text-[#8B4769] mt-0.5 flex-shrink-0" />
                  <div className="min-w-0">
                    <div className="font-medium text-[#8B4769] text-sm">{label}</div>
                    <div className="text-xs text-[#8B4769]/70">{description}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200">
              <p className="text-yellow-800 text-xs">
                <strong>Note:</strong> The backup file will be downloaded to your device's default download folder.
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowBackupOptions(false)}
              className="border-[#8B4769] text-[#8B4769]"
            >
              Cancel
            </Button>
            <Button
              onClick={handleCreateBackup}
              disabled={loading}
              className="bg-[#8B4769] text-white hover:bg-[#96536F]"
            >
              <Download className="w-4 h-4 mr-2" />
              {loading ? 'Creating...' : 'Create Backup'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Restore Result Dialog */}
      {restoreResult && (
        <Dialog open={!!restoreResult} onOpenChange={() => setRestoreResult(null)}>
          <DialogContent className="w-[95vw] max-w-[450px] max-h-[85vh] overflow-y-auto bg-[#FEE2E2]/95">
            <DialogHeader>
              <DialogTitle className="text-[#8B4769] flex items-center gap-2">
                {restoreResult.success ? (
                  <CheckCircle className="w-5 h-5 text-green-600" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-red-600" />
                )}
                Restore {restoreResult.success ? 'Completed' : 'Failed'}
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-4">
              {restoreResult.restored.length > 0 && (
                <div>
                  <h4 className="font-medium text-green-700 mb-2">Successfully Restored:</h4>
                  <ul className="list-disc list-inside space-y-1">
                    {restoreResult.restored.map((item: string, index: number) => (
                      <li key={index} className="text-green-600 text-sm">{item}</li>
                    ))}
                  </ul>
                </div>
              )}

              {restoreResult.errors.length > 0 && (
                <div>
                  <h4 className="font-medium text-red-700 mb-2">Errors:</h4>
                  <ul className="list-disc list-inside space-y-1">
                    {restoreResult.errors.map((error: string, index: number) => (
                      <li key={index} className="text-red-600 text-sm">{error}</li>
                    ))}
                  </ul>
                </div>
              )}

              {restoreResult.success && (
                <div className="bg-green-50 p-3 rounded-lg border border-green-200">
                  <p className="text-green-800 text-sm">
                    Your data has been restored successfully! You may need to refresh the page to see all changes.
                  </p>
                </div>
              )}
            </div>

            <DialogFooter>
              <Button
                onClick={() => {
                  setRestoreResult(null);
                  if (restoreResult.success) {
                    window.location.reload();
                  }
                }}
                className="bg-[#8B4769] text-white hover:bg-[#96536F]"
              >
                {restoreResult.success ? 'Refresh Page' : 'Close'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};