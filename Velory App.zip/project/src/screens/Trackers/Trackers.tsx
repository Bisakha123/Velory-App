import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../../components/ui/dropdown-menu";
import { ArrowLeft, Upload, Link as LinkIcon, Pencil, Trash2, MoreVertical, X, Crown, Lock } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { MediaTracker } from "./MediaTracker";
import { mediaApi, type Tracker } from '../../lib/api';
import { useAuthContext } from '../../components/AuthProvider';
import { useSubscription } from '../../hooks/useSubscription';
import { SubscriptionGate } from '../../components/SubscriptionGate';

export const Trackers = (): JSX.Element => {
  const navigate = useNavigate();
  const { user } = useAuthContext();
  const { canUseMediaTrackers, isFree, isPro, checkLimit, incrementUsage, getLimit, getCurrentCount } = useSubscription();
  const [trackers, setTrackers] = useState<Tracker[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingTracker, setEditingTracker] = useState<Tracker | null>(null);
  const [newName, setNewName] = useState("");
  const [newImage, setNewImage] = useState<string | undefined>(undefined);
  const [contentType, setContentType] = useState<'watching' | 'reading'>('watching');
  const [imageTab, setImageTab] = useState<"upload" | "url">("upload");
  const [selectedTracker, setSelectedTracker] = useState<Tracker | null>(null);
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [upgradeMessage, setUpgradeMessage] = useState('');
  const [mediaItemsCount, setMediaItemsCount] = useState(0);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (user) {
      loadTrackers();
      loadMediaItemsCount();
    }
  }, [user]);

  const loadTrackers = async () => {
    try {
      setLoading(true);
      const data = await mediaApi.getTrackers();
      setTrackers(data);
    } catch (error) {
      console.error('Error loading trackers:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadMediaItemsCount = async () => {
    try {
      const count = await getCurrentCount('media_trackers');
      setMediaItemsCount(count);
    } catch (error) {
      console.error('Error loading media items count:', error);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const canCreateCustomTracker = async () => {
    // Pro users can create unlimited custom trackers
    if (isPro()) {
      return true;
    }
    
    // Plus and Free users cannot create custom trackers
    setUpgradeMessage("Custom trackers are available with Velory Pro only. Upgrade to create unlimited custom trackers for any content type!");
    setShowUpgradeDialog(true);
    return false;
  };

  const canAddMediaItem = async () => {
    const canCreate = await checkLimit('media_trackers');
    if (!canCreate) {
      const limit = getLimit('media_trackers');
      setUpgradeMessage(`You've reached your media tracking limit of ${limit} items. Upgrade to Pro for unlimited tracking!`);
      setShowUpgradeDialog(true);
      return false;
    }
    return true;
  };

  const handleAddTracker = async () => {
    if (!newName.trim() || !user?.id) return;
    
    // Check if user can create custom trackers (only for editing existing trackers, new ones need limit check)
    if (!editingTracker) {
      const canCreate = await canCreateCustomTracker();
      if (!canCreate) return;
    }
    
    try {
      const trackerType = contentType === 'watching' ? 'show' : 'book';
      const trackerData = {
        name: newName.trim(),
        type: trackerType as 'show' | 'book',
        image_url: newImage,
        user_id: user.id
      };

      if (editingTracker) {
        await mediaApi.updateTracker(editingTracker.id, trackerData);
      } else {
        await mediaApi.createTracker(trackerData);
        // Only increment usage for Pro users (since they're the only ones who can create custom trackers)
        if (isPro()) {
          await incrementUsage('custom_trackers');
        }
      }
      
      await loadTrackers(); // Refresh the list
      handleCloseDialog();
    } catch (error) {
      console.error('Error saving tracker:', error);
    }
  };

  const handleCloseDialog = () => {
    setNewName("");
    setNewImage(undefined);
    setContentType('watching');
    setImageTab("upload");
    setEditingTracker(null);
    setDialogOpen(false);
  };

  const handleEdit = (tracker: Tracker) => {
    setEditingTracker(tracker);
    setNewName(tracker.name);
    setNewImage(tracker.image_url || undefined);
    setContentType(tracker.type === 'show' ? 'watching' : 'reading');
    setDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    try {
      await mediaApi.deleteTracker(id);
      await loadTrackers(); // Refresh the list
    } catch (error) {
      console.error('Error deleting tracker:', error);
    }
  };

  const handleNewTracker = async () => {
    const canCreate = await canCreateCustomTracker();
    if (canCreate) {
      // Reset all form fields for a fresh tracker
      setEditingTracker(null);
      setNewName("");
      setNewImage(undefined);
      setContentType('watching');
      setImageTab("upload");
      setDialogOpen(true);
    }
  };

  const handleBuiltInTrackerClick = async (trackerType: 'show' | 'book') => {
    if (!canUseMediaTrackers()) {
      setUpgradeMessage("Media trackers are available with Velory Plus and Pro. Track your favorite books and shows!");
      setShowUpgradeDialog(true);
      return;
    }

    // Check if user can add more media items
    const canAdd = await canAddMediaItem();
    if (!canAdd) return;

    const trackerData = {
      id: trackerType === 'show' ? 'tv-shows' : 'books',
      name: trackerType === 'show' ? "TV Shows" : "Books",
      type: trackerType,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      user_id: user?.id || ''
    };
    setSelectedTracker(trackerData);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FEE2E2] flex items-center justify-center">
        <div className="text-[#8B4769] text-xl font-semibold">Loading trackers...</div>
      </div>
    );
  }

  // Show subscription gate for free users
  if (isFree()) {
    return (
      <div 
        className="min-h-screen bg-[#FEE2E2] overflow-hidden"
        style={{ 
          backgroundImage: 'url("https://res.cloudinary.com/db6un9uvp/image/upload/v1745907531/Trackers_bg_fksow9.png")',
          backgroundBlendMode: 'multiply',
          backgroundColor: 'rgba(0, 0, 0, 0.2)'
        }}
      >
        <div className="h-full max-w-4xl mx-auto px-4 py-6 font-['Quicksand']">
          <div className="flex items-center justify-between mb-8">
            <Button 
              variant="ghost" 
              onClick={() => navigate(-1)}
              className="text-[#8B4769] -ml-3 font-bold text-xl"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <h1 className="text-2xl font-bold text-[#8B4769]">Trackers</h1>
            <Button 
              variant="ghost" 
              onClick={() => navigate("/subscription", { state: { fromNavigation: true } })}
              className="text-[#8B4769]"
            >
              <Crown className="w-6 h-6" />
            </Button>
          </div>

          <div className="flex items-center justify-center min-h-[60vh]">
            <SubscriptionGate
              feature="media_trackers"
              requiredPlan="plus"
              showUpgrade={true}
            >
              {/* This won't render for free users */}
            </SubscriptionGate>
          </div>
        </div>
      </div>
    );
  }

  if (selectedTracker) {
    return (
      <div>
        <div className="fixed top-0 left-0 right-0 bg-[#FEE2E2] z-10 p-4">
          <div className="flex items-center justify-between">
            <Button 
              variant="ghost" 
              onClick={() => setSelectedTracker(null)}
              className="text-[#8B4769] -ml-3 font-bold"
            >
              <ArrowLeft className="w-6 h-6" />
              <span className="ml-2">Back to Trackers</span>
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => navigate("/subscription", { state: { fromNavigation: true } })}
              className="text-[#8B4769]"
            >
              <Crown className="w-6 h-6" />
            </Button>
          </div>
        </div>
        <div className="pt-16">
          <MediaTracker 
            trackerId={selectedTracker.id}
            trackerName={selectedTracker.name}
            type={selectedTracker.type === 'custom' ? 'show' : selectedTracker.type} 
          />
        </div>
      </div>
    );
  }

  const mediaTrackersLimit = getLimit('media_trackers');

  return (
    <div 
      className="min-h-screen bg-[#FEE2E2] overflow-hidden"
      style={{ 
        backgroundImage: 'url("https://res.cloudinary.com/db6un9uvp/image/upload/v1745907531/Trackers_bg_fksow9.png")',
        backgroundBlendMode: 'multiply',
        backgroundColor: 'rgba(0, 0, 0, 0.2)'
      }}
    >
      <div className="h-full max-w-4xl mx-auto px-4 py-6 font-['Quicksand']">
        <div className="flex items-center justify-between mb-8">
          <Button 
            variant="ghost" 
            onClick={() => navigate(-1)}
            className="text-[#8B4769] -ml-3 font-bold text-xl"
          >
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <h1 className="text-2xl font-bold text-[#8B4769]">Trackers</h1>
          <Button 
            variant="ghost" 
            onClick={() => navigate("/subscription", { state: { fromNavigation: true } })}
            className="text-[#8B4769]"
          >
            <Crown className="w-6 h-6" />
          </Button>
        </div>

        {/* Usage limit display for media trackers */}
        {mediaTrackersLimit !== -1 && (
          <div className="mb-6">
            <div className="bg-white/80 rounded-xl p-4 border-2 border-[#8B4769]/20">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-[#8B4769]">Media Items</span>
                <span className="text-sm text-[#8B4769]/70">
                  {mediaItemsCount} / {mediaTrackersLimit} items
                </span>
              </div>
              <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-300 ${
                    mediaItemsCount >= mediaTrackersLimit ? 'bg-red-500' : 'bg-green-500'
                  }`}
                  style={{ width: `${Math.min((mediaItemsCount / mediaTrackersLimit) * 100, 100)}%` }}
                />
              </div>
              {mediaItemsCount >= mediaTrackersLimit && (
                <div className="text-center mt-2">
                  <p className="text-sm text-red-600 mb-2">Media tracking limit reached</p>
                  <Button
                    size="sm"
                    onClick={() => navigate('/subscription')}
                    className="bg-[#8B4769] text-white hover:bg-[#96536F]"
                  >
                    <Crown className="w-3 h-3 mr-1" />
                    Upgrade for Unlimited
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Custom trackers info for Pro users */}
        {isPro() && (
          <div className="mb-6">
            <div className="bg-purple-50/80 rounded-xl p-4 border-2 border-purple-200">
              <div className="text-sm text-purple-800">
                <strong>🎉 Pro Feature:</strong> You can create unlimited custom trackers for any content type! Click the + button to create your own tracker.
              </div>
            </div>
          </div>
        )}

        {/* Custom trackers info for Plus users */}
        {!isPro() && !isFree() && (
          <div className="mb-6">
            <div className="bg-blue-50/80 rounded-xl p-4 border-2 border-blue-200">
              <div className="text-sm text-blue-800">
                <strong>Plus Feature:</strong> You have access to built-in TV Shows and Books trackers. Upgrade to Pro for unlimited custom trackers!
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Built-in TV Shows Tracker */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
            onClick={() => handleBuiltInTrackerClick('show')}
            className="cursor-pointer"
          >
            <div className="relative overflow-hidden rounded-2xl h-40 bg-[#8B4769]/10 backdrop-blur shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="h-full flex items-center justify-center text-lg font-semibold text-[#8B4769] p-4">
                <span className="bg-[#8B4769]/10 backdrop-blur px-4 py-2 rounded-xl shadow-md">
                  TV Shows
                </span>
              </div>
            </div>
          </motion.div>

          {/* Built-in Books Tracker */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: 0.1 }}
            onClick={() => handleBuiltInTrackerClick('book')}
            className="cursor-pointer"
          >
            <div className="relative overflow-hidden rounded-2xl h-40 bg-[#8B4769]/10 backdrop-blur shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="h-full flex items-center justify-center text-lg font-semibold text-[#8B4769] p-4">
                <span className="bg-[#8B4769]/10 backdrop-blur px-4 py-2 rounded-xl shadow-md">
                  Books
                </span>
              </div>
            </div>
          </motion.div>

          {/* Custom Trackers */}
          {trackers.map((tracker) => (
            <motion.div
              key={tracker.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
              onClick={() => setSelectedTracker(tracker)}
              className="cursor-pointer"
            >
              <div className="relative overflow-hidden rounded-2xl h-40 bg-[#8B4769]/10 backdrop-blur shadow-lg hover:shadow-xl transition-all duration-300">
                <div
                  className="h-full flex items-center justify-center text-lg font-semibold text-[#8B4769] bg-cover bg-center p-4"
                  style={{
                    backgroundImage: tracker.image_url ? `url(${tracker.image_url})` : undefined,
                  }}
                >
                  <div className="absolute top-2 right-2" onClick={e => e.stopPropagation()}>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="text-[#8B4769] hover:bg-white/20"
                        >
                          <MoreVertical className="w-5 h-5" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem onClick={() => handleEdit(tracker)}>
                          <Pencil className="w-4 h-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleDelete(tracker.id)}
                          className="text-red-600"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                  <span className="bg-[#8B4769]/10 backdrop-blur px-4 py-2 rounded-xl shadow-md">
                    {tracker.name}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Only show + button for Pro users */}
        {isPro() && (
          <Button
            onClick={handleNewTracker}
            className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-[#8B4769] hover:bg-[#96536F] shadow-lg"
          >
            +
          </Button>
        )}

        {/* Upgrade Dialog */}
        <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
          <DialogContent className="w-[95vw] max-w-[400px] bg-white rounded-3xl p-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lock className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-[#8B4769] mb-3">Upgrade Required</h3>
              <p className="text-[#8B4769]/80 mb-6">
                {upgradeMessage}
              </p>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setShowUpgradeDialog(false)}
                  className="flex-1 border-[#8B4769] text-[#8B4769]"
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    setShowUpgradeDialog(false);
                    navigate('/subscription');
                  }}
                  className="flex-1 bg-[#8B4769] text-white hover:bg-[#96536F]"
                >
                  <Crown className="w-4 h-4 mr-2" />
                  Upgrade
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={dialogOpen} onOpenChange={handleCloseDialog}>
          <DialogContent className="sm:max-w-[90vw] md:max-w-[500px] max-h-[90vh] overflow-y-auto bg-[#FEE2E2] rounded-3xl">
            <DialogHeader>
              <DialogTitle className="text-2xl font-semibold text-[#8B4769]">
                {editingTracker ? 'Edit Tracker' : 'Add New Tracker'}
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <input
                type="text"
                placeholder="Tracker name"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="w-full p-3 rounded-xl border border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
              />

              <div>
                <label className="block text-sm font-medium mb-2 text-[#8B4769]">Content Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setContentType('watching')}
                    className={`p-3 rounded-xl border-2 text-center font-medium transition-colors ${
                      contentType === 'watching'
                        ? 'bg-[#8B4769] text-white border-[#8B4769]'
                        : 'bg-white/50 text-[#8B4769] border-[#8B4769]/20 hover:bg-[#8B4769]/5'
                    }`}
                  >
                    📺 Watching Type
                    <div className="text-xs mt-1 opacity-80">TV Shows, Movies</div>
                  </button>
                  <button
                    onClick={() => setContentType('reading')}
                    className={`p-3 rounded-xl border-2 text-center font-medium transition-colors ${
                      contentType === 'reading'
                        ? 'bg-[#8B4769] text-white border-[#8B4769]'
                        : 'bg-white/50 text-[#8B4769] border-[#8B4769]/20 hover:bg-[#8B4769]/5'
                    }`}
                  >
                    📚 Reading Type
                    <div className="text-xs mt-1 opacity-80">Books, Novels</div>
                  </button>
                </div>
              </div>

              <Tabs value={imageTab} onValueChange={(value) => setImageTab(value as "upload" | "url")}>
                <TabsList className="w-full rounded-xl bg-[#8B4769]/10">
                  <TabsTrigger value="upload" className="flex-1 text-[#8B4769]">Upload Image</TabsTrigger>
                  <TabsTrigger value="url" className="flex-1 text-[#8B4769]">Image URL</TabsTrigger>
                </TabsList>
                <TabsContent value="upload" className="mt-4">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    ref={fileInputRef}
                    className="hidden"
                  />
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full h-24 rounded-xl border-2 border-dashed border-[#8B4769]/30 flex flex-col items-center justify-center gap-2 hover:border-[#8B4769] hover:bg-[#8B4769]/5 bg-white/50"
                  >
                    <Upload className="w-6 h-6 text-[#8B4769]/60" />
                    <span className="text-sm text-[#8B4769]/60">Click to upload image</span>
                  </Button>
                </TabsContent>
                <TabsContent value="url" className="mt-4">
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <LinkIcon className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-[#8B4769]/60" />
                      <input
                        type="url"
                        placeholder="Paste image URL"
                        value={newImage || ""}
                        onChange={(e) => setNewImage(e.target.value)}
                        className="w-full pl-10 p-3 rounded-xl border border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
                      />
                    </div>
                  </div>
                </TabsContent>
              </Tabs>

              {newImage && (
                <div className="relative w-full h-24 rounded-xl overflow-hidden">
                  <img
                    src={newImage}
                    alt="Preview"
                    className="w-full h-full object-cover"
                  />
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => setNewImage(undefined)}
                    className="absolute top-2 right-2 bg-white/80 hover:bg-white"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              )}
            </div>

            <DialogFooter>
              <Button
                variant="outline"
                onClick={handleCloseDialog}
                className="flex-1 border-[#8B4769]/20 text-[#8B4769]"
              >
                Cancel
              </Button>
              <Button
                onClick={handleAddTracker}
                disabled={!newName.trim() || !user?.id}
                className="flex-1 bg-[#8B4769] text-white hover:bg-[#96536F]"
              >
                {editingTracker ? 'Save Changes' : 'Add Tracker'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};