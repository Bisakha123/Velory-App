import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { motion } from "framer-motion";
import { ArrowLeft, Pencil, Crown, Lock, X, Plus, Trash2, ChevronRight, TrendingUp, Target, Settings, Calendar, BarChart3 } from 'lucide-react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isToday, subDays, isSameDay, startOfDay, isWithinInterval, differenceInDays, startOfYear, endOfYear } from 'date-fns';
import { useProfile } from '../../hooks/useProfile';
import { useSubscription } from '../../hooks/useSubscription';
import { achievementsApi, tasksApi, writeupsApi, type Achievement, type Task, type Writeup } from '../../lib/api';
import { useAuthContext } from '../../components/AuthProvider';

interface TaskCompletion {
  date: string;
  completed: number;
  total: number;
  hasActiveTasks: boolean;
}

interface GoalCompletion {
  month: string;
  completed: number;
  total: number;
  year: number;
}

interface StreakInfo {
  currentStreak: number;
  longestStreak: number;
  lastActiveDate: string | null;
}

export const Profile = () => {
  const navigate = useNavigate();
  const { user } = useAuthContext();
  const { profile, loading: profileLoading, updateProfile, uploadAvatar } = useProfile();
  const { subscriptionData, loading: subscriptionLoading, canUseAnalytics, canUploadAvatar, canUseGoalsAnalytics } = useSubscription();
  const fileInputRef = React.useRef<HTMLInputElement>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showAchievementDialog, setShowAchievementDialog] = useState(false);
  const [showStatsDialog, setShowStatsDialog] = useState(false);
  const [statsType, setStatsType] = useState<'improvement' | 'monthly'>('improvement');
  const [editingAchievement, setEditingAchievement] = useState<Achievement | null>(null);
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  
  const [editProfile, setEditProfile] = useState({
    username: '',
    bio: ''
  });

  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [newAchievement, setNewAchievement] = useState({
    title: '',
    description: '',
    icon: '🏆'
  });

  const [tasks, setTasks] = useState<Task[]>([]);
  const [goals, setGoals] = useState<Writeup[]>([]);
  const [taskCompletions, setTaskCompletions] = useState<TaskCompletion[]>([]);
  const [goalCompletions, setGoalCompletions] = useState<GoalCompletion[]>([]);
  const [streakInfo, setStreakInfo] = useState<StreakInfo>({
    currentStreak: 0,
    longestStreak: 0,
    lastActiveDate: null
  });
  const [loading, setLoading] = useState(true);
  const [analyticsLoaded, setAnalyticsLoaded] = useState(false);

  const achievementIcons = ['🏆', '⭐', '🎯', '💪', '🌟', '🎉', '🔥', '💎', '🚀', '🎊', '🏅', '👑'];

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  useEffect(() => {
    if (profile) {
      setEditProfile({
        username: profile.username || '',
        bio: profile.bio || ''
      });
    }
  }, [profile]);

  // Separate effect for analytics to ensure they load properly
  useEffect(() => {
    if (tasks.length > 0 && goals.length > 0 && !analyticsLoaded) {
      console.log('Loading analytics with data:', { tasksCount: tasks.length, goalsCount: goals.length });
      
      if (canUseAnalytics()) {
        console.log('User can access analytics, calculating task analytics...');
        calculateTaskCompletions(tasks);
        calculateStreakInfo(tasks);
      }
      
      if (canUseGoalsAnalytics()) {
        console.log('User can access goals analytics, calculating goal analytics...');
        calculateGoalCompletions(goals);
      }
      
      setAnalyticsLoaded(true);
    }
  }, [tasks, goals, canUseAnalytics, canUseGoalsAnalytics, analyticsLoaded]);

  const loadData = async () => {
    try {
      setLoading(true);
      setAnalyticsLoaded(false); // Reset analytics loaded state
      
      console.log('Loading profile data...');
      const [achievementsData, tasksData, goalsData] = await Promise.all([
        achievementsApi.getAchievements(),
        tasksApi.getTasks(),
        writeupsApi.getWriteups('goals')
      ]);
      
      console.log('Data loaded:', { 
        achievements: achievementsData.length, 
        tasks: tasksData.length, 
        goals: goalsData.length 
      });
      
      setAchievements(achievementsData);
      setTasks(tasksData);
      setGoals(goalsData);
      
    } catch (error) {
      console.error('Error loading profile data:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateTaskCompletions = (allTasks: Task[]) => {
    console.log('Calculating task completions for', allTasks.length, 'tasks');
    const completions: TaskCompletion[] = [];
    const today = new Date();
    
    // Calculate for the last 30 days (day-wise analytics)
    for (let i = 29; i >= 0; i--) {
      const date = subDays(today, i);
      const dateStr = format(date, 'yyyy-MM-dd');
      
      // Get tasks that existed on this date (created on or before this date)
      const availableTasks = allTasks.filter(task => 
        new Date(task.created_at) <= date
      );
      
      // Get tasks completed on this date
      const completedTasks = allTasks.filter(task => 
        task.completed_at && isSameDay(new Date(task.completed_at), date)
      );
      
      // Check if there were any active (non-completed) tasks on this date
      const activeTasks = availableTasks.filter(task => 
        !task.completed_at || new Date(task.completed_at) > date
      );
      
      completions.push({
        date: dateStr,
        completed: completedTasks.length,
        total: availableTasks.length,
        hasActiveTasks: activeTasks.length > 0
      });
    }
    
    console.log('Task completions calculated:', completions.length, 'days');
    setTaskCompletions(completions);
  };

  const calculateGoalCompletions = (allGoals: Writeup[]) => {
    console.log('Calculating goal completions for', allGoals.length, 'goals');
    const completions: GoalCompletion[] = [];
    const currentYear = new Date().getFullYear();
    
    // Calculate for each month of the current year (yearly analytics with monthly breakdown)
    for (let month = 0; month < 12; month++) {
      const monthStart = new Date(currentYear, month, 1);
      const monthEnd = endOfMonth(monthStart);
      const monthStr = format(monthStart, 'MMM');
      
      // Get goals completed in this month (based on metadata.completed flag)
      const completedGoals = allGoals.filter(goal => 
        goal.metadata?.completed === true && 
        goal.updated_at && 
        isWithinInterval(new Date(goal.updated_at), { start: monthStart, end: monthEnd })
      );
      
      // Get total goals that existed during this month
      const totalGoals = allGoals.filter(goal => 
        new Date(goal.created_at) <= monthEnd
      );
      
      completions.push({
        month: monthStr,
        completed: completedGoals.length,
        total: totalGoals.length,
        year: currentYear
      });
    }
    
    console.log('Goal completions calculated:', completions.length, 'months');
    setGoalCompletions(completions);
  };

  const calculateStreakInfo = (allTasks: Task[]) => {
    console.log('Calculating streak info for', allTasks.length, 'tasks');
    
    if (!allTasks || allTasks.length === 0) {
      setStreakInfo({
        currentStreak: 0,
        longestStreak: 0,
        lastActiveDate: null
      });
      return;
    }

    const today = new Date();
    let currentStreak = 0;
    let longestStreak = 0;
    let tempStreak = 0;
    
    // Check the last 30 days for streaks
    for (let i = 0; i < 30; i++) {
      const checkDate = subDays(today, i);
      const dateStr = format(checkDate, 'yyyy-MM-dd');
      
      // Get tasks completed on this specific date
      const completedOnDate = allTasks.filter(task => 
        task.completed_at && 
        format(new Date(task.completed_at), 'yyyy-MM-dd') === dateStr
      );
      
      // Get tasks that existed on this date (created before or on this date)
      const availableOnDate = allTasks.filter(task => 
        format(new Date(task.created_at), 'yyyy-MM-dd') <= dateStr
      );
      
      // If there were tasks available and some were completed
      if (availableOnDate.length > 0 && completedOnDate.length > 0) {
        tempStreak++;
        if (i === 0) { // Today
          currentStreak = tempStreak;
        }
      } else if (availableOnDate.length > 0) {
        // Tasks available but none completed - break streak
        longestStreak = Math.max(longestStreak, tempStreak);
        if (i === 0) { // Today
          currentStreak = 0;
        }
        tempStreak = 0;
      }
      // If no tasks available, don't break streak (continue)
    }
    
    // Final check for longest streak
    longestStreak = Math.max(longestStreak, tempStreak);
    
    console.log('Streak calculated:', { currentStreak, longestStreak });
    setStreakInfo({
      currentStreak,
      longestStreak,
      lastActiveDate: null
    });
  };

  const handleAvatarChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!canUploadAvatar()) {
      setShowUpgradeDialog(true);
      return;
    }

    const file = event.target.files?.[0];
    if (file) {
      try {
        await uploadAvatar(file);
      } catch (error) {
        console.error('Error uploading avatar:', error);
      }
    }
  };

  const handleDeleteAvatar = async () => {
    try {
      await updateProfile({ 
        avatar_url: 'https://res.cloudinary.com/db6un9uvp/image/upload/v1745916296/default_avatar_kq7bxn.png' 
      });
    } catch (error) {
      console.error('Error deleting avatar:', error);
    }
  };

  const handleSaveProfile = async () => {
    try {
      await updateProfile(editProfile);
      setShowEditDialog(false);
    } catch (error) {
      console.error('Error saving profile:', error);
    }
  };

  const handleSaveAchievement = async () => {
    if (!newAchievement.title.trim() || !user?.id) return;

    try {
      const achievementData = {
        ...newAchievement,
        user_id: user.id
      
      };

      if (editingAchievement) {
        await achievementsApi.updateAchievement(editingAchievement.id, achievementData);
      } else {
        await achievementsApi.createAchievement(achievementData);
      }

      await loadData(); // Refresh achievements
      setShowAchievementDialog(false);
      setNewAchievement({ title: '', description: '', icon: '🏆' });
      setEditingAchievement(null);
    } catch (error) {
      console.error('Error saving achievement:', error);
    }
  };

  const handleDeleteAchievement = async (id: string) => {
    try {
      await achievementsApi.deleteAchievement(id);
      await loadData(); // Refresh achievements
    } catch (error) {
      console.error('Error deleting achievement:', error);
    }
  };

  const getImprovementDays = () => {
    return taskCompletions.filter(day => day.completed > 0).length;
  };

  const getCurrentYearGoals = () => {
    return goalCompletions.reduce((total, month) => total + month.completed, 0);
  };

  const getTotalTasksCompleted = () => {
    return tasks.filter(task => task.completed).length;
  };

  const getTotalGoalsCompleted = () => {
    // Count goals from writeups that are marked as completed
    return goals.filter(goal => goal.metadata?.completed === true).length;
  };

  const getCompletionRate = (completed: number, total: number) => {
    return total > 0 ? Math.round((completed / total) * 100) : 0;
  };

  const openStatsDialog = (type: 'improvement' | 'monthly') => {
    if (!canUseAnalytics()) {
      setShowUpgradeDialog(true);
      return;
    }
    
    // Check if trying to access goals analytics without Pro
    if (type === 'monthly' && !canUseGoalsAnalytics()) {
      setShowUpgradeDialog(true);
      return;
    }
    
    setStatsType(type);
    setShowStatsDialog(true);
  };

  const hasTaskData = tasks.length > 0;
  const hasCompletedTasks = tasks.some(task => task.completed);
  const hasGoals = goals.length > 0;
  const totalGoalsCompleted = getTotalGoalsCompleted();
  const currentYearGoals = getCurrentYearGoals();

  if (profileLoading || loading || subscriptionLoading) {
    return (
      <div className="min-h-screen bg-[#FEE2E2] flex items-center justify-center">
        <div className="text-[#8B4769] text-xl font-semibold">Loading profile...</div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-cover bg-center p-4 font-['Quicksand']"
      style={{
        backgroundImage: "url('https://res.cloudinary.com/db6un9uvp/image/upload/v1745916296/Autobiography_bg_fyshzv.png')",
        backgroundBlendMode: 'multiply',
        backgroundColor: 'rgba(255, 192, 203, 0.7)'
      }}
    >
      <div className="flex items-center justify-between mb-8">
        <Button 
          variant="ghost" 
          onClick={() => navigate('/')}
          className="text-[#8B4769] -ml-3"
        >
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-4xl font-extrabold text-[#8B4769] mb-2 tracking-wide font-['Indie Flower']">
            Profile
          </h1>
        </motion.div>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            onClick={() => navigate("/subscription")}
            className="text-[#8B4769]"
          >
            <Crown className="w-6 h-6" />
          </Button>
          <Button
            variant="ghost"
            onClick={() => navigate("/settings")}
            className="text-[#8B4769]"
          >
            <Settings className="w-6 h-6" />
          </Button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto space-y-6">
        {/* Profile Section */}
        <motion.div 
          className="bg-white/80 rounded-3xl p-6 text-center relative border-2 border-[#8B4769]/20"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="relative w-32 h-32 mx-auto mb-4">
            <img
              src={profile?.avatar_url || 'https://res.cloudinary.com/db6un9uvp/image/upload/v1745916296/default_avatar_kq7bxn.png'}
              alt="Profile"
              className="w-full h-full rounded-full object-cover border-4 border-[#8B4769]/20"
            />
            <button
              onClick={() => setShowEditDialog(true)}
              className="absolute bottom-0 right-0 bg-[#8B4769] text-white rounded-full p-1.5 hover:bg-[#96536F] transition-colors opacity-70 hover:opacity-100"
            >
              <Pencil className="w-3 h-3" />
            </button>
          </div>
          
          <h2 className="text-2xl font-bold text-[#8B4769] mb-2">{profile?.username || 'User'}</h2>
          <p className="text-[#8B4769]/80 mb-4">{profile?.bio || 'No bio yet'}</p>
        </motion.div>

        {/* Task Analytics - Only show if user has created tasks and can access analytics */}
        {hasTaskData && canUseAnalytics() && (
          <>
            {/* Days of Improvement - Only show if tasks have been completed */}
            {hasCompletedTasks && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="bg-white/80 rounded-3xl p-6 border-2 border-[#8B4769]/20 cursor-pointer hover:bg-white/90 transition-all"
                onClick={() => openStatsDialog('improvement')}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-green-200 rounded-full flex items-center justify-center">
                      <TrendingUp className="w-8 h-8 text-green-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-[#8B4769]">Task Analytics</h3>
                      <p className="text-[#8B4769]/70">
                        {getImprovementDays()} days with completed tasks
                      </p>
                      <div className="flex items-center gap-4 mt-1">
                        <div className="text-sm text-[#8B4769]/60">
                          <span className="font-medium">Total Tasks:</span> {getTotalTasksCompleted()}
                        </div>
                      </div>
                      <div className="flex items-center gap-4 mt-1">
                        <div className="text-sm text-[#8B4769]/60">
                          <span className="font-medium">Current Streak:</span> {streakInfo.currentStreak} days
                        </div>
                        <div className="text-sm text-[#8B4769]/60">
                          <span className="font-medium">Best Streak:</span> {streakInfo.longestStreak} days
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-[#8B4769]/50" />
                    <ChevronRight className="w-6 h-6 text-[#8B4769]/50" />
                  </div>
                </div>
              </motion.div>
            )}
          </>
        )}

        {/* Goals Analytics - Only show for Pro users who have goals and can access goals analytics */}
        {hasGoals && canUseGoalsAnalytics() && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white/80 rounded-3xl p-6 border-2 border-[#8B4769]/20 cursor-pointer hover:bg-white/90 transition-all"
            onClick={() => openStatsDialog('monthly')}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-blue-200 rounded-full flex items-center justify-center">
                  <Target className="w-8 h-8 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-[#8B4769]">Goals Analytics</h3>
                  <p className="text-[#8B4769]/70">
                    {totalGoalsCompleted} of {goals.length} goals completed
                  </p>
                  {currentYearGoals > 0 && (
                    <p className="text-sm text-[#8B4769]/60">
                      {currentYearGoals} completed this year
                    </p>
                  )}
                  <p className="text-sm text-[#8B4769]/60">
                    Yearly breakdown with monthly details
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-[#8B4769]/50" />
                <ChevronRight className="w-6 h-6 text-[#8B4769]/50" />
              </div>
            </div>
          </motion.div>
        )}

        {/* Show message when no analytics available */}
        {(!hasTaskData && !hasGoals) || !canUseAnalytics() ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white/80 rounded-3xl p-6 border-2 border-[#8B4769]/20 text-center"
          >
            <div className="text-[#8B4769]/70">
              {!canUseAnalytics() ? (
                <>
                  <Lock className="w-12 h-12 mx-auto mb-3 text-[#8B4769]/50" />
                  <p className="text-lg font-medium mb-2">Analytics Available with Plus & Pro</p>
                  <p className="text-sm mb-4">Upgrade to see detailed statistics about your tasks progress! Goals analytics available with Pro only.</p>
                  <Button
                    onClick={() => navigate('/subscription')}
                    className="bg-[#8B4769] text-white hover:bg-[#96536F]"
                  >
                    <Crown className="w-4 h-4 mr-2" />
                    Upgrade Now
                  </Button>
                </>
              ) : (
                <>
                  <p className="text-lg font-medium mb-2">No Statistics Yet</p>
                  <p className="text-sm">Create your first task{canUseGoalsAnalytics() ? ' or goal' : ''} to see your progress statistics here!</p>
                </>
              )}
            </div>
          </motion.div>
        ) : null}

        {/* Subscription Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white/80 rounded-3xl p-6 border-2 border-[#8B4769]/20"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-semibold text-[#8B4769] flex items-center gap-2">
              <Crown className="w-5 h-5" />
              Subscription
            </h3>
            <Button
              variant="ghost"
              onClick={() => navigate('/subscription')}
              className="text-[#8B4769]"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-semibold text-[#8B4769]">Current Plan</h4>
                <p className="text-sm text-[#8B4769]/70">
                  {subscriptionData?.plan?.display_name || 'Velory Free'}
                </p>
              </div>
              <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                subscriptionData?.plan?.id === 'pro' 
                  ? 'bg-purple-100 text-purple-600'
                  : subscriptionData?.plan?.id === 'plus'
                  ? 'bg-blue-100 text-blue-600'
                  : 'bg-gray-100 text-gray-600'
              }`}>
                {subscriptionData?.plan?.id === 'free' || !subscriptionData?.plan ? 'Free' : 
                 subscriptionData?.plan?.id === 'plus' ? 'Plus' : 'Pro'}
              </div>
            </div>

            {(!subscriptionData?.plan || subscriptionData?.plan?.id !== 'pro') && (
              <div className="bg-gradient-to-r from-[#8B4769]/10 to-[#96536F]/10 rounded-xl p-4">
                <div className="flex items-center gap-3 mb-2">
                  <Crown className="w-5 h-5 text-[#8B4769]" />
                  <span className="font-medium text-[#8B4769]">
                    {!subscriptionData?.plan || subscriptionData?.plan?.id === 'free' ? 'Upgrade to unlock more features' : 'Upgrade to Pro for unlimited access'}
                  </span>
                </div>
                <p className="text-sm text-[#8B4769]/70 mb-3">
                  {!subscriptionData?.plan || subscriptionData?.plan?.id === 'free' 
                    ? 'Get more tasks, writing space, media trackers, and task analytics'
                    : 'Unlock unlimited everything, backups, offline writing, goals analytics, and more'
                  }
                </p>
                <Button
                  onClick={() => navigate('/subscription')}
                  className="bg-[#8B4769] text-white hover:bg-[#96536F] text-sm"
                >
                  <Crown className="w-4 h-4 mr-2" />
                  Upgrade Now
                </Button>
              </div>
            )}

            {subscriptionData?.plan?.id === 'pro' && (
              <div className="bg-gradient-to-r from-purple-100 to-purple-50 rounded-xl p-4">
                <div className="flex items-center gap-3 mb-2">
                  <Crown className="w-5 h-5 text-purple-600" />
                  <span className="font-medium text-purple-700">
                    You're on Velory Pro! 🎉
                  </span>
                </div>
                <p className="text-sm text-purple-600">
                  Enjoy unlimited access to all features, analytics, backups, and more.
                </p>
              </div>
            )}
          </div>
        </motion.div>

        {/* Achievements */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white/80 rounded-3xl p-6 border-2 border-[#8B4769]/20"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-semibold text-[#8B4769]">Achievements</h3>
            <Button
              variant="ghost"
              onClick={() => {
                setEditingAchievement(null);
                setNewAchievement({ title: '', description: '', icon: '🏆' });
                setShowAchievementDialog(true);
              }}
              className="text-[#8B4769]"
            >
              <Plus className="w-5 h-5" />
            </Button>
          </div>
          
          {achievements.length === 0 ? (
            <p className="text-[#8B4769]/70 text-center py-4">No achievements yet. Add your first one!</p>
          ) : (
            <div className="space-y-3">
              {achievements.map((achievement) => (
                <div
                  key={achievement.id}
                  className="flex items-center justify-between bg-[#8B4769]/5 rounded-xl p-3"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{achievement.icon}</span>
                    <div>
                      <h4 className="font-semibold text-[#8B4769]">{achievement.title}</h4>
                      {achievement.description && (
                        <p className="text-sm text-[#8B4769]/70">{achievement.description}</p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        setEditingAchievement(achievement);
                        setNewAchievement({
                          title: achievement.title,
                          description: achievement.description,
                          icon: achievement.icon
                        });
                        setShowAchievementDialog(true);
                      }}
                      className="h-8 w-8 text-[#8B4769]"
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDeleteAchievement(achievement.id)}
                      className="h-8 w-8 text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      </div>

      {/* Upgrade Dialog */}
      <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
        <DialogContent className="w-[95vw] max-w-[400px] bg-white rounded-3xl p-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-[#8B4769] mb-3">Upgrade Required</h3>
            <p className="text-[#8B4769]/80 mb-6">
              {!canUseAnalytics() 
                ? "Analytics are available with Velory Plus (tasks only) and Pro (tasks + goals)."
                : "Goals analytics are available with Velory Pro only. Plus users have access to task analytics."
              }
            </p>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowUpgradeDialog(false)}
                className="flex-1 border-[#8B4769] text-[#8B4769]"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  setShowUpgradeDialog(false);
                  navigate('/subscription');
                }}
                className="flex-1 bg-[#8B4769] text-white hover:bg-[#96536F]"
              >
                <Crown className="w-4 h-4 mr-2" />
                Upgrade Now
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Profile Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="sm:max-w-[500px] bg-[#FEE2E2]/95">
          <DialogHeader>
            <DialogTitle className="text-[#8B4769]">Edit Profile</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="flex flex-col items-center gap-4">
              <div className="relative w-24 h-24">
                <img
                  src={profile?.avatar_url || 'https://res.cloudinary.com/db6un9uvp/image/upload/v1745916296/default_avatar_kq7bxn.png'}
                  alt="Profile"
                  className="w-full h-full rounded-full object-cover border-4 border-[#8B4769]/20"
                />
                <button
                  onClick={() => {
                    if (canUploadAvatar()) {
                      fileInputRef.current?.click();
                    } else {
                      setShowUpgradeDialog(true);
                    }
                  }}
                  className="absolute bottom-0 right-0 bg-[#8B4769] text-white rounded-full p-1.5 hover:bg-[#96536F] transition-colors"
                >
                  <Pencil className="w-3 h-3" />
                </button>
              </div>
              
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    if (canUploadAvatar()) {
                      fileInputRef.current?.click();
                    } else {
                      setShowUpgradeDialog(true);
                    }
                  }}
                  className="border-[#8B4769] text-[#8B4769]"
                >
                  {!canUploadAvatar() && <Lock className="w-4 h-4 mr-2" />}
                  Change Photo
                </Button>
                {canUploadAvatar() && (
                  <Button
                    variant="outline"
                    onClick={handleDeleteAvatar}
                    className="border-red-500 text-red-600"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Remove
                  </Button>
                )}
              </div>
              
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleAvatarChange}
                accept="image/*"
                className="hidden"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2 text-[#8B4769]">Username</label>
              <input
                type="text"
                value={editProfile.username}
                onChange={(e) => setEditProfile({ ...editProfile, username: e.target.value })}
                className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2 text-[#8B4769]">Bio</label>
              <textarea
                value={editProfile.bio}
                onChange={(e) => setEditProfile({ ...editProfile, bio: e.target.value })}
                className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50 min-h-[100px]"
                placeholder="Tell us about yourself..."
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowEditDialog(false)}
              className="border-[#8B4769] text-[#8B4769]"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSaveProfile}
              className="bg-[#8B4769] text-white hover:bg-[#96536F]"
            >
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Achievement Dialog */}
      <Dialog open={showAchievementDialog} onOpenChange={setShowAchievementDialog}>
        <DialogContent className="sm:max-w-[500px] bg-[#FEE2E2]/95">
          <DialogHeader>
            <DialogTitle className="text-[#8B4769]">
              {editingAchievement ? 'Edit Achievement' : 'Add Achievement'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2 text-[#8B4769]">Icon</label>
              <div className="flex flex-wrap gap-2">
                {achievementIcons.map(icon => (
                  <button
                    key={icon}
                    onClick={() => setNewAchievement({ ...newAchievement, icon })}
                    className={`w-12 h-12 rounded-xl border-2 flex items-center justify-center text-xl ${
                      newAchievement.icon === icon
                        ? 'border-[#8B4769] bg-[#8B4769]/10'
                        : 'border-[#8B4769]/20 bg-white/50'
                    }`}
                  >
                    {icon}
                  </button>
                ))}
              </div>
            </div>

            <input
              type="text"
              placeholder="Achievement Title"
              value={newAchievement.title}
              onChange={(e) => setNewAchievement({ ...newAchievement, title: e.target.value })}
              className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
            />

            <textarea
              placeholder="Description (optional)"
              value={newAchievement.description}
              onChange={(e) => setNewAchievement({ ...newAchievement, description: e.target.value })}
              className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50 min-h-[100px]"
            />
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowAchievementDialog(false);
                setNewAchievement({ title: '', description: '', icon: '🏆' });
                setEditingAchievement(null);
              }}
              className="border-[#8B4769] text-[#8B4769]"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSaveAchievement}
              disabled={!newAchievement.title.trim() || !user?.id}
              className="bg-[#8B4769] text-white hover:bg-[#96536F]"
            >
              {editingAchievement ? 'Save Changes' : 'Add Achievement'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Statistics Dialog */}
      <Dialog open={showStatsDialog} onOpenChange={setShowStatsDialog}>
        <DialogContent className="sm:max-w-[600px] bg-[#FEE2E2]/95 max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-[#8B4769]">
              {statsType === 'improvement' ? 'Daily Task Analytics' : 'Yearly Goals Analytics'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {statsType === 'improvement' ? (
              <div className="space-y-3">
                <div className="text-center mb-4">
                  <p className="text-sm text-[#8B4769]/70">Your daily task completion progress (last 30 days)</p>
                  <div className="flex justify-center gap-4 mt-2 text-sm">
                    <span className="text-[#8B4769]">
                      <strong>Current Streak:</strong> {streakInfo.currentStreak} days
                    </span>
                    <span className="text-[#8B4769]">
                      <strong>Best Streak:</strong> {streakInfo.longestStreak} days
                    </span>
                  </div>
                </div>
                {taskCompletions.slice(-10).reverse().map((day, index) => (
                  <div key={day.date} className="bg-white/50 rounded-xl p-4 border-2 border-[#8B4769]/20">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-[#8B4769]">
                        {isToday(new Date(day.date)) ? 'Today' : format(new Date(day.date), 'MMM d, yyyy')}
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-[#8B4769]">
                          {day.completed} tasks completed
                        </span>
                        {!day.hasActiveTasks && (
                          <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">
                            No active tasks
                          </span>
                        )}
                      </div>
                    </div>
                    {day.hasActiveTasks && (
                      <>
                        <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-green-400 to-green-600 rounded-full transition-all duration-300"
                            style={{ width: `${getCompletionRate(day.completed, day.total)}%` }}
                          />
                        </div>
                        <div className="flex justify-between items-center mt-2">
                          <span className="text-xs text-[#8B4769]/60">
                            {getCompletionRate(day.completed, day.total)}% completed
                          </span>
                          {day.completed === day.total && day.total > 0 && (
                            <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                              Perfect Day! 🎉
                            </span>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-3">
                <div className="text-center mb-4">
                  <p className="text-sm text-[#8B4769]/70">Your goal completion progress for {new Date().getFullYear()}</p>
                  <div className="mt-2 text-sm">
                    <span className="text-[#8B4769]">
                      <strong>Total Goals Completed This Year:</strong> {getCurrentYearGoals()}
                    </span>
                  </div>
                  <div className="mt-1 text-sm">
                    <span className="text-[#8B4769]">
                      <strong>Overall Goals Completed:</strong> {getTotalGoalsCompleted()}
                    </span>
                  </div>
                </div>
                {goalCompletions.map((month, index) => (
                  <div key={month.month} className="bg-white/50 rounded-xl p-4 border-2 border-[#8B4769]/20">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-semibold text-[#8B4769]">{month.month} {month.year}</h4>
                      <span className="text-sm font-medium text-[#8B4769]">
                        {month.completed} goals completed
                      </span>
                    </div>
                    
                    {month.total > 0 && (
                      <>
                        <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden mb-2">
                          <div 
                            className="h-full bg-gradient-to-r from-blue-400 to-blue-600 rounded-full transition-all duration-300"
                            style={{ width: `${getCompletionRate(month.completed, month.total)}%` }}
                          />
                        </div>
                        
                        <span className="text-xs text-[#8B4769]/60">
                          {getCompletionRate(month.completed, month.total)}% of goals completed
                        </span>
                      </>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          <DialogFooter>
            <Button
              onClick={() => setShowStatsDialog(false)}
              className="bg-[#8B4769] text-white hover:bg-[#96536F]"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};