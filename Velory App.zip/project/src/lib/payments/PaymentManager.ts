import type { PaymentProvider, PaymentMethod, PaymentIntent, PaymentResult, CustomerInfo, PaymentConfig } from './types';
import { RazorpayProvider } from './providers/razorpay';

export class PaymentManager {
  private config: PaymentConfig;
  private providers: Map<string, any> = new Map();
  private userCountry: string = 'IN';
  private userCurrency: string = 'INR';

  constructor(config: PaymentConfig) {
    this.config = config;
    this.initializeProviders();
  }

  private initializeProviders() {
    // Initialize Razorpay for India
    if (this.config.providers.razorpay) {
      this.providers.set('razorpay', new RazorpayProvider({
        keyId: this.config.providers.razorpay.keyId,
        keySecret: this.config.providers.razorpay.keySecret,
        environment: this.config.environment
      }));
    }
  }

  getAvailableProviders(): PaymentProvider[] {
    const providers: PaymentProvider[] = [];

    if (this.providers.has('razorpay') && this.userCountry === 'IN') {
      providers.push(RazorpayProvider.getProviderInfo());
    }

    return providers;
  }

  getAvailablePaymentMethods(): PaymentMethod[] {
    const methods: PaymentMethod[] = [];

    if (this.providers.has('razorpay') && this.userCountry === 'IN') {
      methods.push(...RazorpayProvider.getPaymentMethods());
    }

    // Sort by popularity - UPI first for India, then cards
    return methods.sort((a, b) => {
      if (a.type === 'upi' && b.type === 'card') return -1;
      if (a.type === 'card' && b.type === 'upi') return 1;
      if (a.isPopular && !b.isPopular) return -1;
      if (!a.isPopular && b.isPopular) return 1;
      return 0;
    });
  }

  async processPayment(
    providerId: string,
    amount: number,
    currency: string,
    planId: string,
    billingCycle: 'monthly' | 'yearly',
    customer: CustomerInfo,
    paymentMethodId?: string
  ): Promise<PaymentResult> {
    const provider = this.providers.get(providerId);
    if (!provider) {
      return {
        success: false,
        error: `Payment provider ${providerId} not available`
      };
    }

    try {
      // Create payment intent
      const paymentIntent = await provider.createPaymentIntent(
        amount,
        currency,
        planId,
        billingCycle,
        customer
      );

      // Process payment
      const result = await provider.processPayment(
        paymentIntent,
        customer,
        paymentMethodId
      );

      return result;
    } catch (error: any) {
      return {
        success: false,
        error: error.message || 'Payment processing failed'
      };
    }
  }

  getUserCountry(): string {
    return this.userCountry;
  }

  getUserCurrency(): string {
    return this.userCurrency;
  }

  setUserLocation(country: string, currency: string) {
    this.userCountry = country;
    this.userCurrency = currency;
  }
}