import { AdMob, BannerAdOptions, BannerAdSize, BannerAdPosition, InterstitialAdOptions, RewardAdOptions, AdMobRewardItem, AdLoadInfo, AdShowInfo } from '@capacitor-community/admob';
import { Capacitor } from '@capacitor/core';

// Test Ad Unit IDs - Replace with your actual Ad Unit IDs from AdMob
const AD_UNITS = {
  banner: {
    android: 'ca-app-pub-3940256099942544/6300978111', // Test banner
    ios: 'ca-app-pub-3940256099942544/2934735716'     // Test banner
  },
  interstitial: {
    android: 'ca-app-pub-3940256099942544/1033173712', // Test interstitial
    ios: 'ca-app-pub-3940256099942544/4411468910'     // Test interstitial
  },
  rewarded: {
    android: 'ca-app-pub-3940256099942544/5224354917', // Test rewarded
    ios: 'ca-app-pub-3940256099942544/1712485313'     // Test rewarded
  }
};

class AdMobManager {
  private isInitialized = false;
  private isNative = false;

  constructor() {
    this.isNative = Capacitor.isNativePlatform();
  }

  async initialize(): Promise<void> {
    if (!this.isNative || this.isInitialized) {
      console.log('AdMob: Not native platform or already initialized');
      return;
    }

    try {
      await AdMob.initialize({
        requestTrackingAuthorization: true,
        testingDevices: ['YOUR_DEVICE_ID'], // Add your device ID for testing
        initializeForTesting: true
      });
      
      this.isInitialized = true;
      console.log('AdMob initialized successfully');
    } catch (error) {
      console.error('AdMob initialization failed:', error);
    }
  }

  private getAdUnitId(type: 'banner' | 'interstitial' | 'rewarded'): string {
    const platform = Capacitor.getPlatform();
    return AD_UNITS[type][platform as 'android' | 'ios'] || AD_UNITS[type].android;
  }

  // Banner Ads
  async showBanner(position: BannerAdPosition = BannerAdPosition.BOTTOM_CENTER): Promise<void> {
    if (!this.isNative) {
      console.log('AdMob: Banner not available on web platform');
      return;
    }

    try {
      const options: BannerAdOptions = {
        adId: this.getAdUnitId('banner'),
        adSize: BannerAdSize.ADAPTIVE_BANNER,
        position: position,
        margin: 0,
        isTesting: true // Set to false in production
      };

      await AdMob.showBanner(options);
      console.log('Banner ad shown successfully');
    } catch (error) {
      console.error('Failed to show banner ad:', error);
    }
  }

  async hideBanner(): Promise<void> {
    if (!this.isNative) return;

    try {
      await AdMob.hideBanner();
      console.log('Banner ad hidden');
    } catch (error) {
      console.error('Failed to hide banner ad:', error);
    }
  }

  async removeBanner(): Promise<void> {
    if (!this.isNative) return;

    try {
      await AdMob.removeBanner();
      console.log('Banner ad removed');
    } catch (error) {
      console.error('Failed to remove banner ad:', error);
    }
  }

  // Interstitial Ads
  async prepareInterstitial(): Promise<void> {
    if (!this.isNative) return;

    try {
      const options: InterstitialAdOptions = {
        adId: this.getAdUnitId('interstitial'),
        isTesting: true // Set to false in production
      };

      await AdMob.prepareInterstitial(options);
      console.log('Interstitial ad prepared');
    } catch (error) {
      console.error('Failed to prepare interstitial ad:', error);
    }
  }

  async showInterstitial(): Promise<void> {
    if (!this.isNative) {
      console.log('AdMob: Interstitial not available on web platform');
      return;
    }

    try {
      await AdMob.showInterstitial();
      console.log('Interstitial ad shown');
    } catch (error) {
      console.error('Failed to show interstitial ad:', error);
    }
  }

  // Rewarded Ads
  async prepareRewardedAd(): Promise<void> {
    if (!this.isNative) return;

    try {
      const options: RewardAdOptions = {
        adId: this.getAdUnitId('rewarded'),
        isTesting: true // Set to false in production
      };

      await AdMob.prepareRewardVideoAd(options);
      console.log('Rewarded ad prepared');
    } catch (error) {
      console.error('Failed to prepare rewarded ad:', error);
    }
  }

  async showRewardedAd(): Promise<AdMobRewardItem | null> {
    if (!this.isNative) {
      console.log('AdMob: Rewarded ad not available on web platform');
      return null;
    }

    try {
      const result = await AdMob.showRewardVideoAd();
      console.log('Rewarded ad shown, reward:', result);
      return result;
    } catch (error) {
      console.error('Failed to show rewarded ad:', error);
      return null;
    }
  }

  // Event Listeners
  setupEventListeners(): void {
    if (!this.isNative) return;

    // Banner events
    AdMob.addListener('bannerAdLoaded', (info: AdLoadInfo) => {
      console.log('Banner ad loaded:', info);
    });

    AdMob.addListener('bannerAdFailedToLoad', (error: any) => {
      console.error('Banner ad failed to load:', error);
    });

    // Interstitial events
    AdMob.addListener('interstitialAdLoaded', (info: AdLoadInfo) => {
      console.log('Interstitial ad loaded:', info);
    });

    AdMob.addListener('interstitialAdFailedToLoad', (error: any) => {
      console.error('Interstitial ad failed to load:', error);
    });

    AdMob.addListener('interstitialAdShown', (info: AdShowInfo) => {
      console.log('Interstitial ad shown:', info);
    });

    AdMob.addListener('interstitialAdDismissed', (info: AdShowInfo) => {
      console.log('Interstitial ad dismissed:', info);
      // Prepare next interstitial
      this.prepareInterstitial();
    });

    // Rewarded ad events
    AdMob.addListener('rewardedVideoAdLoaded', (info: AdLoadInfo) => {
      console.log('Rewarded ad loaded:', info);
    });

    AdMob.addListener('rewardedVideoAdFailedToLoad', (error: any) => {
      console.error('Rewarded ad failed to load:', error);
    });

    AdMob.addListener('rewardedVideoAdShown', (info: AdShowInfo) => {
      console.log('Rewarded ad shown:', info);
    });

    AdMob.addListener('rewardedVideoAdDismissed', (info: AdShowInfo) => {
      console.log('Rewarded ad dismissed:', info);
      // Prepare next rewarded ad
      this.prepareRewardedAd();
    });

    AdMob.addListener('rewardedVideoAdRewardReceived', (reward: AdMobRewardItem) => {
      console.log('Reward received:', reward);
    });
  }

  // Utility methods
  isAvailable(): boolean {
    return this.isNative && this.isInitialized;
  }

  async requestConsentInfo(): Promise<void> {
    if (!this.isNative) return;

    try {
      // This is for GDPR compliance - implement based on your needs
      console.log('Requesting consent info...');
    } catch (error) {
      console.error('Failed to request consent info:', error);
    }
  }
}

export const adMobManager = new AdMobManager();