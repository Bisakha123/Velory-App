export interface NotificationPermission {
  granted: boolean;
  denied: boolean;
  default: boolean;
}

class NotificationManager {
  private static instance: NotificationManager;
  private isInitialized = false;
  private scheduledNotifications = new Map<string, number[]>();

  private constructor() {}

  static getInstance(): NotificationManager {
    if (!NotificationManager.instance) {
      NotificationManager.instance = new NotificationManager();
    }
    return NotificationManager.instance;
  }

  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      // Check if we're in a WebContainer environment (StackBlitz)
      const isWebContainer = typeof window !== 'undefined' && 
        (window.location.hostname === 'localhost' || 
         window.location.hostname.includes('stackblitz') ||
         window.location.hostname.includes('webcontainer'));

      // Skip service worker registration in WebContainer environments
      if (isWebContainer) {
        console.log('Service Worker registration skipped: WebContainer environment detected');
        this.isInitialized = true;
        return;
      }

      await this.initializeServiceWorker();
      this.isInitialized = true;
    } catch (error) {
      console.error('Failed to initialize notifications:', error);
    }
  }

  private async initializeServiceWorker(): Promise<void> {
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.register('/sw.js');
        console.log('Service Worker registered successfully:', registration);
      } catch (error) {
        console.error('Service Worker registration failed:', error);
        throw error;
      }
    } else {
      throw new Error('Service Workers are not supported in this browser');
    }
  }

  getPermissionStatus(): NotificationPermission {
    if (!('Notification' in window)) {
      return { granted: false, denied: true, default: false };
    }

    const permission = Notification.permission;
    return {
      granted: permission === 'granted',
      denied: permission === 'denied',
      default: permission === 'default'
    };
  }

  async requestPermission(): Promise<NotificationPermission> {
    if (!('Notification' in window)) {
      throw new Error('This browser does not support notifications');
    }

    if (Notification.permission === 'granted') {
      return this.getPermissionStatus();
    }

    if (Notification.permission !== 'denied') {
      const permission = await Notification.requestPermission();
      return this.getPermissionStatus();
    }

    return this.getPermissionStatus();
  }

  async showNotification(title: string, options?: NotificationOptions): Promise<void> {
    try {
      const permission = await this.requestPermission();
      
      if (permission.granted) {
        new Notification(title, options);
      } else {
        console.warn('Notification permission not granted');
      }
    } catch (error) {
      console.error('Failed to show notification:', error);
    }
  }

  async testNotification(): Promise<void> {
    await this.showNotification('Test Notification', {
      body: 'This is a test notification from your task manager!',
      icon: '/icon.svg',
      badge: '/icon.svg'
    });
  }

  scheduleTaskReminders(task: any): void {
    if (!task || !task.id) return;

    // Clear existing notifications for this task
    this.clearTaskNotifications(task.id);

    const notifications: number[] = [];

    // Schedule reminder based on task due date or other criteria
    if (task.dueDate) {
      const dueDate = new Date(task.dueDate);
      const now = new Date();
      const timeDiff = dueDate.getTime() - now.getTime();

      // Schedule notification 1 hour before due date
      if (timeDiff > 3600000) { // More than 1 hour away
        const reminderTime = timeDiff - 3600000;
        const timeoutId = window.setTimeout(() => {
          this.showNotification(`Task Due Soon: ${task.title}`, {
            body: `Your task "${task.title}" is due in 1 hour`,
            icon: '/icon.svg',
            badge: '/icon.svg'
          });
        }, reminderTime);
        notifications.push(timeoutId);
      }

      // Schedule notification at due date
      if (timeDiff > 0) {
        const timeoutId = window.setTimeout(() => {
          this.showNotification(`Task Due Now: ${task.title}`, {
            body: `Your task "${task.title}" is due now!`,
            icon: '/icon.svg',
            badge: '/icon.svg'
          });
        }, timeDiff);
        notifications.push(timeoutId);
      }
    }

    if (notifications.length > 0) {
      this.scheduledNotifications.set(task.id, notifications);
    }
  }

  clearTaskNotifications(taskId: string): void {
    const notifications = this.scheduledNotifications.get(taskId);
    if (notifications) {
      notifications.forEach(timeoutId => clearTimeout(timeoutId));
      this.scheduledNotifications.delete(taskId);
    }
  }

  clearAllNotifications(): void {
    this.scheduledNotifications.forEach(notifications => {
      notifications.forEach(timeoutId => clearTimeout(timeoutId));
    });
    this.scheduledNotifications.clear();
  }

  async scheduleReminder(title: string, message: string, delay: number): Promise<void> {
    setTimeout(() => {
      this.showNotification(title, {
        body: message,
        icon: '/icon.svg',
        badge: '/icon.svg'
      });
    }, delay);
  }
}

export const notificationManager = NotificationManager.getInstance();