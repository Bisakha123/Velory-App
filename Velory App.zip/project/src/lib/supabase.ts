import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

console.log('Supabase URL:', supabaseUrl);
console.log('Supabase Anon Key:', supabaseAnonKey ? 'Present' : 'Missing');

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Missing Supabase environment variables');
  console.log('Please check your .env file contains:');
  console.log('VITE_SUPABASE_URL=your_supabase_project_url');
  console.log('VITE_SUPABASE_ANON_KEY=your_supabase_anon_key');
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    flowType: 'pkce'
  },
  global: {
    headers: {
      'X-Client-Info': 'my-organizer-app'
    }
  },
  db: {
    schema: 'public'
  },
  realtime: {
    params: {
      eventsPerSecond: 2
    }
  }
});

// Enhanced connection test function with better error handling
export const testSupabaseConnection = async () => {
  try {
    console.log('Testing Supabase connection...');
    
    // First test basic connectivity
    const healthCheck = await fetch(`${supabaseUrl}/rest/v1/`, {
      method: 'HEAD',
      headers: {
        'apikey': supabaseAnonKey,
        'Authorization': `Bearer ${supabaseAnonKey}`
      }
    });
    
    if (!healthCheck.ok && healthCheck.status !== 401) {
      throw new Error(`Health check failed with status: ${healthCheck.status}`);
    }
    
    // Test auth endpoint
    const { data, error } = await supabase.auth.getSession();
    
    if (error && !error.message.includes('session_not_found')) {
      console.error('Auth test failed:', error);
      return false;
    }
    
    console.log('Supabase connection test successful');
    return true;
  } catch (error) {
    console.error('Supabase connection test error:', error);
    return false;
  }
};

// Initialize connection test on module load
testSupabaseConnection().then(success => {
  if (!success) {
    console.warn('Initial Supabase connection test failed. Please check your configuration.');
  }
});

// Database types
export interface Profile {
  id: string;
  username: string;
  bio: string;
  avatar_url: string;
  diary_name: string;
  created_at: string;
  updated_at: string;
}

export interface Task {
  id: string;
  user_id: string;
  title: string;
  description: string;
  deadline: string;
  repeat_days: string[];
  tag: string;
  important: boolean;
  completed: boolean;
  completed_at?: string;
  created_at: string;
  updated_at: string;
}

export interface MoodEntry {
  id: string;
  user_id: string;
  date: string;
  mood: 'Happy' | 'Normal' | 'Sad' | 'Angry';
  created_at: string;
  updated_at: string;
}

export interface Writeup {
  id: string;
  user_id: string;
  type: 'journal' | 'creative' | 'thoughts' | 'gratitude' | 'goals' | 'autobiography';
  title: string;
  content: string;
  tags: string[];
  mood?: 'good' | 'bad';
  background_image?: string;
  metadata: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface Tracker {
  id: string;
  user_id: string;
  name: string;
  type: 'show' | 'book' | 'custom';
  image_url?: string;
  created_at: string;
  updated_at: string;
}

export interface MediaItem {
  id: string;
  tracker_id?: string;
  user_id: string;
  title: string;
  description: string;
  type: 'show' | 'book';
  genres: string[];
  status: 'pending' | 'ongoing' | 'completed';
  total_seasons?: number;
  total_episodes?: number;
  watched_episodes: number;
  created_at: string;
  updated_at: string;
}

export interface Achievement {
  id: string;
  user_id: string;
  title: string;
  description: string;
  icon: string;
  created_at: string;
  updated_at: string;
}

// Subscription types
export interface SubscriptionPlan {
  id: string;
  name: string;
  display_name: string;
  price_monthly: number;
  price_yearly: number;
  features: Record<string, any>;
  limits: Record<string, any>;
  is_active: boolean;
}

export interface UserSubscription {
  id: string;
  user_id: string;
  plan_id: string;
  status: 'active' | 'cancelled' | 'expired' | 'trial';
  billing_cycle: 'monthly' | 'yearly';
  current_period_start: string;
  current_period_end: string;
  trial_end?: string;
  cancelled_at?: string;
  metadata: Record<string, any>;
}