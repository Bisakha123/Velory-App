import { supabase, type Achievement } from '../supabase';

export const achievementsApi = {
  // Get all achievements
  async getAchievements() {
    const { data, error } = await supabase
      .from('achievements')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data as Achievement[];
  },

  // Create achievement
  async createAchievement(achievement: Omit<Achievement, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('achievements')
      .insert([achievement])
      .select()
      .single();
    
    if (error) throw error;
    return data as Achievement;
  },

  // Update achievement
  async updateAchievement(id: string, updates: Partial<Achievement>) {
    const { data, error } = await supabase
      .from('achievements')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data as Achievement;
  },

  // Delete achievement
  async deleteAchievement(id: string) {
    const { error } = await supabase
      .from('achievements')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  }
};