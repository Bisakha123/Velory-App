import { supabase } from '../supabase';

export const authApi = {
  // Sign up with email and password
  async signUp(email: string, password: string, username?: string) {
    console.log('authApi: Starting signup for:', email);
    
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          username: username || 'User'
        }
      }
    });
    
    if (error) {
      console.error('authApi: Signup error:', error);
      throw error;
    }
    
    console.log('authApi: Signup successful:', data);
    return data;
  },

  // Sign in with email and password
  async signIn(email: string, password: string) {
    console.log('authApi: Starting signin for:', email);
    
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    
    if (error) {
      console.error('authApi: Signin error:', error);
      throw error;
    }
    
    console.log('authApi: Signin successful:', data);
    return data;
  },

  // Sign out
  async signOut() {
    console.log('authApi: Starting signout');
    
    const { error } = await supabase.auth.signOut();
    if (error) {
      console.error('authApi: Signout error:', error);
      throw error;
    }
    
    console.log('authApi: Signout successful');
  },

  // Get current user
  async getCurrentUser() {
    const { data: { user }, error } = await supabase.auth.getUser();
    if (error) {
      console.error('authApi: Get user error:', error);
      throw error;
    }
    console.log('authApi: Current user:', user ? 'Found' : 'None');
    return user;
  },

  // Get current session
  async getCurrentSession() {
    const { data: { session }, error } = await supabase.auth.getSession();
    if (error) {
      console.error('authApi: Get session error:', error);
      throw error;
    }
    console.log('authApi: Current session:', session ? 'Found' : 'None');
    return session;
  },

  // Listen to auth changes
  onAuthStateChange(callback: (event: string, session: any) => void) {
    console.log('authApi: Setting up auth state listener');
    return supabase.auth.onAuthStateChange((event, session) => {
      console.log('authApi: Auth state change event:', event, session ? 'Session exists' : 'No session');
      callback(event, session);
    });
  },

  // Clear all user data from database (without logging out)
  async clearAllUserData() {
    console.log('authApi: Starting to clear all user data');
    
    try {
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError || !user) {
        throw new Error('User not authenticated');
      }

      console.log('authApi: Clearing data for user:', user.id);

      // Delete data in the correct order (respecting foreign key constraints)
      const deleteOperations = [
        // Delete media items first (references trackers)
        supabase.from('media_items').delete().eq('user_id', user.id),
        
        // Delete trackers
        supabase.from('trackers').delete().eq('user_id', user.id),
        
        // Delete other tables
        supabase.from('achievements').delete().eq('user_id', user.id),
        supabase.from('writeups').delete().eq('user_id', user.id),
        supabase.from('mood_entries').delete().eq('user_id', user.id),
        supabase.from('tasks').delete().eq('user_id', user.id),
        
        // Reset profile to defaults (don't delete, just reset)
        supabase.from('profiles').update({
          username: 'User',
          bio: '',
          diary_name: '',
          avatar_url: 'https://res.cloudinary.com/db6un9uvp/image/upload/v1745916296/default_avatar_kq7bxn.png'
        }).eq('id', user.id)
      ];

      // Execute all delete operations
      const results = await Promise.allSettled(deleteOperations);
      
      // Check for any errors
      const errors = results
        .map((result, index) => ({ result, index }))
        .filter(({ result }) => result.status === 'rejected')
        .map(({ result, index }) => `Operation ${index}: ${result.reason}`);

      if (errors.length > 0) {
        console.warn('authApi: Some delete operations failed:', errors);
        // Don't throw error, just log warnings as some tables might be empty
      }

      console.log('authApi: Successfully cleared all user data');
      return { success: true, errors };
    } catch (error) {
      console.error('authApi: Error clearing user data:', error);
      throw new Error(`Failed to clear user data: ${error.message}`);
    }
  }
};