import { supabase, type MoodEntry } from '../supabase';

export const moodsApi = {
  // Get mood entries for a date range
  async getMoodEntries(startDate?: string, endDate?: string) {
    try {
      let query = supabase
        .from('mood_entries')
        .select('*')
        .order('date', { ascending: false });
      
      if (startDate) {
        query = query.gte('date', startDate);
      }
      
      if (endDate) {
        query = query.lte('date', endDate);
      }
      
      const { data, error } = await query;
      
      if (error) {
        console.error('Error fetching mood entries:', error);
        throw error;
      }
      
      return data as MoodEntry[];
    } catch (error) {
      console.error('moodsApi.getMoodEntries error:', error);
      throw error;
    }
  },

  // Get mood for specific date
  async getMoodForDate(date: string) {
    try {
      const { data, error } = await supabase
        .from('mood_entries')
        .select('*')
        .eq('date', date)
        .single();
      
      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching mood for date:', error);
        throw error;
      }
      
      return data as MoodEntry | null;
    } catch (error) {
      console.error('moodsApi.getMoodForDate error:', error);
      throw error;
    }
  },

  // Set mood for date
  async setMood(date: string, mood: MoodEntry['mood']) {
    try {
      console.log('moodsApi.setMood called with:', { date, mood });
      
      // Validate inputs
      if (!date || !mood) {
        throw new Error('Date and mood are required');
      }
      
      // Validate mood value
      const validMoods = ['Happy', 'Normal', 'Sad', 'Angry'];
      if (!validMoods.includes(mood)) {
        throw new Error(`Invalid mood value: ${mood}. Must be one of: ${validMoods.join(', ')}`);
      }
      
      // Check if user is authenticated
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError || !user) {
        console.error('User authentication error:', userError);
        throw new Error('User not authenticated');
      }
      
      console.log('User authenticated:', user.id);
      
      // Use upsert to insert or update mood entry
      const { data, error } = await supabase
        .from('mood_entries')
        .upsert([{ 
          date, 
          mood,
          user_id: user.id 
        }], { 
          onConflict: 'user_id,date',
          ignoreDuplicates: false 
        })
        .select()
        .single();
      
      if (error) {
        console.error('Error upserting mood entry:', error);
        throw new Error(`Failed to save mood: ${error.message}`);
      }
      
      console.log('Mood saved successfully:', data);
      return data as MoodEntry;
    } catch (error) {
      console.error('moodsApi.setMood error:', error);
      throw error;
    }
  },

  // Delete mood entry
  async deleteMood(date: string) {
    try {
      console.log('moodsApi.deleteMood called with date:', date);
      
      const { error } = await supabase
        .from('mood_entries')
        .delete()
        .eq('date', date);
      
      if (error) {
        console.error('Error deleting mood entry:', error);
        throw error;
      }
      
      console.log('Mood deleted successfully');
    } catch (error) {
      console.error('moodsApi.deleteMood error:', error);
      throw error;
    }
  }
};