import { useState, useEffect } from 'react';
import { adMobManager } from '../lib/admob';
import { BannerAdPosition, AdMobRewardItem } from '@capacitor-community/admob';
import { Capacitor } from '@capacitor/core';

export function useAdMob() {
  const [isInitialized, setIsInitialized] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isNative, setIsNative] = useState(false);

  useEffect(() => {
    const initializeAdMob = async () => {
      try {
        setIsLoading(true);
        setIsNative(Capacitor.isNativePlatform());
        
        if (Capacitor.isNativePlatform()) {
          await adMobManager.initialize();
          adMobManager.setupEventListeners();
          
          // Prepare ads
          await adMobManager.prepareInterstitial();
          await adMobManager.prepareRewardedAd();
          
          setIsInitialized(true);
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to initialize AdMob');
      } finally {
        setIsLoading(false);
      }
    };

    initializeAdMob();
  }, []);

  const showBanner = async (position?: BannerAdPosition) => {
    try {
      setError(null);
      await adMobManager.showBanner(position);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to show banner');
    }
  };

  const hideBanner = async () => {
    try {
      setError(null);
      await adMobManager.hideBanner();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to hide banner');
    }
  };

  const removeBanner = async () => {
    try {
      setError(null);
      await adMobManager.removeBanner();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to remove banner');
    }
  };

  const showInterstitial = async () => {
    try {
      setError(null);
      await adMobManager.showInterstitial();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to show interstitial');
    }
  };

  const showRewardedAd = async (): Promise<AdMobRewardItem | null> => {
    try {
      setError(null);
      return await adMobManager.showRewardedAd();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to show rewarded ad');
      return null;
    }
  };

  const clearError = () => setError(null);

  return {
    isInitialized,
    isLoading,
    error,
    isNative,
    isAvailable: adMobManager.isAvailable(),
    showBanner,
    hideBanner,
    removeBanner,
    showInterstitial,
    showRewardedAd,
    clearError
  };
}