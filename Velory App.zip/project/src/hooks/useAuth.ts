import { useState, useEffect } from 'react';
import { authApi, profilesApi } from '../lib/api';
import type { User, Session } from '@supabase/supabase-js';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    console.log('useAuth: Initializing...');
    
    // Get initial session
    authApi.getCurrentSession().then((session) => {
      console.log('useAuth: Initial session:', session ? 'Found' : 'None');
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    }).catch((error) => {
      console.error('useAuth: Error getting initial session:', error);
      setLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = authApi.onAuthStateChange(async (event, session) => {
      console.log('useAuth: Auth state changed:', event, session ? 'Session exists' : 'No session');
      
      // Handle different auth events
      if (event === 'SIGNED_IN') {
        console.log('useAuth: User signed in');
        setSession(session);
        setUser(session?.user ?? null);
        
        // Create or update profile when user signs in
        if (session?.user) {
          try {
            await profilesApi.getProfile();
          } catch (error) {
            // Profile doesn't exist, it should be created by the trigger
            console.log('useAuth: Profile will be created by trigger');
          }
        }
      } else if (event === 'SIGNED_OUT') {
        console.log('useAuth: User signed out');
        setSession(null);
        setUser(null);
      } else if (event === 'TOKEN_REFRESHED') {
        console.log('useAuth: Token refreshed');
        setSession(session);
        setUser(session?.user ?? null);
      }
      
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const signUp = async (email: string, password: string, username?: string) => {
    console.log('useAuth: Attempting sign up for:', email);
    setLoading(true);
    try {
      const result = await authApi.signUp(email, password, username);
      console.log('useAuth: Sign up result:', result);
      
      // If there's a session, update state immediately
      if (result.session) {
        setSession(result.session);
        setUser(result.session.user);
      }
      
      return result;
    } catch (error) {
      console.error('useAuth: Sign up error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const signIn = async (email: string, password: string) => {
    console.log('useAuth: Attempting sign in for:', email);
    setLoading(true);
    try {
      const result = await authApi.signIn(email, password);
      console.log('useAuth: Sign in result:', result);
      
      // Update state immediately on successful sign in
      if (result.session) {
        setSession(result.session);
        setUser(result.session.user);
      }
      
      return result;
    } catch (error) {
      console.error('useAuth: Sign in error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    console.log('useAuth: Attempting sign out');
    setLoading(true);
    try {
      await authApi.signOut();
      console.log('useAuth: Sign out successful');
      // State will be updated by the auth state change listener
    } catch (error) {
      console.error('useAuth: Sign out error:', error);
    } finally {
      setLoading(false);
    }
  };

  const isAuthenticated = !!user;
  console.log('useAuth: Current state - authenticated:', isAuthenticated, 'loading:', loading);

  return {
    user,
    session,
    loading,
    signUp,
    signIn,
    signOut,
    isAuthenticated
  };
}