import { useState } from 'react';
import { backupManager, type BackupData, type BackupOptions } from '../lib/backup';
import { useAuthContext } from '../components/AuthProvider';
import * as apis from '../lib/api';

export function useBackup() {
  const { user } = useAuthContext();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const createBackup = async (options?: BackupOptions) => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      setLoading(true);
      setError(null);
      
      const backupData = await backupManager.createBackup(apis, user, options);
      return backupData;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to create backup';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const saveBackupLocally = async (backupData: BackupData) => {
    try {
      setLoading(true);
      setError(null);
      
      await backupManager.saveBackupLocally(backupData);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to save backup locally';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const restoreFromFile = async (file: File, options?: { overwrite?: boolean; selective?: string[] }) => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      setLoading(true);
      setError(null);
      
      const backupData = await backupManager.loadBackupFromFile(file);
      const result = await backupManager.restoreFromBackup(backupData, apis, user, options);
      return result;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to restore from file';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const createAndSaveBackup = async (options?: BackupOptions) => {
    const backupData = await createBackup(options);
    await saveBackupLocally(backupData);
    return backupData;
  };

  return {
    // Status
    loading,
    error,
    
    // Backup operations
    createBackup,
    saveBackupLocally,
    createAndSaveBackup,
    
    // Restore operations
    restoreFromFile,
    
    // Utilities
    clearError: () => setError(null)
  };
}