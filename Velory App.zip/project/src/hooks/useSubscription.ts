import { useState, useEffect } from 'react';
import { subscriptionsApi, type SubscriptionPlan, type UserSubscription } from '../lib/api/subscriptions';
import { useAuthContext } from '../components/AuthProvider';

interface SubscriptionData {
  subscription: UserSubscription;
  plan: SubscriptionPlan;
}

export function useSubscription() {
  const { user, isAuthenticated } = useAuthContext();
  const [subscriptionData, setSubscriptionData] = useState<SubscriptionData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isAuthenticated && user) {
      loadSubscription();
    } else {
      // Set default free plan for unauthenticated users
      setSubscriptionData({
        subscription: {
          id: 'default',
          user_id: '',
          plan_id: 'free',
          status: 'active',
          billing_cycle: 'monthly',
          current_period_start: new Date().toISOString(),
          current_period_end: new Date(Date.now() + 100 * 365 * 24 * 60 * 60 * 1000).toISOString(),
          metadata: {}
        },
        plan: {
          id: 'free',
          name: 'free',
          display_name: 'Velory Free',
          price_monthly: 0,
          price_yearly: 0,
          features: { basic_features: true, read_only_offline: true },
          limits: {
            daily_tasks: 10,
            important_tasks: 5,
            journal_entries: 10,
            journal_words_per_entry: 300,
            thoughts_entries: 5,
            thoughts_total_words: 150,
            gratitude_days: 10,
            gratitude_words_per_day: 100,
            goals_entries: 2,
            media_trackers: 0,
            custom_trackers: false,
            autobiography_cards: 0,
            creative_writing: 0,
            profile_avatar: false,
            background_images: false,
            analytics: false,
            goals_analytics: false,
            backups: false,
            offline_writing: false,
            motivational_popups: false,
            mood_history_months: 1
          },
          is_active: true
        }
      });
      setLoading(false);
    }
  }, [isAuthenticated, user]);

  const loadSubscription = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await subscriptionsApi.getUserSubscription();
      
      if (data) {
        setSubscriptionData(data);
      } else {
        // Fallback to free plan
        setSubscriptionData({
          subscription: {
            id: 'default',
            user_id: user?.id || '',
            plan_id: 'free',
            status: 'active',
            billing_cycle: 'monthly',
            current_period_start: new Date().toISOString(),
            current_period_end: new Date(Date.now() + 100 * 365 * 24 * 60 * 60 * 1000).toISOString(),
            metadata: {}
          },
          plan: {
            id: 'free',
            name: 'free',
            display_name: 'Velory Free',
            price_monthly: 0,
            price_yearly: 0,
            features: { basic_features: true, read_only_offline: true },
            limits: {
              daily_tasks: 10,
              important_tasks: 5,
              journal_entries: 10,
              journal_words_per_entry: 300,
              thoughts_entries: 5,
              thoughts_total_words: 150,
              gratitude_days: 10,
              gratitude_words_per_day: 100,
              goals_entries: 2,
              media_trackers: 0,
              custom_trackers: false,
              autobiography_cards: 0,
              creative_writing: 0,
              profile_avatar: false,
              background_images: false,
              analytics: false,
              goals_analytics: false,
              backups: false,
              offline_writing: false,
              motivational_popups: false,
              mood_history_months: 1
            },
            is_active: true
          }
        });
      }
    } catch (err) {
      console.error('Error loading subscription:', err);
      setError(err instanceof Error ? err.message : 'Failed to load subscription');
      
      // Fallback to free plan on error
      setSubscriptionData({
        subscription: {
          id: 'default',
          user_id: user?.id || '',
          plan_id: 'free',
          status: 'active',
          billing_cycle: 'monthly',
          current_period_start: new Date().toISOString(),
          current_period_end: new Date(Date.now() + 100 * 365 * 24 * 60 * 60 * 1000).toISOString(),
          metadata: {}
        },
        plan: {
          id: 'free',
          name: 'free',
          display_name: 'Velory Free',
          price_monthly: 0,
          price_yearly: 0,
          features: { basic_features: true, read_only_offline: true },
          limits: {
            daily_tasks: 10,
            important_tasks: 5,
            journal_entries: 10,
            journal_words_per_entry: 300,
            thoughts_entries: 5,
            thoughts_total_words: 150,
            gratitude_days: 10,
            gratitude_words_per_day: 100,
            goals_entries: 2,
            media_trackers: 0,
            custom_trackers: false,
            autobiography_cards: 0,
            creative_writing: 0,
            profile_avatar: false,
            background_images: false,
            analytics: false,
            goals_analytics: false,
            backups: false,
            offline_writing: false,
            motivational_popups: false,
            mood_history_months: 1
          },
          is_active: true
        }
      });
    } finally {
      setLoading(false);
    }
  };

  const checkLimit = async (resourceType: string): Promise<boolean> => {
    try {
      return await subscriptionsApi.checkLimit(resourceType);
    } catch (err) {
      console.error('Error checking limit:', err);
      return false;
    }
  };

  const incrementUsage = async (resourceType: string, incrementBy: number = 1): Promise<void> => {
    try {
      await subscriptionsApi.incrementUsage(resourceType, incrementBy);
    } catch (err) {
      console.error('Error incrementing usage:', err);
    }
  };

  const updateSubscription = async (planId: string, billingCycle: 'monthly' | 'yearly'): Promise<void> => {
    try {
      await subscriptionsApi.updateSubscription(planId, billingCycle);
      await loadSubscription(); // Refresh subscription data
    } catch (err) {
      console.error('Error updating subscription:', err);
      throw err;
    }
  };

  // Get current count for a resource type
  const getCurrentCount = async (resourceType: string): Promise<number> => {
    try {
      return await subscriptionsApi.getCurrentCount(resourceType);
    } catch (err) {
      console.error('Error getting current count:', err);
      return 0;
    }
  };

  // Helper functions to check specific features
  const canUseFeature = (feature: string): boolean => {
    if (!subscriptionData) return false;
    return subscriptionData.plan.features[feature] === true;
  };

  const getLimit = (limitType: string): number => {
    if (!subscriptionData) {
      // Return free plan limits as fallback
      const freeLimits: Record<string, number> = {
        daily_tasks: 10,
        important_tasks: 5,
        journal_entries: 10,
        thoughts_entries: 5,
        gratitude_days: 10,
        goals_entries: 2,
        media_trackers: 0,
        autobiography_cards: 0,
        creative_writing: 0
      };
      return freeLimits[limitType] || 0;
    }
    
    const limit = subscriptionData.plan.limits[limitType];
    return typeof limit === 'number' ? limit : 0;
  };

  const isUnlimited = (limitType: string): boolean => {
    return getLimit(limitType) === -1;
  };

  const isPro = (): boolean => {
    return subscriptionData?.plan.id === 'pro';
  };

  const isPlus = (): boolean => {
    return subscriptionData?.plan.id === 'plus';
  };

  const isFree = (): boolean => {
    return !subscriptionData || subscriptionData?.plan.id === 'free';
  };

  // Check if user can access analytics (Plus and Pro)
  const canUseAnalytics = (): boolean => {
    return subscriptionData?.plan.limits?.analytics === true;
  };

  // Check if user can access goals analytics (Pro only)
  const canUseGoalsAnalytics = (): boolean => {
    return subscriptionData?.plan.limits?.goals_analytics === true;
  };

  return {
    subscriptionData,
    loading,
    error,
    checkLimit,
    incrementUsage,
    updateSubscription,
    getCurrentCount,
    refetch: loadSubscription,
    
    // Helper methods
    canUseFeature,
    getLimit,
    isUnlimited,
    isPro,
    isPlus,
    isFree,
    canUseAnalytics,
    canUseGoalsAnalytics,
    
    // Quick access to common checks
    canUploadAvatar: () => canUseFeature('profile_avatar'),
    canUseMediaTrackers: () => canUseFeature('media_trackers') || isPro(),
    canUseBackups: () => canUseFeature('backups') || isPro(),
    canUseOfflineWriting: () => canUseFeature('offline_writing') || isPro(),
    canUseMotivationalPopups: () => canUseFeature('motivational_popups') || isPro(),
  };
}