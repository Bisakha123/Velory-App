import { useState, useEffect } from 'react';
import { profilesApi, type Profile } from '../lib/api';
import { useAuth } from './useAuth';

export function useProfile() {
  const { user, isAuthenticated } = useAuth();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isAuthenticated && user) {
      loadProfile();
    } else {
      setProfile(null);
    }
  }, [isAuthenticated, user]);

  const loadProfile = async () => {
    setLoading(true);
    setError(null);
    try {
      const profileData = await profilesApi.getProfile();
      setProfile(profileData);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const updateProfile = async (updates: Partial<Profile>) => {
    if (!user?.id) {
      throw new Error('User not authenticated');
    }
    
    setLoading(true);
    setError(null);
    try {
      const updatedProfile = await profilesApi.updateProfile(user.id, updates);
      setProfile(updatedProfile);
      return updatedProfile;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update profile');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const uploadAvatar = async (file: File) => {
    setLoading(true);
    setError(null);
    try {
      const avatarUrl = await profilesApi.uploadAvatar(file);
      const updatedProfile = await updateProfile({ avatar_url: avatarUrl });
      return updatedProfile;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to upload avatar');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return {
    profile,
    loading,
    error,
    updateProfile,
    uploadAvatar,
    refetch: loadProfile
  };
}