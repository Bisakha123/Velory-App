import React, { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { 
  Italic, 
  Underline as UnderlineIcon, 
  AlignLeft, 
  AlignCenter, 
  AlignRight,
  Palette,
  Highlighter,
  X
} from 'lucide-react';

interface SimpleEditorProps {
  content: string;
  onChange: (content: string) => void;
  placeholder?: string;
  readOnly?: boolean;
  className?: string;
  style?: React.CSSProperties;
  wordLimit?: number;
  onWordLimitExceeded?: (exceeded: boolean) => void;
}

const TEXT_COLORS = [
  '#000000', '#FFFFFF', '#FF0000', '#FF9900', '#FFFF00', '#00FF00', 
  '#00FFFF', '#0000FF', '#9900FF', '#FF00FF', '#8B4769'
];
const HIGHLIGHT_COLORS = ['#FFEB3B', '#FF9800', '#4CAF50', '#2196F3', '#E91E63', '#9C27B0'];

export const SimpleEditor: React.FC<SimpleEditorProps> = ({
  content,
  onChange,
  placeholder = 'Start typing...',
  readOnly = false,
  className = '',
  style = {},
  wordLimit,
  onWordLimitExceeded
}) => {
  const editorRef = useRef<HTMLDivElement>(null);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [showHighlightPicker, setShowHighlightPicker] = useState(false);
  const [wordCount, setWordCount] = useState(0);

  useEffect(() => {
    if (editorRef.current && content !== editorRef.current.innerHTML) {
      editorRef.current.innerHTML = content;
      updateWordCount(content);
    }
  }, [content]);

  const getTextContent = (html: string): string => {
    const div = document.createElement('div');
    div.innerHTML = html;
    return div.textContent || div.innerText || '';
  };

  const countWords = (text: string): number => {
    return text.trim().split(/\s+/).filter(word => word.length > 0).length;
  };

  const updateWordCount = (html: string) => {
    const text = getTextContent(html);
    const count = countWords(text);
    setWordCount(count);
    
    if (wordLimit && onWordLimitExceeded) {
      onWordLimitExceeded(count > wordLimit);
    }
  };

  const handleInput = () => {
    if (editorRef.current && !readOnly) {
      const newContent = editorRef.current.innerHTML;
      const text = getTextContent(newContent);
      const count = countWords(text);
      
      // If word limit is set and exceeded, prevent the change
      if (wordLimit && count > wordLimit) {
        // Revert to previous content
        editorRef.current.innerHTML = content;
        return;
      }
      
      updateWordCount(newContent);
      onChange(newContent);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Check word limit before allowing new input
    if (wordLimit && !readOnly) {
      const text = getTextContent(editorRef.current?.innerHTML || '');
      const count = countWords(text);
      
      // Allow backspace, delete, and navigation keys even when at limit
      const allowedKeys = ['Backspace', 'Delete', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End'];
      
      if (count >= wordLimit && !allowedKeys.includes(e.key) && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        return;
      }
    }
    
    if (e.key === 'Tab') {
      e.preventDefault();
      document.execCommand('insertText', false, '    ');
    }
  };

  const execCommand = (command: string, value?: string) => {
    if (readOnly) return;
    
    document.execCommand(command, false, value);
    editorRef.current?.focus();
    handleInput();
  };

  const handleColorClick = (color: string) => {
    execCommand('foreColor', color);
    setShowColorPicker(false);
  };

  const handleHighlightClick = (color: string | null) => {
    if (color === null) {
      execCommand('removeFormat');
    } else {
      execCommand('hiliteColor', color);
    }
    setShowHighlightPicker(false);
  };

  const isAtWordLimit = wordLimit && wordCount >= wordLimit;

  return (
    <div className={`simple-editor ${className}`}>
      {!readOnly && (
        <div className="editor-toolbar bg-white/80 border-b border-[#8B4769]/20 px-2 py-0.5 flex flex-wrap gap-0.5 items-center min-h-[28px]">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => execCommand('italic')}
            className="text-[#8B4769] h-5 w-5 p-0 hover:bg-[#8B4769]/10"
          >
            <Italic className="w-2.5 h-2.5" />
          </Button>
          
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => execCommand('underline')}
            className="text-[#8B4769] h-5 w-5 p-0 hover:bg-[#8B4769]/10"
          >
            <UnderlineIcon className="w-2.5 h-2.5" />
          </Button>

          <div className="h-3 w-px bg-[#8B4769]/20 mx-0.5" />

          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => execCommand('justifyLeft')}
            className="text-[#8B4769] h-5 w-5 p-0 hover:bg-[#8B4769]/10"
          >
            <AlignLeft className="w-2.5 h-2.5" />
          </Button>
          
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => execCommand('justifyCenter')}
            className="text-[#8B4769] h-5 w-5 p-0 hover:bg-[#8B4769]/10"
          >
            <AlignCenter className="w-2.5 h-2.5" />
          </Button>
          
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => execCommand('justifyRight')}
            className="text-[#8B4769] h-5 w-5 p-0 hover:bg-[#8B4769]/10"
          >
            <AlignRight className="w-2.5 h-2.5" />
          </Button>

          <div className="h-3 w-px bg-[#8B4769]/20 mx-0.5" />

          <div className="relative">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => {
                setShowColorPicker(!showColorPicker);
                setShowHighlightPicker(false);
              }}
              className="text-[#8B4769] h-5 w-5 p-0 hover:bg-[#8B4769]/10"
            >
              <Palette className="w-2.5 h-2.5" />
            </Button>
            {showColorPicker && (
              <div className="absolute top-full left-0 mt-1 p-1.5 bg-white rounded-lg shadow-lg z-50 border">
                <div className="flex gap-0.5">
                  {TEXT_COLORS.map(color => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => handleColorClick(color)}
                      className="w-3.5 h-3.5 rounded hover:scale-110 transition-transform"
                      style={{ backgroundColor: color, border: color === '#FFFFFF' ? '1px solid #e2e8f0' : 'none' }}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="relative">
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => {
                setShowHighlightPicker(!showHighlightPicker);
                setShowColorPicker(false);
              }}
              className="text-[#8B4769] h-5 w-5 p-0 hover:bg-[#8B4769]/10"
            >
              <Highlighter className="w-2.5 h-2.5" />
            </Button>
            {showHighlightPicker && (
              <div className="absolute top-full left-0 mt-1 p-1.5 bg-white rounded-lg shadow-lg z-50 border">
                <div className="flex gap-0.5">
                  <button
                    type="button"
                    onClick={() => handleHighlightClick(null)}
                    className="w-3.5 h-3.5 rounded hover:scale-110 transition-transform flex items-center justify-center border border-gray-200"
                  >
                    <X className="w-1.5 h-1.5 text-[#8B4769]" />
                  </button>
                  {HIGHLIGHT_COLORS.map(color => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => handleHighlightClick(color)}
                      className="w-3.5 h-3.5 rounded hover:scale-110 transition-transform"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Word count display */}
          {wordLimit && (
            <div className="ml-auto text-xs text-[#8B4769]/70 px-2">
              <span className={isAtWordLimit ? 'text-red-600 font-medium' : ''}>
                {wordCount}/{wordLimit} words
              </span>
            </div>
          )}
        </div>
      )}

      <div
        ref={editorRef}
        contentEditable={!readOnly}
        onInput={handleInput}
        onKeyDown={handleKeyDown}
        className={`editor-content p-4 min-h-[300px] focus:outline-none ${readOnly ? 'cursor-default' : 'cursor-text'} ${isAtWordLimit ? 'border-red-300' : ''}`}
        style={{ 
          lineHeight: '1.6',
          ...style
        }}
        data-placeholder={placeholder}
        suppressContentEditableWarning={true}
      />

      {/* Word limit warning */}
      {wordLimit && isAtWordLimit && !readOnly && (
        <div className="bg-red-50 border-t border-red-200 p-2 text-center">
          <span className="text-red-600 text-sm font-medium">
            Word limit reached ({wordLimit} words)
          </span>
        </div>
      )}

      <style jsx>{`
        .editor-content:empty::before {
          content: attr(data-placeholder);
          color: #adb5bd;
          font-style: italic;
          pointer-events: none;
        }
        
        .editor-content:focus {
          outline: none !important;
        }
        
        .editor-content p {
          margin: 0.5em 0;
        }
        
        .editor-content:empty {
          min-height: 300px;
        }
      `}</style>
    </div>
  );
};