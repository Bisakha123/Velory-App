import React, { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuthContext } from './AuthProvider';
import { LoginScreen } from './LoginScreen';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { isAuthenticated, loading } = useAuthContext();
  const navigate = useNavigate();
  const location = useLocation();

  console.log('ProtectedRoute: authenticated:', isAuthenticated, 'loading:', loading);

  // Redirect to home after successful authentication ONLY if coming from login
  useEffect(() => {
    if (isAuthenticated && !loading) {
      // Only redirect if we're on the root path and coming from login (not normal navigation)
      if (location.pathname === '/' && !location.state?.fromNavigation) {
        // This means user just logged in, stay on home
        console.log('ProtectedRoute: User authenticated, staying on home');
      }
      // Don't redirect if user is navigating to settings or other pages normally
    }
  }, [isAuthenticated, loading, location.pathname, navigate, location.state]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FEE2E2] flex items-center justify-center">
        <div className="text-[#8B4769] text-xl font-semibold">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    console.log('ProtectedRoute: Showing login screen');
    return <LoginScreen />;
  }

  console.log('ProtectedRoute: Showing protected content');
  return <>{children}</>;
}