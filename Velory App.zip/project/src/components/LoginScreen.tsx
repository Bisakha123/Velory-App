import React, { useState } from 'react';
import { Button } from './ui/button';
import { useAuthContext } from './AuthProvider';
import { motion } from 'framer-motion';

export function LoginScreen() {
  const { signIn, signUp, loading } = useAuthContext();
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!email.trim() || !password.trim()) {
      setError('Please fill in all required fields');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters long');
      return;
    }

    console.log('LoginScreen: Form submitted', { isSignUp, email });

    try {
      if (isSignUp) {
        console.log('LoginScreen: Attempting signup');
        const result = await signUp(email.trim(), password, username.trim() || undefined);
        console.log('LoginScreen: Signup result:', result);
        
        if (result.error) {
          setError(result.error.message);
          return;
        }
        
        if (result.user && !result.session) {
          // Email confirmation required
          setSuccess('Account created successfully! You can now sign in.');
          setIsSignUp(false);
          setEmail('');
          setPassword('');
          setUsername('');
        } else if (result.session) {
          // Auto signed in
          console.log('LoginScreen: User automatically signed in after signup');
        }
      } else {
        console.log('LoginScreen: Attempting signin');
        const result = await signIn(email.trim(), password);
        console.log('LoginScreen: Signin result:', result);
        
        if (result.error) {
          setError(result.error.message);
          return;
        }
        
        if (result.session) {
          console.log('LoginScreen: User successfully signed in');
        }
      }
    } catch (err: any) {
      console.error('LoginScreen: Auth error:', err);
      setError(err.message || 'Authentication failed. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-[#FEE2E2] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white/80 rounded-3xl p-8 w-full max-w-md border-2 border-[#8B4769]/20"
      >
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-[#8B4769] mb-2">
            {isSignUp ? 'Create Account' : 'Welcome Back'}
          </h1>
          <p className="text-[#8B4769]/70">
            {isSignUp ? 'Join Velory Space today' : 'Sign in to your account'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignUp && (
            <input
              type="text"
              placeholder="Username (optional)"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
            />
          )}
          
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
            required
          />
          
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
            required
            minLength={6}
          />

          {error && (
            <div className="text-red-600 text-sm text-center bg-red-50 p-3 rounded-lg border border-red-200">
              {error}
            </div>
          )}

          {success && (
            <div className="text-green-600 text-sm text-center bg-green-50 p-3 rounded-lg border border-green-200">
              {success}
            </div>
          )}

          <Button
            type="submit"
            disabled={loading}
            className="w-full bg-[#8B4769] text-white hover:bg-[#96536F] py-3 text-lg"
          >
            {loading ? 'Loading...' : (isSignUp ? 'Sign Up' : 'Sign In')}
          </Button>
        </form>

        <div className="text-center mt-6">
          <button
            onClick={() => {
              setIsSignUp(!isSignUp);
              setError('');
              setSuccess('');
              setEmail('');
              setPassword('');
              setUsername('');
            }}
            className="text-[#8B4769] hover:underline"
          >
            {isSignUp 
              ? 'Already have an account? Sign in' 
              : "Don't have an account? Sign up"
            }
          </button>
        </div>
      </motion.div>
    </div>
  );
}