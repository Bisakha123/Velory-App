import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { motion } from 'framer-motion';
import { CreditCard, Smartphone } from 'lucide-react';
import type { PaymentMethod } from '../lib/payments/types';

interface PaymentMethodSelectorProps {
  paymentMethods: PaymentMethod[];
  onSelect: (method: PaymentMethod) => void;
  selectedMethod?: PaymentMethod;
  amount: number;
  currency: string;
  userCountry: string;
}

const getMethodIcon = (type: string) => {
  switch (type) {
    case 'card': return <CreditCard className="w-5 h-5" />;
    case 'upi': return <Smartphone className="w-5 h-5" />;
    default: return <CreditCard className="w-5 h-5" />;
  }
};

const getMethodColor = (type: string) => {
  switch (type) {
    case 'card': return 'bg-blue-50 border-blue-200 text-blue-700';
    case 'upi': return 'bg-green-50 border-green-200 text-green-700';
    default: return 'bg-gray-50 border-gray-200 text-gray-700';
  }
};

export const PaymentMethodSelector: React.FC<PaymentMethodSelectorProps> = ({
  paymentMethods,
  onSelect,
  selectedMethod,
  amount,
  currency,
  userCountry
}) => {
  const [groupedMethods, setGroupedMethods] = useState<Record<string, PaymentMethod[]>>({});

  useEffect(() => {
    // Group payment methods by type
    const grouped = paymentMethods.reduce((acc, method) => {
      if (!acc[method.type]) {
        acc[method.type] = [];
      }
      acc[method.type].push(method);
      return acc;
    }, {} as Record<string, PaymentMethod[]>);

    setGroupedMethods(grouped);
  }, [paymentMethods]);

  const getTypeDisplayName = (type: string) => {
    switch (type) {
      case 'card': return 'Cards';
      case 'upi': return 'UPI';
      default: return type.charAt(0).toUpperCase() + type.slice(1);
    }
  };

  const isMethodAvailable = (method: PaymentMethod) => {
    if (method.minAmount && amount < method.minAmount) return false;
    if (method.maxAmount && amount > method.maxAmount) return false;
    return true;
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h3 className="text-lg font-semibold text-[#8B4769] mb-2">Choose Payment Method</h3>
        <p className="text-sm text-[#8B4769]/70">
          Pay ₹{amount.toFixed(2)} securely with your preferred method
        </p>
      </div>

      {Object.entries(groupedMethods).map(([type, methods]) => (
        <div key={type} className="space-y-3">
          <h4 className="font-medium text-[#8B4769] flex items-center gap-2">
            {getMethodIcon(type)}
            {getTypeDisplayName(type)}
            {type === 'upi' && userCountry === 'IN' && (
              <span className="bg-green-100 text-green-600 text-xs px-2 py-1 rounded-full">
                Recommended
              </span>
            )}
          </h4>
          
          <div className="grid grid-cols-1 gap-2">
            {methods.map((method) => {
              const isAvailable = isMethodAvailable(method);
              const isSelected = selectedMethod?.id === method.id;
              
              return (
                <motion.button
                  key={method.id}
                  whileHover={isAvailable ? { scale: 1.02 } : {}}
                  whileTap={isAvailable ? { scale: 0.98 } : {}}
                  onClick={() => isAvailable && onSelect(method)}
                  disabled={!isAvailable}
                  className={`
                    p-4 rounded-xl border-2 text-left transition-all duration-200
                    ${isSelected 
                      ? 'border-[#8B4769] bg-[#8B4769]/5' 
                      : isAvailable
                      ? `${getMethodColor(method.type)} hover:border-[#8B4769]/50`
                      : 'bg-gray-50 border-gray-200 text-gray-400 cursor-not-allowed'
                    }
                  `}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{method.icon}</span>
                      <div>
                        <div className="font-medium">{method.name}</div>
                        {method.isPopular && (
                          <div className="text-xs text-green-600 font-medium">Popular</div>
                        )}
                        {!isAvailable && method.minAmount && (
                          <div className="text-xs text-red-600">
                            Minimum amount: ₹{method.minAmount}
                          </div>
                        )}
                      </div>
                    </div>
                    
                    {isSelected && (
                      <div className="w-5 h-5 bg-[#8B4769] rounded-full flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full" />
                      </div>
                    )}
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>
      ))}

      {paymentMethods.length === 0 && (
        <div className="text-center py-8">
          <div className="text-[#8B4769]/50 mb-2">No payment methods available</div>
          <div className="text-sm text-[#8B4769]/70">
            Please check your location settings or try again later
          </div>
        </div>
      )}

      <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
        <div className="text-sm text-blue-800">
          <div className="font-medium mb-1">🔒 Secure Payment</div>
          <div>Your payment information is encrypted and secure. We never store your payment details.</div>
        </div>
      </div>
    </div>
  );
};