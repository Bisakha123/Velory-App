import React from 'react';
import { Routes, Route } from "react-router-dom";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { Box } from "./screens/Box";
import { Tasks } from "./screens/Tasks";
import { Trackers } from "./screens/Trackers";
import { Profile } from "./screens/Profile";
import { Settings } from "./screens/Settings";
import { Subscription } from "./screens/Subscription";
import { Writeups, ThoughtsJournal, GratitudeLog, CreativeWriting, Goals, Journal, Autobiography } from "./screens/Writeups";

export function App() {
  return (
    <ProtectedRoute>
      <Routes>
        <Route path="/" element={<Box />} />
        <Route path="/tasks" element={<Tasks />} />
        <Route path="/trackers" element={<Trackers />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/subscription" element={<Subscription />} />
        <Route path="/writeups" element={<Writeups />} />
        <Route path="/writeups/thoughts" element={<ThoughtsJournal />} />
        <Route path="/writeups/gratitude" element={<GratitudeLog />} />
        <Route path="/writeups/creative" element={<CreativeWriting />} />
        <Route path="/writeups/autobiography" element={<Autobiography />} />
        <Route path="/writeups/journal" element={<Journal />} />
        <Route path="/writeups/dreams" element={<Writeups />} />
        <Route path="/writeups/goals" element={<Goals />} />
      </Routes>
    </ProtectedRoute>
  );
}