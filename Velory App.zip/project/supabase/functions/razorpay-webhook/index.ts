import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { createHmac } from 'https://deno.land/std@0.168.0/node/crypto.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-razorpay-signature',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    // Get environment variables
    const RAZORPAY_WEBHOOK_SECRET = Deno.env.get('RAZORPAY_WEBHOOK_SECRET')
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL')
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')

    if (!RAZORPAY_WEBHOOK_SECRET || !SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      throw new Error('Required environment variables not configured')
    }

    // Get webhook signature
    const signature = req.headers.get('x-razorpay-signature')
    if (!signature) {
      throw new Error('Missing webhook signature')
    }

    // Get request body
    const body = await req.text()
    
    // Verify webhook signature
    const expectedSignature = createHmac('sha256', RAZORPAY_WEBHOOK_SECRET)
      .update(body)
      .digest('hex')

    if (expectedSignature !== signature) {
      console.error('❌ Webhook signature verification failed')
      throw new Error('Webhook verification failed')
    }

    console.log('✅ Webhook signature verified successfully')

    // Parse webhook payload
    const payload = JSON.parse(body)
    const event = payload.event
    const paymentEntity = payload.payload?.payment?.entity
    const orderEntity = payload.payload?.order?.entity

    console.log('📨 Webhook event received:', event)

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)

    // Handle different webhook events
    switch (event) {
      case 'payment.captured':
        console.log('💰 Payment captured:', paymentEntity?.id)
        
        if (paymentEntity && orderEntity) {
          // Update payment order status
          await supabase
            .from('payment_orders')
            .update({
              status: 'captured',
              payment_id: paymentEntity.id,
              webhook_data: payload,
              updated_at: new Date().toISOString()
            })
            .eq('order_id', orderEntity.id)
        }
        break

      case 'payment.failed':
        console.log('❌ Payment failed:', paymentEntity?.id)
        
        if (paymentEntity && orderEntity) {
          // Update payment order status
          await supabase
            .from('payment_orders')
            .update({
              status: 'failed',
              payment_id: paymentEntity.id,
              webhook_data: payload,
              updated_at: new Date().toISOString()
            })
            .eq('order_id', orderEntity.id)
        }
        break

      case 'subscription.charged':
        console.log('🔄 Subscription charged:', payload.payload?.subscription?.entity?.id)
        // Handle subscription renewal
        break

      default:
        console.log('ℹ️ Unhandled webhook event:', event)
    }

    return new Response(
      JSON.stringify({ success: true, message: 'Webhook processed successfully' }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    )

  } catch (error) {
    console.error('❌ Webhook processing error:', error)
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'Webhook processing failed'
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      },
    )
  }
})