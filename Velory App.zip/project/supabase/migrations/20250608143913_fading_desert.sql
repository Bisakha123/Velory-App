/*
  # Media Trackers Schema

  1. New Tables
    - `trackers`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `name` (text)
      - `type` (text) - show, book, custom
      - `image_url` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `media_items`
      - `id` (uuid, primary key)
      - `tracker_id` (uuid, references trackers)
      - `user_id` (uuid, references profiles)
      - `title` (text)
      - `description` (text)
      - `type` (text) - show, book
      - `genres` (text array)
      - `status` (text) - pending, ongoing, completed
      - `total_seasons` (integer)
      - `total_episodes` (integer)
      - `watched_episodes` (integer)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Add policies for users to manage their own data

  3. Functions
    - Auto-update status based on progress
*/

CREATE TABLE IF NOT EXISTS trackers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('show', 'book', 'custom')),
  image_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS media_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tracker_id uuid REFERENCES trackers(id) ON DELETE CASCADE,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text DEFAULT '',
  type text NOT NULL CHECK (type IN ('show', 'book')),
  genres text[] DEFAULT '{}',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'ongoing', 'completed')),
  total_seasons integer,
  total_episodes integer,
  watched_episodes integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE trackers ENABLE ROW LEVEL SECURITY;
ALTER TABLE media_items ENABLE ROW LEVEL SECURITY;

-- Trackers policies
CREATE POLICY "Users can read own trackers"
  ON trackers
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own trackers"
  ON trackers
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own trackers"
  ON trackers
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own trackers"
  ON trackers
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Media items policies
CREATE POLICY "Users can read own media items"
  ON media_items
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own media items"
  ON media_items
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own media items"
  ON media_items
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own media items"
  ON media_items
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS trackers_user_id_idx ON trackers(user_id);
CREATE INDEX IF NOT EXISTS media_items_user_id_idx ON media_items(user_id);
CREATE INDEX IF NOT EXISTS media_items_tracker_id_idx ON media_items(tracker_id);
CREATE INDEX IF NOT EXISTS media_items_status_idx ON media_items(status);
CREATE INDEX IF NOT EXISTS media_items_type_idx ON media_items(type);

-- Triggers for updated_at
CREATE TRIGGER update_trackers_updated_at
  BEFORE UPDATE ON trackers
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_media_items_updated_at
  BEFORE UPDATE ON media_items
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Function to auto-update media item status based on progress
CREATE OR REPLACE FUNCTION update_media_status()
RETURNS trigger AS $$
BEGIN
  IF NEW.total_episodes IS NOT NULL AND NEW.watched_episodes IS NOT NULL THEN
    IF NEW.watched_episodes >= NEW.total_episodes THEN
      NEW.status = 'completed';
    ELSIF NEW.watched_episodes > 0 THEN
      NEW.status = 'ongoing';
    ELSE
      NEW.status = 'pending';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER media_status_trigger
  BEFORE INSERT OR UPDATE ON media_items
  FOR EACH ROW
  EXECUTE FUNCTION update_media_status();