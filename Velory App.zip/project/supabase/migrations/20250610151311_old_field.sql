/*
  # Fix User Signup Trigger

  1. Changes
    - Update handle_new_user function to properly handle null/empty usernames
    - Use NULLIF with COALESCE to ensure robust username defaulting
*/

-- Function to handle profile creation on user signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO profiles (id, username)
  VALUES (new.id, COALESCE(NULLIF(new.raw_user_meta_data->>'username', ''), 'User'));
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;