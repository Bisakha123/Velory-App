/*
  # Add metadata column to coupon_codes table

  1. Changes
    - Add metadata jsonb column to coupon_codes table
    - Update existing coupon codes to have empty metadata if needed
*/

-- Add metadata column to coupon_codes table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'coupon_codes' AND column_name = 'metadata'
  ) THEN
    ALTER TABLE coupon_codes ADD COLUMN metadata jsonb DEFAULT '{}';
  END IF;
END $$;

-- Update existing coupon codes to have default metadata
UPDATE coupon_codes SET metadata = '{}' WHERE metadata IS NULL;