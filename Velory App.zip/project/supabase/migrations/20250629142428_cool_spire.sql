/*
  # Fix Coupon Discount Type Constraint

  1. Changes
    - Update the check constraint on coupon_codes table to include 'free_access' type
    - This allows creating all types of coupons: percentage, fixed, and free_access

  2. Security
    - Maintains data integrity while expanding allowed discount types
    - Preserves existing RLS policies
*/

-- Drop the existing check constraint
ALTER TABLE coupon_codes DROP CONSTRAINT IF EXISTS coupon_codes_discount_type_check;

-- Add the updated check constraint with 'free_access' included
ALTER TABLE coupon_codes ADD CONSTRAINT coupon_codes_discount_type_check 
  CHECK (discount_type IN ('percentage', 'fixed', 'free_access'));