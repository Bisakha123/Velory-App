/*
  # Payment Orders Table

  1. New Tables
    - `payment_orders`
      - Stores Razorpay order information for verification
      - Links orders to users and subscription plans
      - Tracks payment status and completion

  2. Security
    - Enable RLS on payment_orders table
    - Add policies for payment order management

  3. Indexes
    - Index on order_id for quick lookups
    - Index on user_id for user-specific queries
*/

CREATE TABLE IF NOT EXISTS payment_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id text UNIQUE NOT NULL,
  payment_id text,
  signature text,
  amount decimal(10,2) NOT NULL,
  currency text NOT NULL DEFAULT 'INR',
  plan_id text NOT NULL,
  billing_cycle text NOT NULL CHECK (billing_cycle IN ('monthly', 'yearly')),
  customer_email text NOT NULL,
  status text NOT NULL DEFAULT 'created' CHECK (status IN ('created', 'completed', 'failed', 'captured')),
  razorpay_order_data jsonb,
  webhook_data jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

ALTER TABLE payment_orders ENABLE ROW LEVEL SECURITY;

-- Payment orders policies
CREATE POLICY "Users can read own payment orders"
  ON payment_orders
  FOR SELECT
  TO authenticated
  USING (customer_email = (SELECT email FROM auth.users WHERE id = auth.uid()));

CREATE POLICY "Service role can manage all payment orders"
  ON payment_orders
  FOR ALL
  TO service_role
  USING (true);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS payment_orders_order_id_idx ON payment_orders(order_id);
CREATE INDEX IF NOT EXISTS payment_orders_customer_email_idx ON payment_orders(customer_email);
CREATE INDEX IF NOT EXISTS payment_orders_status_idx ON payment_orders(status);
CREATE INDEX IF NOT EXISTS payment_orders_created_at_idx ON payment_orders(created_at DESC);

-- Trigger for payment_orders updated_at
CREATE TRIGGER update_payment_orders_updated_at
  BEFORE UPDATE ON payment_orders
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();