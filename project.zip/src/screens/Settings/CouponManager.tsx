import React, { useState, useEffect } from 'react';
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { motion } from "framer-motion";
import { Plus, Copy, Trash2, Eye, EyeOff, Calendar, Users, Percent, DollarSign, Crown } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface CouponCode {
  id: string;
  code: string;
  discount_type: 'percentage' | 'fixed' | 'free_access';
  discount_value: number;
  max_uses?: number;
  used_count: number;
  valid_from: string;
  valid_until?: string;
  applicable_plans: string[];
  is_active: boolean;
  metadata: {
    free_access_duration_months?: number;
    description?: string;
  };
  created_at: string;
}

interface CouponManagerProps {
  onClose: () => void;
}

export const CouponManager: React.FC<CouponManagerProps> = ({ onClose }) => {
  const [coupons, setCoupons] = useState<CouponCode[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showAdminKey, setShowAdminKey] = useState(false);
  const [adminKey, setAdminKey] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  const [newCoupon, setNewCoupon] = useState({
    code: '',
    discount_type: 'percentage' as 'percentage' | 'fixed' | 'free_access',
    discount_value: 0,
    max_uses: 100,
    valid_until: '',
    applicable_plans: ['plus', 'pro'],
    description: '',
    free_access_duration_months: 1
  });

  // Admin authentication
  const ADMIN_KEY = 'VISHU THE PSU GIRL'; // Change this to your secret key

  useEffect(() => {
    if (isAuthenticated) {
      loadCoupons();
    }
  }, [isAuthenticated]);

  const handleAdminAuth = () => {
    if (adminKey === ADMIN_KEY) {
      setIsAuthenticated(true);
      setShowAdminKey(false);
    } else {
      alert('Invalid admin key');
    }
  };

  const loadCoupons = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('coupon_codes')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      // Ensure metadata exists for all coupons
      const couponsWithMetadata = (data || []).map(coupon => ({
        ...coupon,
        metadata: coupon.metadata || {}
      }));
      
      setCoupons(couponsWithMetadata);
    } catch (error) {
      console.error('Error loading coupons:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateRandomCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < 8; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  };

  const createCoupon = async () => {
    if (!newCoupon.code.trim()) {
      setNewCoupon(prev => ({ ...prev, code: generateRandomCode() }));
      return;
    }

    try {
      const couponData = {
        code: newCoupon.code.toUpperCase(),
        discount_type: newCoupon.discount_type,
        discount_value: newCoupon.discount_value,
        max_uses: newCoupon.max_uses,
        valid_until: newCoupon.valid_until ? new Date(newCoupon.valid_until).toISOString() : null,
        applicable_plans: newCoupon.applicable_plans,
        is_active: true,
        metadata: {
          description: newCoupon.description || '',
          ...(newCoupon.discount_type === 'free_access' && {
            free_access_duration_months: newCoupon.free_access_duration_months
          })
        }
      };

      const { error } = await supabase
        .from('coupon_codes')
        .insert([couponData]);

      if (error) throw error;

      await loadCoupons();
      setShowCreateDialog(false);
      setNewCoupon({
        code: '',
        discount_type: 'percentage',
        discount_value: 0,
        max_uses: 100,
        valid_until: '',
        applicable_plans: ['plus', 'pro'],
        description: '',
        free_access_duration_months: 1
      });
    } catch (error) {
      console.error('Error creating coupon:', error);
      alert('Error creating coupon: ' + error.message);
    }
  };

  const toggleCouponStatus = async (couponId: string, isActive: boolean) => {
    try {
      const { error } = await supabase
        .from('coupon_codes')
        .update({ is_active: !isActive })
        .eq('id', couponId);

      if (error) throw error;
      await loadCoupons();
    } catch (error) {
      console.error('Error updating coupon:', error);
    }
  };

  const deleteCoupon = async (couponId: string) => {
    if (!confirm('Are you sure you want to delete this coupon?')) return;

    try {
      const { error } = await supabase
        .from('coupon_codes')
        .delete()
        .eq('id', couponId);

      if (error) throw error;
      await loadCoupons();
    } catch (error) {
      console.error('Error deleting coupon:', error);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copied to clipboard!');
  };

  if (!isAuthenticated) {
    return (
      <div className="space-y-6">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-[#8B4769] mb-4">Admin Access Required</h2>
          <p className="text-[#8B4769]/80 mb-6">Enter the admin key to manage coupon codes</p>
          
          <div className="max-w-sm mx-auto space-y-4">
            <div className="relative">
              <input
                type={showAdminKey ? 'text' : 'password'}
                value={adminKey}
                onChange={(e) => setAdminKey(e.target.value)}
                placeholder="Enter admin key"
                className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50 pr-12"
                onKeyPress={(e) => e.key === 'Enter' && handleAdminAuth()}
              />
              <button
                onClick={() => setShowAdminKey(!showAdminKey)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#8B4769]/50"
              >
                {showAdminKey ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
            
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={onClose}
                className="flex-1 border-[#8B4769] text-[#8B4769]"
              >
                Cancel
              </Button>
              <Button
                onClick={handleAdminAuth}
                className="flex-1 bg-[#8B4769] text-white hover:bg-[#96536F]"
              >
                Access
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-[#8B4769]">Coupon Management</h2>
        <div className="flex gap-2">
          <Button
            onClick={() => setShowCreateDialog(true)}
            className="bg-[#8B4769] text-white hover:bg-[#96536F]"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Coupon
          </Button>
          <Button
            variant="outline"
            onClick={onClose}
            className="border-[#8B4769] text-[#8B4769]"
          >
            Close
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-8">
          <div className="text-[#8B4769]">Loading coupons...</div>
        </div>
      ) : (
        <div className="space-y-4">
          {coupons.map((coupon) => (
            <motion.div
              key={coupon.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`bg-white/80 rounded-xl p-4 border-2 ${
                coupon.is_active ? 'border-green-300' : 'border-gray-300'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <code className="bg-[#8B4769]/10 px-3 py-1 rounded-lg font-mono text-lg font-bold text-[#8B4769]">
                      {coupon.code}
                    </code>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(coupon.code)}
                      className="text-[#8B4769]"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      coupon.is_active 
                        ? 'bg-green-100 text-green-600' 
                        : 'bg-gray-100 text-gray-600'
                    }`}>
                      {coupon.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-[#8B4769]/70">Type:</span>
                      <div className="font-medium text-[#8B4769] flex items-center gap-1">
                        {coupon.discount_type === 'percentage' && <Percent className="w-3 h-3" />}
                        {coupon.discount_type === 'fixed' && <DollarSign className="w-3 h-3" />}
                        {coupon.discount_type === 'free_access' && <Crown className="w-3 h-3" />}
                        {coupon.discount_type === 'free_access' 
                          ? `Free ${coupon.metadata?.free_access_duration_months || 1}mo`
                          : coupon.discount_type === 'percentage' 
                          ? `${coupon.discount_value}% off`
                          : `$${coupon.discount_value} off`
                        }
                      </div>
                    </div>

                    <div>
                      <span className="text-[#8B4769]/70">Usage:</span>
                      <div className="font-medium text-[#8B4769] flex items-center gap-1">
                        <Users className="w-3 h-3" />
                        {coupon.used_count}/{coupon.max_uses || '∞'}
                      </div>
                    </div>

                    <div>
                      <span className="text-[#8B4769]/70">Plans:</span>
                      <div className="font-medium text-[#8B4769]">
                        {coupon.applicable_plans.join(', ').toUpperCase()}
                      </div>
                    </div>

                    <div>
                      <span className="text-[#8B4769]/70">Expires:</span>
                      <div className="font-medium text-[#8B4769] flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {coupon.valid_until 
                          ? new Date(coupon.valid_until).toLocaleDateString()
                          : 'Never'
                        }
                      </div>
                    </div>
                  </div>

                  {coupon.metadata?.description && (
                    <div className="mt-2 text-sm text-[#8B4769]/70">
                      {coupon.metadata.description}
                    </div>
                  )}
                </div>

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => toggleCouponStatus(coupon.id, coupon.is_active)}
                    className={coupon.is_active ? 'text-orange-600' : 'text-green-600'}
                  >
                    {coupon.is_active ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => deleteCoupon(coupon.id)}
                    className="text-red-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}

          {coupons.length === 0 && (
            <div className="text-center py-8 text-[#8B4769]/70">
              No coupons created yet. Create your first coupon to get started!
            </div>
          )}
        </div>
      )}

      {/* Create Coupon Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="sm:max-w-[600px] bg-[#FEE2E2]/95 max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-[#8B4769]">Create New Coupon</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2 text-[#8B4769]">
                  Coupon Code
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newCoupon.code}
                    onChange={(e) => setNewCoupon({ ...newCoupon, code: e.target.value.toUpperCase() })}
                    placeholder="Enter code or leave empty"
                    className="flex-1 p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
                  />
                  <Button
                    type="button"
                    onClick={() => setNewCoupon({ ...newCoupon, code: generateRandomCode() })}
                    variant="outline"
                    className="border-[#8B4769] text-[#8B4769]"
                  >
                    Generate
                  </Button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 text-[#8B4769]">
                  Discount Type
                </label>
                <select
                  value={newCoupon.discount_type}
                  onChange={(e) => setNewCoupon({ 
                    ...newCoupon, 
                    discount_type: e.target.value as 'percentage' | 'fixed' | 'free_access',
                    discount_value: e.target.value === 'free_access' ? 0 : newCoupon.discount_value
                  })}
                  className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
                >
                  <option value="percentage">Percentage Discount</option>
                  <option value="fixed">Fixed Amount Discount</option>
                  <option value="free_access">Free Access</option>
                </select>
              </div>
            </div>

            {newCoupon.discount_type !== 'free_access' && (
              <div>
                <label className="block text-sm font-medium mb-2 text-[#8B4769]">
                  Discount Value {newCoupon.discount_type === 'percentage' ? '(%)' : '($)'}
                </label>
                <input
                  type="number"
                  value={newCoupon.discount_value}
                  onChange={(e) => setNewCoupon({ ...newCoupon, discount_value: Number(e.target.value) })}
                  min="0"
                  max={newCoupon.discount_type === 'percentage' ? 100 : undefined}
                  className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
                />
              </div>
            )}

            {newCoupon.discount_type === 'free_access' && (
              <div>
                <label className="block text-sm font-medium mb-2 text-[#8B4769]">
                  Free Access Duration (Months)
                </label>
                <input
                  type="number"
                  value={newCoupon.free_access_duration_months}
                  onChange={(e) => setNewCoupon({ ...newCoupon, free_access_duration_months: Number(e.target.value) })}
                  min="1"
                  max="12"
                  className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
                />
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2 text-[#8B4769]">
                  Max Uses
                </label>
                <input
                  type="number"
                  value={newCoupon.max_uses}
                  onChange={(e) => setNewCoupon({ ...newCoupon, max_uses: Number(e.target.value) })}
                  min="1"
                  className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 text-[#8B4769]">
                  Expiry Date (Optional)
                </label>
                <input
                  type="date"
                  value={newCoupon.valid_until}
                  onChange={(e) => setNewCoupon({ ...newCoupon, valid_until: e.target.value })}
                  className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2 text-[#8B4769]">
                Applicable Plans
              </label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={newCoupon.applicable_plans.includes('plus')}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setNewCoupon({ 
                          ...newCoupon, 
                          applicable_plans: [...newCoupon.applicable_plans, 'plus'] 
                        });
                      } else {
                        setNewCoupon({ 
                          ...newCoupon, 
                          applicable_plans: newCoupon.applicable_plans.filter(p => p !== 'plus') 
                        });
                      }
                    }}
                    className="rounded"
                  />
                  <span className="text-[#8B4769]">Plus</span>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={newCoupon.applicable_plans.includes('pro')}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setNewCoupon({ 
                          ...newCoupon, 
                          applicable_plans: [...newCoupon.applicable_plans, 'pro'] 
                        });
                      } else {
                        setNewCoupon({ 
                          ...newCoupon, 
                          applicable_plans: newCoupon.applicable_plans.filter(p => p !== 'pro') 
                        });
                      }
                    }}
                    className="rounded"
                  />
                  <span className="text-[#8B4769]">Pro</span>
                </label>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2 text-[#8B4769]">
                Description (Optional)
              </label>
              <textarea
                value={newCoupon.description}
                onChange={(e) => setNewCoupon({ ...newCoupon, description: e.target.value })}
                placeholder="Internal description for this coupon"
                className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50 min-h-[80px] resize-none"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowCreateDialog(false)}
              className="border-[#8B4769] text-[#8B4769]"
            >
              Cancel
            </Button>
            <Button
              onClick={createCoupon}
              disabled={!newCoupon.applicable_plans.length}
              className="bg-[#8B4769] text-white hover:bg-[#96536F]"
            >
              Create Coupon
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};