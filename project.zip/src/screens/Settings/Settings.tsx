import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { motion } from "framer-motion";
import { 
  ArrowLeft, 
  Bell, 
  Download, 
  Trash2, 
  MessageSquare, 
  Info, 
  FileText, 
  Shield, 
  LogOut,
  ChevronRight,
  BellRing,
  AlertCircle,
  CheckCircle,
  HardDrive,
  Crown,
  Lock,
  Gift
} from 'lucide-react';
import { useNotifications } from '../../hooks/useNotifications';
import { BackupRestore } from './BackupRestore';
import { CouponManager } from './CouponManager';
import { useAuthContext } from '../../components/AuthProvider';
import { useSubscription } from '../../hooks/useSubscription';
import { authApi } from '../../lib/api';

interface DialogContent {
  title: string;
  content: string;
}

export const Settings = () => {
  const navigate = useNavigate();
  const { signOut } = useAuthContext();
  const { subscriptionData, canUseBackups } = useSubscription();
  const { 
    permission, 
    isSupported, 
    requestPermission, 
    showTestNotification 
  } = useNotifications();
  
  const [showDialog, setShowDialog] = useState(false);
  const [dialogContent, setDialogContent] = useState<DialogContent>({ title: '', content: '' });
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [showClearDataConfirm, setShowClearDataConfirm] = useState(false);
  const [showNotificationDialog, setShowNotificationDialog] = useState(false);
  const [showBackupRestore, setShowBackupRestore] = useState(false);
  const [showCouponManager, setShowCouponManager] = useState(false);
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const handleNotificationToggle = async () => {
    if (!isSupported) {
      alert('Notifications are not supported in this browser');
      return;
    }

    if (permission.granted) {
      // Show test notification
      await showTestNotification();
    } else if (permission.denied) {
      // Show instructions to enable in browser settings
      setShowNotificationDialog(true);
    } else {
      // Request permission
      const newPermission = await requestPermission();
      if (newPermission.granted) {
        await showTestNotification();
      }
    }
  };

  const handleClearAllData = async () => {
    setIsClearing(true);
    try {
      await authApi.clearAllUserData();
      
      // Clear local storage as well
      localStorage.clear();
      
      // Show success message
      alert('All data has been cleared successfully! Redirecting to home...');
      
      // Navigate to home instead of reloading
      navigate('/', { replace: true });
    } catch (error) {
      console.error('Error clearing data:', error);
      alert(`Failed to clear data: ${error.message}`);
    } finally {
      setIsClearing(false);
      setShowClearDataConfirm(false);
    }
  };

  const handleLogout = async () => {
    setIsLoggingOut(true);
    try {
      await signOut();
      console.log('User logged out successfully');
      // The auth context will handle redirecting to login screen
      // and ProtectedRoute will ensure we go to home after re-login
    } catch (error) {
      console.error('Error during logout:', error);
      alert(`Failed to logout: ${error.message}`);
    } finally {
      setIsLoggingOut(false);
      setShowLogoutConfirm(false);
    }
  };

  const handleBackupClick = () => {
    if (!canUseBackups()) {
      setShowUpgradeDialog(true);
      return;
    }
    setShowBackupRestore(true);
  };

  const showInfoDialog = (title: string, content: string) => {
    setDialogContent({ title, content });
    setShowDialog(true);
  };

  const getNotificationStatus = () => {
    if (!isSupported) {
      return { icon: AlertCircle, text: 'Not Supported', color: 'text-gray-500' };
    }
    if (permission.granted) {
      return { icon: CheckCircle, text: 'Enabled', color: 'text-green-600' };
    }
    if (permission.denied) {
      return { icon: AlertCircle, text: 'Blocked', color: 'text-red-600' };
    }
    return { icon: Bell, text: 'Not Set', color: 'text-orange-600' };
  };

  const notificationStatus = getNotificationStatus();

  const contactFeedbackContent = `
    We'd love to hear from you! 

    📧 Email: team.velory@gmail.com
    📱 Instagram: @veloryapp

    For bug reports, feature requests, or general feedback, please reach out to us. We typically respond within 24 hours.

    Your feedback helps us improve the app for everyone!
  `;

  const developerCreditsContent = `
    Velory: Write it. Plan it. Live it.

    👨‍💻 Developed by: A solo developer
    🎨 UI/UX Design: Independently crafted
    📱 Version: 1.0.3
    🛠️ Built with: React, TypeScript, Tailwind CSS

    Special thanks to everyone who supported and inspired this project.

    © 2025 Velory. All rights reserved.
  `;

  const termsConditionsContent = `
    Terms & Conditions
    
    Last updated: January 2025

    1. ACCEPTANCE OF TERMS
    By using Velory, you agree to these terms.
 
    2. USE OF SERVICE
    Use the app for personal organization only

    Do not share your account with others

    You are responsible for keeping your data and login credentials secure

    3. DATA PRIVACY
    Your data is stored securely using Supabase, a managed backend service

    All sensitive information is encrypted at rest and in transit

    We do not access or sell your personal data

    Backups are handled securely through Supabase's infrastructure

    4. LIMITATIONS
    The service is provided "as is", without warranties of any kind

    We are not responsible for any temporary service interruptions

    Data loss is not our liability — please use the built-in backup/export features regularly

  `;

  const privacyPolicyContent = `
    Privacy Policy

    Last updated: January 2025

    1. INFORMATION WE COLLECT
    - Account information (email, username)
    - App usage data (tasks, notes, etc.)
    - No tracking or analytics data

    2. HOW WE USE INFORMATION
    - Provide app functionality
    - Sync data across your devices
    - No sharing with third parties

    3. DATA STORAGE
    - Secure cloud storage via Supabase
    - Encrypted data transmission
    - Regular security updates

    4. BACKUPS
    - Local backup options available
    - You control your backup data
    - Export data anytime

    5. YOUR RIGHTS
    - Access your data anytime
    - Delete your account and data
    - Export data via backup

    6. CONTACT
    Questions? Email: team.velory@gmail.com

  `;

  if (showBackupRestore) {
    return (
      <div
        className="min-h-screen bg-cover bg-center p-4 font-['Quicksand']"
        style={{
          backgroundImage: "url('https://res.cloudinary.com/db6un9uvp/image/upload/v1745916296/Autobiography_bg_fyshzv.png')",
          backgroundBlendMode: 'multiply',
          backgroundColor: 'rgba(255, 192, 203, 0.7)'
        }}
      >
        <div className="max-w-4xl mx-auto">
          <BackupRestore onClose={() => setShowBackupRestore(false)} />
        </div>
      </div>
    );
  }

  if (showCouponManager) {
    return (
      <div
        className="min-h-screen bg-cover bg-center p-4 font-['Quicksand']"
        style={{
          backgroundImage: "url('https://res.cloudinary.com/db6un9uvp/image/upload/v1745916296/Autobiography_bg_fyshzv.png')",
          backgroundBlendMode: 'multiply',
          backgroundColor: 'rgba(255, 192, 203, 0.7)'
        }}
      >
        <div className="max-w-6xl mx-auto">
          <CouponManager onClose={() => setShowCouponManager(false)} />
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-cover bg-center p-4 font-['Quicksand']"
      style={{
        backgroundImage: "url('https://res.cloudinary.com/db6un9uvp/image/upload/v1745916296/Autobiography_bg_fyshzv.png')",
        backgroundBlendMode: 'multiply',
        backgroundColor: 'rgba(255, 192, 203, 0.7)'
      }}
    >
      <div className="flex items-center justify-between mb-8">
        <Button 
          variant="ghost" 
          onClick={() => navigate('/', { state: { fromNavigation: true } })}
          className="text-[#8B4769] -ml-3"
        >
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-4xl font-extrabold text-[#8B4769] mb-2 tracking-wide font-['Indie Flower']">
            Settings
          </h1>
        </motion.div>
        <Button 
          variant="ghost" 
          onClick={() => navigate("/subscription", { state: { fromNavigation: true } })}
          className="text-[#8B4769]"
        >
          <Crown className="w-6 h-6" />
        </Button>
      </div>

      <div className="max-w-2xl mx-auto space-y-3">
        {/* Subscription Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/80 rounded-2xl p-4 border-2 border-[#8B4769]/20 cursor-pointer hover:bg-white/90 transition-all"
          onClick={() => navigate('/subscription')}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                <Crown className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-base font-semibold text-[#8B4769]">Subscription</h3>
                <p className="text-xs text-[#8B4769]/70">
                  Current: {subscriptionData?.plan?.display_name || 'Velory Free'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                subscriptionData?.plan?.id === 'pro' 
                  ? 'bg-purple-100 text-purple-600'
                  : subscriptionData?.plan?.id === 'plus'
                  ? 'bg-blue-100 text-blue-600'
                  : 'bg-gray-100 text-gray-600'
              }`}>
                {subscriptionData?.plan?.id === 'free' || !subscriptionData?.plan ? 'Free' : 
                 subscriptionData?.plan?.id === 'plus' ? 'Plus' : 'Pro'}
              </div>
              <ChevronRight className="w-4 h-4 text-[#8B4769]/50" />
            </div>
          </div>
        </motion.div>

        {/* Coupon Management */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          onClick={() => setShowCouponManager(true)}
          className="bg-white/80 rounded-2xl p-4 border-2 border-[#8B4769]/20 cursor-pointer hover:bg-white/90 transition-all"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-pink-200 rounded-full flex items-center justify-center">
                <Gift className="w-5 h-5 text-pink-600" />
              </div>
              <div>
                <h3 className="text-base font-semibold text-[#8B4769]">Coupon Management</h3>
                <p className="text-xs text-[#8B4769]/70">Create and manage discount codes</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#8B4769]/50" />
          </div>
        </motion.div>

        {/* Notifications */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white/80 rounded-2xl p-4 border-2 border-[#8B4769]/20 cursor-pointer hover:bg-white/90 transition-all"
          onClick={handleNotificationToggle}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-orange-200 rounded-full flex items-center justify-center">
                <BellRing className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <h3 className="text-base font-semibold text-[#8B4769]">Task Notifications</h3>
                <p className="text-xs text-[#8B4769]/70">Get reminders for task deadlines</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className={`flex items-center gap-1 ${notificationStatus.color}`}>
                <notificationStatus.icon className="w-4 h-4" />
                <span className="text-sm font-medium">{notificationStatus.text}</span>
              </div>
              <ChevronRight className="w-4 h-4 text-[#8B4769]/50" />
            </div>
          </div>
        </motion.div>

        {/* Backup & Restore */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          onClick={handleBackupClick}
          className="bg-white/80 rounded-2xl p-4 border-2 border-[#8B4769]/20 cursor-pointer hover:bg-white/90 transition-all"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-200 rounded-full flex items-center justify-center">
                <HardDrive className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h3 className="text-base font-semibold text-[#8B4769] flex items-center gap-2">
                  Backup & Restore
                  {!canUseBackups() && <Lock className="w-4 h-4 text-orange-500" />}
                </h3>
                <p className="text-xs text-[#8B4769]/70">
                  {canUseBackups() ? 'Local backup and restore options' : 'Available with Pro subscription'}
                </p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#8B4769]/50" />
          </div>
        </motion.div>

        {/* Clear All Data */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          onClick={() => setShowClearDataConfirm(true)}
          className="bg-white/80 rounded-2xl p-4 border-2 border-[#8B4769]/20 cursor-pointer hover:bg-white/90 transition-all"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-red-200 rounded-full flex items-center justify-center">
              <Trash2 className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-[#8B4769]">Clear All Data</h3>
              <p className="text-xs text-[#8B4769]/70">Delete all your data (keeps account)</p>
            </div>
          </div>
        </motion.div>

        {/* Contact & Feedback */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          onClick={() => showInfoDialog('Contact & Feedback', contactFeedbackContent)}
          className="bg-white/80 rounded-2xl p-4 border-2 border-[#8B4769]/20 cursor-pointer hover:bg-white/90 transition-all"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-200 rounded-full flex items-center justify-center">
                <MessageSquare className="w-5 h-5 text-purple-600" />
              </div>
              <h3 className="text-base font-semibold text-[#8B4769]">Contact & Feedback</h3>
            </div>
            <ChevronRight className="w-4 h-4 text-[#8B4769]/50" />
          </div>
        </motion.div>

        {/* App Version */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white/80 rounded-2xl p-4 border-2 border-[#8B4769]/20"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                <Info className="w-5 h-5 text-gray-600" />
              </div>
              <h3 className="text-base font-semibold text-[#8B4769]">App Version</h3>
            </div>
            <span className="text-[#8B4769]/70 font-medium text-sm">v1.0.3</span>
          </div>
        </motion.div>

        {/* Developer Credits */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          onClick={() => showInfoDialog('Developer Credits', developerCreditsContent)}
          className="bg-white/80 rounded-2xl p-4 border-2 border-[#8B4769]/20 cursor-pointer hover:bg-white/90 transition-all"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-200 rounded-full flex items-center justify-center">
                <FileText className="w-5 h-5 text-indigo-600" />
              </div>
              <h3 className="text-base font-semibold text-[#8B4769]">Developer Credits</h3>
            </div>
            <ChevronRight className="w-4 h-4 text-[#8B4769]/50" />
          </div>
        </motion.div>

        {/* Terms & Conditions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          onClick={() => showInfoDialog('Terms & Conditions', termsConditionsContent)}
          className="bg-white/80 rounded-2xl p-4 border-2 border-[#8B4769]/20 cursor-pointer hover:bg-white/90 transition-all"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-yellow-200 rounded-full flex items-center justify-center">
                <FileText className="w-5 h-5 text-yellow-600" />
              </div>
              <h3 className="text-base font-semibold text-[#8B4769]">Terms & Conditions</h3>
            </div>
            <ChevronRight className="w-4 h-4 text-[#8B4769]/50" />
          </div>
        </motion.div>

        {/* Privacy Policy */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          onClick={() => showInfoDialog('Privacy Policy', privacyPolicyContent)}
          className="bg-white/80 rounded-2xl p-4 border-2 border-[#8B4769]/20 cursor-pointer hover:bg-white/90 transition-all"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-teal-200 rounded-full flex items-center justify-center">
                <Shield className="w-5 h-5 text-teal-600" />
              </div>
              <h3 className="text-base font-semibold text-[#8B4769]">Privacy Policy</h3>
            </div>
            <ChevronRight className="w-4 h-4 text-[#8B4769]/50" />
          </div>
        </motion.div>

        {/* Logout */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          onClick={() => setShowLogoutConfirm(true)}
          className="bg-white/80 rounded-2xl p-4 border-2 border-[#8B4769]/20 cursor-pointer hover:bg-white/90 transition-all"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-orange-200 rounded-full flex items-center justify-center">
                <LogOut className="w-5 h-5 text-orange-600" />
              </div>
              <h3 className="text-base font-semibold text-[#8B4769]">Logout</h3>
            </div>
            <ChevronRight className="w-4 h-4 text-[#8B4769]/50" />
          </div>
        </motion.div>
      </div>

      {/* Upgrade Dialog for Backup */}
      <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
        <DialogContent className="w-[95vw] max-w-[400px] bg-white rounded-3xl p-6">
          <DialogHeader>
            <DialogTitle className="text-center text-xl font-semibold text-[#8B4769] mb-3">Upgrade Required</DialogTitle>
          </DialogHeader>
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <p className="text-[#8B4769]/80 mb-6">
              Backup & Restore is available with Velory Pro. Upgrade to securely backup and restore all your data.
            </p>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowUpgradeDialog(false)}
                className="flex-1 border-[#8B4769] text-[#8B4769]"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  setShowUpgradeDialog(false);
                  navigate('/subscription');
                }}
                className="flex-1 bg-[#8B4769] text-white hover:bg-[#96536F]"
              >
                <Crown className="w-4 h-4 mr-2" />
                Upgrade
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Notification Instructions Dialog */}
      <Dialog open={showNotificationDialog} onOpenChange={setShowNotificationDialog}>
        <DialogContent className="sm:max-w-[500px] bg-[#FEE2E2]/95">
          <DialogHeader>
            <DialogTitle className="text-[#8B4769] flex items-center gap-2">
              <Bell className="w-5 h-5" />
              Enable Notifications
            </DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-4">
            {permission.denied ? (
              <div className="space-y-3">
                <p className="text-[#8B4769]">
                  Notifications are currently blocked. To enable task reminders:
                </p>
                <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
                  <h4 className="font-semibold text-orange-800 mb-2">Browser Instructions:</h4>
                  <ol className="list-decimal list-inside space-y-1 text-sm text-orange-700">
                    <li>Click the lock icon in your browser's address bar</li>
                    <li>Find "Notifications" and change it to "Allow"</li>
                    <li>Refresh this page</li>
                    <li>Try enabling notifications again</li>
                  </ol>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-[#8B4769]">
                  Enable notifications to get reminders for your task deadlines:
                </p>
                <ul className="list-disc list-inside space-y-1 text-sm text-[#8B4769]/80">
                  <li>Get notified 1 hour before deadlines</li>
                  <li>30-minute warning reminders</li>
                  <li>5-minute final alerts</li>
                  <li>Works even when the app is closed</li>
                </ul>
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <p className="text-blue-800 text-sm">
                    <strong>Privacy:</strong> All notifications are handled locally on your device. 
                    No data is sent to external servers.
                  </p>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button
              onClick={() => setShowNotificationDialog(false)}
              className="bg-[#8B4769] text-white hover:bg-[#96536F]"
            >
              Got it
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Info Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-[500px] bg-[#FEE2E2]/95 max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-[#8B4769]">{dialogContent.title}</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <pre className="whitespace-pre-wrap text-sm text-[#8B4769] font-['Quicksand']">
              {dialogContent.content}
            </pre>
          </div>
          <DialogFooter>
            <Button
              onClick={() => setShowDialog(false)}
              className="bg-[#8B4769] text-white hover:bg-[#96536F]"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Logout Confirmation */}
      <Dialog open={showLogoutConfirm} onOpenChange={setShowLogoutConfirm}>
        <DialogContent className="sm:max-w-[400px] bg-[#FEE2E2]/95">
          <DialogHeader>
            <DialogTitle className="text-[#8B4769]">Confirm Logout</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p className="text-[#8B4769] mb-2">Are you sure you want to logout?</p>
            <p className="text-sm text-[#8B4769]/70">
              You'll be signed out of your account, but all your data will remain safe.
            </p>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowLogoutConfirm(false)}
              disabled={isLoggingOut}
              className="border-[#8B4769] text-[#8B4769]"
            >
              Cancel
            </Button>
            <Button
              onClick={handleLogout}
              disabled={isLoggingOut}
              className="bg-orange-600 text-white hover:bg-orange-700"
            >
              {isLoggingOut ? 'Logging out...' : 'Logout'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Clear Data Confirmation */}
      <Dialog open={showClearDataConfirm} onOpenChange={setShowClearDataConfirm}>
        <DialogContent className="sm:max-w-[400px] bg-[#FEE2E2]/95">
          <DialogHeader>
            <DialogTitle className="text-[#8B4769]">Clear All Data</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p className="text-[#8B4769] mb-2">
              <strong>Warning:</strong> This will permanently delete all your data including:
            </p>
            <ul className="list-disc list-inside text-sm text-[#8B4769] space-y-1 mb-4">
              <li>All tasks and deadlines</li>
              <li>Journal entries and writeups</li>
              <li>Mood tracking data</li>
              <li>Media trackers and progress</li>
              <li>Personal achievements</li>
              <li>Profile information (reset to defaults)</li>
            </ul>
            <div className="bg-blue-50 p-3 rounded-lg border border-blue-200 mb-3">
              <p className="text-blue-800 text-sm">
                <strong>Note:</strong> Your account will remain active. Only your data will be cleared.
              </p>
            </div>
            <p className="text-red-600 font-semibold">This action cannot be undone!</p>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowClearDataConfirm(false)}
              disabled={isClearing}
              className="border-[#8B4769] text-[#8B4769]"
            >
              Cancel
            </Button>
            <Button
              onClick={handleClearAllData}
              disabled={isClearing}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              {isClearing ? 'Clearing Data...' : 'Clear All Data'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};