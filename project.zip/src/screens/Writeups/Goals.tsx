import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';
import TextStyle from '@tiptap/extension-text-style';
import Color from '@tiptap/extension-color';
import Highlight from '@tiptap/extension-highlight';
import Underline from '@tiptap/extension-underline';
import TextAlign from '@tiptap/extension-text-align';
import { Button } from "../../components/ui/button";
import { Checkbox } from "../../components/ui/checkbox";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../../components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { motion } from "framer-motion";
import { ArrowLeft, Plus, Eye, Pencil, Trash2, Save, Clock, Check, X, Highlighter, Crown, Lock } from 'lucide-react';
import { format } from 'date-fns';
import { writeupsApi, type Writeup } from '../../lib/api';
import { useAuthContext } from '../../components/AuthProvider';
import { useSubscription } from '../../hooks/useSubscription';
import { UsageLimit } from '../../components/SubscriptionGate';

// Reduced and more accessible highlight colors
const HIGHLIGHT_COLORS = [
  { color: '#FFEB3B', name: 'Yellow' },
  { color: '#FF9800', name: 'Orange' },
  { color: '#4CAF50', name: 'Green' },
  { color: '#2196F3', name: 'Blue' },
  { color: '#E91E63', name: 'Pink' },
  { color: '#9C27B0', name: 'Purple' },
];

interface GoalData {
  content: string;
  completed: boolean;
}

export const Goals = () => {
  const navigate = useNavigate();
  const { user } = useAuthContext();
  const { checkLimit, incrementUsage, getLimit, isUnlimited } = useSubscription();
  const [goals, setGoals] = useState<Writeup[]>([]);
  const [selectedGoal, setSelectedGoal] = useState<Writeup | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [showHighlightPicker, setShowHighlightPicker] = useState(false);
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadGoals();
    }
  }, [user]);

  const loadGoals = async () => {
    try {
      setLoading(true);
      const data = await writeupsApi.getWriteups('goals');
      setGoals(data);
    } catch (error) {
      console.error('Error loading goals:', error);
    } finally {
      setLoading(false);
    }
  };

  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: true,
      }),
      Placeholder.configure({
        placeholder: 'Write your goal...',
      }),
      TextStyle,
      Color,
      Highlight.configure({
        multicolor: true,
      }),
      Underline,
      TextAlign.configure({
        types: ['paragraph', 'heading'],
      }),
    ],
    editorProps: {
      attributes: {
        class: 'prose prose-lg focus:outline-none max-w-none min-h-[300px] prose-headings:text-[#8B4769] prose-p:text-gray-700',
      },
    },
    editable: false,
  });

  const canCreateGoal = async () => {
    const canCreate = await checkLimit('goals_entries');
    if (!canCreate) {
      setShowUpgradeDialog(true);
      return false;
    }
    return true;
  };

  const handleNewGoal = async () => {
    if (!editor || !user?.id) return;
    
    // Check limits before creating
    const canCreate = await canCreateGoal();
    if (!canCreate) return;
    
    try {
      const newGoal = await writeupsApi.createWriteup({
        type: 'goals',
        title: 'New Goal',
        content: '',
        tags: [],
        metadata: { completed: false },
        user_id: user.id
      });

      // Increment usage for new goals
      await incrementUsage('goals_entries');

      await loadGoals(); // Refresh the list
      setSelectedGoal(newGoal);
      setIsEditing(true);
      editor.setEditable(true);
      editor.commands.setContent('');
    } catch (error) {
      console.error('Error creating goal:', error);
    }
  };

  const handleSave = async () => {
    if (!editor || !selectedGoal) return;
    
    try {
      const content = editor.getHTML();
      const updatedGoal = await writeupsApi.updateWriteup(selectedGoal.id, {
        content,
        title: getFirstLine(content) || 'Untitled Goal'
      });
      
      await loadGoals(); // Refresh the list
      setSelectedGoal(updatedGoal);
      setIsEditing(false);
      editor.setEditable(false);
    } catch (error) {
      console.error('Error saving goal:', error);
    }
  };

  const toggleGoalCompletion = async (goalId: string) => {
    try {
      const goal = goals.find(g => g.id === goalId);
      if (!goal) return;

      const currentCompleted = goal.metadata?.completed || false;
      const updatedGoal = await writeupsApi.updateWriteup(goalId, {
        metadata: { ...goal.metadata, completed: !currentCompleted }
      });

      await loadGoals(); // Refresh the list
    } catch (error) {
      console.error('Error updating goal completion:', error);
    }
  };

  const handleDelete = async (goalId: string) => {
    try {
      await writeupsApi.deleteWriteup(goalId);
      await loadGoals(); // Refresh the list
      
      if (selectedGoal?.id === goalId) {
        setSelectedGoal(null);
        setIsEditing(false);
      }
    } catch (error) {
      console.error('Error deleting goal:', error);
    }
  };

  const getFirstLine = (content: string) => {
    const div = document.createElement('div');
    div.innerHTML = content;
    const text = div.textContent || '';
    return text.split('\n')[0] || 'Untitled Goal';
  };

  const isGoalCompleted = (goal: Writeup) => {
    return goal.metadata?.completed || false;
  };

  const handleHighlightClick = (color: string | null) => {
    if (editor) {
      if (color === null) {
        editor.chain().focus().unsetHighlight().run();
      } else {
        editor.chain().focus().setHighlight({ color }).run();
      }
      setShowHighlightPicker(false);
    }
  };

  const goalsLimit = getLimit('goals_entries');
  const currentCount = goals.length;

  // Fixed navigation - replace current history entry to prevent back button loop
  const handleBackNavigation = () => {
    navigate('/writeups', { 
      state: { tab: 'journey' },
      replace: true // This replaces the current history entry instead of adding a new one
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FEE2E2] flex items-center justify-center">
        <div className="text-[#8B4769] text-xl font-semibold">Loading goals...</div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-cover bg-center p-4 font-['Quicksand']"
      style={{
        backgroundImage: "url('https://res.cloudinary.com/db6un9uvp/image/upload/v1745916296/Autobiography_bg_fyshzv.png')",
        backgroundBlendMode: 'multiply',
        backgroundColor: 'rgba(0, 0, 0, 0.2)'
      }}
    >
      <div className="flex items-center justify-between mb-8">
        <Button 
          variant="ghost" 
          onClick={handleBackNavigation}
          className="text-white -ml-3"
        >
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <Button 
          variant="ghost" 
          onClick={() => navigate("/subscription", { state: { fromNavigation: true } })}
          className="text-white"
        >
          <Crown className="w-6 h-6" />
        </Button>
      </div>

      <motion.div 
        className="text-center mb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-4xl font-extrabold text-white mb-2 tracking-wide font-['Indie Flower']">
          Goals
        </h1>
        <div className="flex items-center justify-center gap-3">
          <div className="h-0.5 w-12 bg-gradient-to-r from-transparent via-pink-400 to-transparent" />
          <span className="text-pink-300">✨</span>
          <div className="h-0.5 w-12 bg-gradient-to-r from-transparent via-pink-400 to-transparent" />
        </div>
      </motion.div>

      {!selectedGoal ? (
        <div className="max-w-2xl mx-auto space-y-4">
          {/* Usage Limit Display */}
          {!isUnlimited('goals_entries') && (
            <div className="mb-6">
              <UsageLimit
                resourceType="Goals"
                current={currentCount}
                limit={goalsLimit}
                unit="goals"
              />
            </div>
          )}

          {goals.map((goal, index) => {
            const completed = isGoalCompleted(goal);
            return (
              <motion.div
                key={goal.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className={`bg-white/80 shadow-lg rounded-2xl p-6 hover:bg-white/90 transition-all duration-300 border-2 ${
                  completed ? 'border-green-400/50' : 'border-[#8B4769]/20'
                }`}
              >
                <div className="flex items-start gap-4">
                  <Checkbox
                    checked={completed}
                    onCheckedChange={() => toggleGoalCompletion(goal.id)}
                    className={`mt-1 ${
                      completed ? 'bg-green-500 border-green-500' : ''
                    }`}
                  />
                  <div className="flex-1">
                    <h3 className={`text-xl font-semibold text-[#8B4769] mb-2 ${
                      completed ? 'line-through text-[#8B4769]/70' : ''
                    }`}>
                      {goal.title}
                    </h3>
                    <div className="flex items-center gap-2 text-sm text-[#8B4769]/70">
                      <Clock className="w-4 h-4" />
                      <span>Created: {format(new Date(goal.created_at), 'MMM d, yyyy')}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {completed && (
                      <div className="bg-green-100 px-3 py-1 rounded-full text-green-600 text-sm font-medium flex items-center gap-1">
                        <Check className="w-4 h-4" />
                        Completed
                      </div>
                    )}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <svg width="15" height="3" viewBox="0 0 15 3" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="1.5" cy="1.5" r="1.5" fill="#8B4769"/>
                            <circle cx="7.5" cy="1.5" r="1.5" fill="#8B4769"/>
                            <circle cx="13.5" cy="1.5" r="1.5" fill="#8B4769"/>
                          </svg>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => {
                          setSelectedGoal(goal);
                          setIsEditing(false);
                          if (editor) {
                            editor.setEditable(false);
                            editor.commands.setContent(goal.content);
                          }
                        }}>
                          <Eye className="w-4 h-4 mr-2" />
                          View
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => {
                          setSelectedGoal(goal);
                          setIsEditing(true);
                          if (editor) {
                            editor.setEditable(true);
                            editor.commands.setContent(goal.content);
                          }
                        }}>
                          <Pencil className="w-4 h-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleDelete(goal.id)}
                          className="text-red-600"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </motion.div>
            );
          })}

          <Button
            onClick={handleNewGoal}
            disabled={!user?.id}
            className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-[#8B4769] hover:bg-[#96536F] shadow-lg"
          >
            <Plus className="w-6 h-6" />
          </Button>
        </div>
      ) : (
        <div className="h-[calc(100vh-200px)] flex flex-col bg-white/90 rounded-xl shadow-lg">
          <div className="bg-gradient-to-b from-[#8B4769]/20 to-transparent p-4 backdrop-blur-sm rounded-t-xl">
            <div className="flex justify-between items-center">
              <Button
                variant="ghost"
                onClick={() => {
                  setSelectedGoal(null);
                  setIsEditing(false);
                }}
                className="text-[#8B4769]"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back
              </Button>
              {isEditing ? (
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Button
                      variant="ghost"
                      onClick={() => setShowHighlightPicker(!showHighlightPicker)}
                      className={`text-[#8B4769] h-8 w-8 ${editor?.isActive('highlight') ? 'bg-[#8B4769]/10' : ''}`}
                      title="Highlight text"
                    >
                      <Highlighter className="w-3 h-3" />
                    </Button>
                    {showHighlightPicker && (
                      <div className="absolute top-full right-0 mt-2 p-3 bg-white rounded-lg shadow-lg z-50 border border-gray-200 min-w-[200px]">
                        <div className="text-xs text-gray-600 mb-2 font-medium">Highlight Colors</div>
                        <div className="flex flex-wrap gap-2">
                          {/* Remove highlight button */}
                          <button
                            onClick={() => handleHighlightClick(null)}
                            className="w-6 h-6 rounded border-2 border-gray-300 hover:scale-110 transition-transform flex items-center justify-center bg-white hover:bg-gray-50"
                            title="Remove highlight"
                          >
                            <X className="w-3 h-3 text-gray-500" />
                          </button>
                          {/* Color options */}
                          {HIGHLIGHT_COLORS.map(({ color, name }) => (
                            <button
                              key={color}
                              onClick={() => handleHighlightClick(color)}
                              className="w-6 h-6 rounded border-2 border-gray-200 hover:scale-110 transition-transform hover:border-gray-400"
                              style={{ backgroundColor: color }}
                              title={`Highlight with ${name}`}
                            />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    onClick={handleSave}
                    className="text-[#8B4769] ml-4"
                  >
                    <Save className="w-5 h-5 mr-2" />
                    Save
                  </Button>
                </div>
              ) : (
                <Button
                  variant="ghost"
                  onClick={() => {
                    setIsEditing(true);
                    if (editor) {
                      editor.setEditable(true);
                    }
                  }}
                  className="text-[#8B4769]"
                >
                  <Pencil className="w-5 h-5 mr-2" />
                  Edit
                </Button>
              )}
            </div>
          </div>

          <div className="flex-1 overflow-auto p-8">
            <div className="max-w-4xl mx-auto">
              <EditorContent editor={editor} />
            </div>
          </div>
        </div>
      )}

      {/* Upgrade Dialog */}
      <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
        <DialogContent className="w-[95vw] max-w-[400px] bg-white rounded-3xl p-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-[#8B4769] mb-3">Upgrade Required</h3>
            <p className="text-[#8B4769]/80 mb-6">
              You've reached your goals limit of {goalsLimit} goals. Upgrade to Velory Plus for 10 goals or Pro for unlimited.
            </p>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowUpgradeDialog(false)}
                className="flex-1 border-[#8B4769] text-[#8B4769]"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  setShowUpgradeDialog(false);
                  navigate('/subscription');
                }}
                className="flex-1 bg-[#8B4769] text-white hover:bg-[#96536F]"
              >
                <Crown className="w-4 h-4 mr-2" />
                Upgrade
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};