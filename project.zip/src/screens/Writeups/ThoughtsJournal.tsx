import React, { useState, useEffect } from 'react';
import { Plus, MoreVertical, Eye, ArrowLeft, Pencil, Trash2, Crown, Lock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { motion } from "framer-motion";
import { writeupsApi, type Writeup } from '../../lib/api';
import { useAuthContext } from '../../components/AuthProvider';
import { useSubscription } from '../../hooks/useSubscription';
import { UsageLimit } from '../../components/SubscriptionGate';

interface ThoughtEntry {
  situation: string;
  negative: string;
  positive: string;
}

export const ThoughtsJournal = () => {
  const navigate = useNavigate();
  const { user } = useAuthContext();
  const { checkLimit, incrementUsage, getLimit, isUnlimited } = useSubscription();
  const [entries, setEntries] = useState<Writeup[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [newEntry, setNewEntry] = useState<ThoughtEntry>({ situation: '', negative: '', positive: '' });
  const [showOptionsIndex, setShowOptionsIndex] = useState<string | null>(null);
  const [expandedIndex, setExpandedIndex] = useState<string | null>(null);
  const [editingEntry, setEditingEntry] = useState<Writeup | null>(null);
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [wordCounts, setWordCounts] = useState({ negative: 0, positive: 0 });

  useEffect(() => {
    if (user) {
      loadEntries();
    }
  }, [user]);

  const loadEntries = async () => {
    try {
      setLoading(true);
      const data = await writeupsApi.getWriteups('thoughts');
      setEntries(data);
    } catch (error) {
      console.error('Error loading thoughts:', error);
    } finally {
      setLoading(false);
    }
  };

  const canCreateThought = async () => {
    const canCreate = await checkLimit('thoughts_entries');
    if (!canCreate) {
      setShowUpgradeDialog(true);
      return false;
    }
    return true;
  };

  const countWords = (text: string): number => {
    return text.trim().split(/\s+/).filter(word => word.length > 0).length;
  };

  const getTotalWordCount = (): number => {
    return wordCounts.negative + wordCounts.positive;
  };

  const thoughtsWordLimit = getLimit('thoughts_total_words');
  const isAtWordLimit = thoughtsWordLimit > 0 && getTotalWordCount() >= thoughtsWordLimit;

  const handleInputChange = (field: keyof ThoughtEntry, value: string) => {
    // Check word limit for negative and positive fields
    if (field === 'negative' || field === 'positive') {
      const wordCount = countWords(value);
      const otherField = field === 'negative' ? 'positive' : 'negative';
      const otherWordCount = wordCounts[otherField];
      
      // If word limit is set and would be exceeded, don't allow the change
      if (thoughtsWordLimit > 0 && (wordCount + otherWordCount) > thoughtsWordLimit) {
        return;
      }
      
      setWordCounts(prev => ({ ...prev, [field]: wordCount }));
    }
    
    setNewEntry({ ...newEntry, [field]: value });
  };

  const handleSave = async () => {
    if (!newEntry.situation.trim() || !user?.id) return;

    // Check limits for new entries
    if (!editingEntry) {
      const canCreate = await canCreateThought();
      if (!canCreate) return;
    }

    try {
      const thoughtData = {
        type: 'thoughts' as const,
        title: newEntry.situation,
        content: JSON.stringify({
          situation: newEntry.situation,
          negative: newEntry.negative,
          positive: newEntry.positive
        }),
        tags: [],
        metadata: {},
        user_id: user.id
      };

      if (editingEntry) {
        await writeupsApi.updateWriteup(editingEntry.id, thoughtData);
      } else {
        await writeupsApi.createWriteup(thoughtData);
        // Increment usage for new thoughts
        await incrementUsage('thoughts_entries');
      }

      await loadEntries(); // Refresh the list
      setNewEntry({ situation: '', negative: '', positive: '' });
      setWordCounts({ negative: 0, positive: 0 });
      setShowForm(false);
      setEditingEntry(null);
    } catch (error) {
      console.error('Error saving thought:', error);
    }
  };

  const handleEdit = (entry: Writeup) => {
    const thoughtData = parseThoughtContent(entry.content);
    setNewEntry(thoughtData);
    setWordCounts({
      negative: countWords(thoughtData.negative),
      positive: countWords(thoughtData.positive)
    });
    setEditingEntry(entry);
    setShowForm(true);
    setShowOptionsIndex(null);
  };

  const handleDelete = async (id: string) => {
    try {
      await writeupsApi.deleteWriteup(id);
      await loadEntries(); // Refresh the list
      setShowOptionsIndex(null);
    } catch (error) {
      console.error('Error deleting thought:', error);
    }
  };

  const handleCancel = () => {
    setNewEntry({ situation: '', negative: '', positive: '' });
    setWordCounts({ negative: 0, positive: 0 });
    setShowForm(false);
    setEditingEntry(null);
  };

  const handleNewThought = async () => {
    const canCreate = await canCreateThought();
    if (canCreate) {
      setEditingEntry(null);
      setNewEntry({ situation: '', negative: '', positive: '' });
      setWordCounts({ negative: 0, positive: 0 });
      setShowForm(true);
    }
  };

  const parseThoughtContent = (content: string): ThoughtEntry => {
    try {
      return JSON.parse(content);
    } catch {
      return { situation: content, negative: '', positive: '' };
    }
  };

  const toggleCard = (cardId: string) => {
    setExpandedIndex(expandedIndex === cardId ? null : cardId);
  };

  const thoughtsLimit = getLimit('thoughts_entries');
  const currentCount = entries.length;

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FEE2E2] flex items-center justify-center">
        <div className="text-[#8B4769] text-xl font-semibold">Loading thoughts...</div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-cover bg-center p-4 font-['Quicksand']"
      style={{
        backgroundImage:
          "url('https://res.cloudinary.com/db6un9uvp/image/upload/v1745916296/Autobiography_bg_fyshzv.png')",
        backgroundBlendMode: 'multiply',
        backgroundColor: 'rgba(0, 0, 0, 0.2)'
      }}
    >
      <div className="flex items-center justify-between mb-8">
        <Button 
          variant="ghost" 
          onClick={() => navigate(-1)}
          className="text-white -ml-3"
        >
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <Button 
          variant="ghost" 
          onClick={() => navigate("/subscription", { state: { fromNavigation: true } })}
          className="text-white"
        >
          <Crown className="w-6 h-6" />
        </Button>
      </div>

      <motion.div 
        className="text-center mb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-4xl font-extrabold text-white mb-2 tracking-wide font-['Indie Flower']">
          Thoughts Journal
        </h1>
        <div className="flex items-center justify-center gap-3">
          <div className="h-0.5 w-12 bg-gradient-to-r from-transparent via-pink-400 to-transparent" />
          <span className="text-pink-300">✨</span>
          <div className="h-0.5 w-12 bg-gradient-to-r from-transparent via-pink-400 to-transparent" />
        </div>
      </motion.div>

      <div className="max-w-2xl mx-auto">
        {/* Usage Limit Display */}
        {!isUnlimited('thoughts_entries') && (
          <div className="mb-6">
            <UsageLimit
              resourceType="Thoughts Entries"
              current={currentCount}
              limit={thoughtsLimit}
              unit="entries"
            />
          </div>
        )}

        {entries.map((entry, index) => {
          const thoughtData = parseThoughtContent(entry.content);
          return (
            <div
              key={entry.id}
              className="bg-white/80 shadow-lg rounded-2xl p-5 mb-6 space-y-4 relative border-2 border-[#8B4769]/20"
            >
              <div className="flex justify-between items-center">
                <h2 className="font-bold text-lg text-[#8B4769]">{thoughtData.situation}</h2>
                <div className="flex gap-2 items-center">
                  <button onClick={() => toggleCard(entry.id)}>
                    <Eye className="w-5 h-5 text-[#8B4769] hover:text-[#96536F]" />
                  </button>
                  <button onClick={() => setShowOptionsIndex(showOptionsIndex === entry.id ? null : entry.id)}>
                    <MoreVertical className="w-5 h-5 text-[#8B4769]" />
                  </button>
                  {showOptionsIndex === entry.id && (
                    <div className="absolute right-4 mt-8 w-32 bg-white border-2 border-[#8B4769]/20 rounded shadow-md z-10">
                      <button
                        onClick={() => handleEdit(entry)}
                        className="flex items-center w-full px-4 py-2 text-left text-sm text-[#8B4769] hover:bg-[#8B4769]/5"
                      >
                        <Pencil className="w-4 h-4 mr-2" />
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(entry.id)}
                        className="flex items-center w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-[#8B4769]/5"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {expandedIndex === entry.id && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-red-50 p-4 rounded-xl border-2 border-red-300">
                    <div className="font-semibold mb-1 text-red-600">😟 Negative Thought</div>
                    <p className="text-[#8B4769]">{thoughtData.negative}</p>
                  </div>
                  <div className="bg-green-50 p-4 rounded-xl border-2 border-green-300">
                    <div className="font-semibold mb-1 text-green-600">😊 Positive Thought</div>
                    <p className="text-[#8B4769]">{thoughtData.positive}</p>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {showForm && (
          <div className="bg-white/80 shadow-lg rounded-2xl p-6 mb-8 space-y-5 border-2 border-[#8B4769]/20">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-semibold text-[#8B4769]">
                {editingEntry ? 'Edit Thought' : 'Add New Thought'}
              </h3>
              {thoughtsWordLimit > 0 && (
                <div className="text-sm text-[#8B4769]/70">
                  <span className={isAtWordLimit ? 'text-red-600 font-medium' : ''}>
                    {getTotalWordCount()}/{thoughtsWordLimit} words
                  </span>
                </div>
              )}
            </div>

            <div>
              <label className="block font-semibold mb-1 text-[#8B4769]">Situation / Event:</label>
              <input
                type="text"
                value={newEntry.situation}
                onChange={(e) => handleInputChange('situation', e.target.value)}
                className="w-full border-2 border-[#8B4769]/20 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
                placeholder="Describe the situation..."
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="border-2 border-red-300 rounded-xl p-4 bg-red-50">
                <div className="font-semibold mb-2 text-red-600 flex items-center justify-between">
                  <span>😟 Negative thought</span>
                  {thoughtsWordLimit > 0 && (
                    <span className="text-xs text-red-500">
                      {wordCounts.negative} words
                    </span>
                  )}
                </div>
                <textarea
                  rows={4}
                  value={newEntry.negative}
                  onChange={(e) => handleInputChange('negative', e.target.value)}
                  className={`w-full resize-none border-2 border-[#8B4769]/20 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50 ${
                    isAtWordLimit ? 'border-red-300' : ''
                  }`}
                  placeholder="What was the negative thought?"
                ></textarea>
              </div>

              <div className="border-2 border-green-300 rounded-xl p-4 bg-green-50">
                <div className="font-semibold mb-2 text-green-600 flex items-center justify-between">
                  <span>😊 Positive thought</span>
                  {thoughtsWordLimit > 0 && (
                    <span className="text-xs text-green-500">
                      {wordCounts.positive} words
                    </span>
                  )}
                </div>
                <textarea
                  rows={4}
                  value={newEntry.positive}
                  onChange={(e) => handleInputChange('positive', e.target.value)}
                  className={`w-full resize-none border-2 border-[#8B4769]/20 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50 ${
                    isAtWordLimit ? 'border-red-300' : ''
                  }`}
                  placeholder="How can you reframe it positively?"
                ></textarea>
              </div>
            </div>

            {isAtWordLimit && (
              <div className="bg-red-50 border border-red-200 p-3 rounded-lg">
                <div className="text-red-600 text-sm font-medium">
                  Word limit reached ({thoughtsWordLimit} words). Please reduce your content to continue.
                </div>
              </div>
            )}

            <div className="flex justify-end gap-3">
              <Button
                onClick={handleCancel}
                variant="outline"
                className="border-[#8B4769] text-[#8B4769] px-5 py-2 rounded-lg hover:bg-[#8B4769]/5"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSave}
                disabled={!user?.id || !newEntry.situation.trim() || isAtWordLimit}
                className="bg-[#8B4769] text-white px-5 py-2 rounded-lg hover:bg-[#96536F]"
              >
                {editingEntry ? 'Update' : 'Save'}
              </Button>
            </div>
          </div>
        )}

        <Button
          onClick={handleNewThought}
          className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-[#8B4769] hover:bg-[#96536F] shadow-lg"
        >
          <Plus className="w-6 h-6" />
        </Button>

        {/* Upgrade Dialog */}
        <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
          <DialogContent className="w-[95vw] max-w-[400px] bg-white rounded-3xl p-6">
            <DialogHeader>
              <DialogTitle className="text-center text-xl font-semibold text-[#8B4769] mb-3">Upgrade Required</DialogTitle>
            </DialogHeader>
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lock className="w-8 h-8 text-white" />
              </div>
              <p className="text-[#8B4769]/80 mb-6">
                You've reached your thoughts limit of {thoughtsLimit} entries. Upgrade to Velory Plus for 20 thoughts entries or Pro for unlimited.
              </p>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setShowUpgradeDialog(false)}
                  className="flex-1 border-[#8B4769] text-[#8B4769]"
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    setShowUpgradeDialog(false);
                    navigate('/subscription');
                  }}
                  className="flex-1 bg-[#8B4769] text-white hover:bg-[#96536F]"
                >
                  <Crown className="w-4 h-4 mr-2" />
                  Upgrade
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};