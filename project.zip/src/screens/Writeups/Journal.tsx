import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../../components/ui/dropdown-menu";
import { motion } from "framer-motion";
import { ArrowLeft, Plus, Eye, Save, Pencil, MoreVertical, Trash2, AlertCircle, X, Crown, Lock } from 'lucide-react';
import { format } from 'date-fns';
import { writeupsApi, type Writeup } from '../../lib/api';
import { useAuthContext } from '../../components/AuthProvider';
import { useProfile } from '../../hooks/useProfile';
import { useSubscription } from '../../hooks/useSubscription';
import { UsageLimit } from '../../components/SubscriptionGate';
import { SimpleEditor } from '../../components/SimpleEditor';

export const Journal = () => {
  const navigate = useNavigate();
  const { user } = useAuthContext();
  const { profile, updateProfile } = useProfile();
  const { checkLimit, incrementUsage, getLimit, isUnlimited } = useSubscription();
  const [entries, setEntries] = useState<Writeup[]>([]);
  const [selectedEntry, setSelectedEntry] = useState<Writeup | null>(null);
  const [isReadMode, setIsReadMode] = useState(false);
  const [showNewDialog, setShowNewDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDiaryNameDialog, setShowDiaryNameDialog] = useState(false);
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [newTitle, setNewTitle] = useState('Diary');
  const [diaryName, setDiaryName] = useState('');
  const [selectedMood, setSelectedMood] = useState<'good' | 'bad'>('good');
  const [loading, setLoading] = useState(true);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [wordLimitExceeded, setWordLimitExceeded] = useState(false);

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  useEffect(() => {
    if (profile) {
      setDiaryName(profile.diary_name || 'My Diary');
      if (!profile.diary_name) {
        setShowDiaryNameDialog(true);
      }
    }
  }, [profile]);

  const loadData = async () => {
    try {
      setLoading(true);
      const journalEntries = await writeupsApi.getWriteups('journal');
      setEntries(journalEntries);
    } catch (error) {
      console.error('Error loading journal data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleContentChange = (content: string) => {
    if (selectedEntry) {
      const updatedEntry = {
        ...selectedEntry,
        content,
      };
      setSelectedEntry(updatedEntry);
      // Auto-save after a delay
      setTimeout(() => saveEntry(updatedEntry), 1000);
    }
  };

  const saveEntry = async (entry: Writeup) => {
    try {
      setSaveError(null); // Clear any previous errors
      await writeupsApi.updateWriteup(entry.id, {
        content: entry.content,
      });
      
      // Update the entries list to reflect the changes
      setEntries(prevEntries => 
        prevEntries.map(e => e.id === entry.id ? { ...e, content: entry.content } : e)
      );
    } catch (error) {
      console.error('Error saving entry:', error);
      setSaveError('Unable to save changes. Please check your internet connection and try again.');
    }
  };

  const canCreateJournal = async () => {
    const canCreate = await checkLimit('journal_entries');
    if (!canCreate) {
      setShowUpgradeDialog(true);
      return false;
    }
    return true;
  };

  const handleNewEntry = async () => {
    if (!newTitle.trim() || !user?.id) return;

    const today = format(new Date(), 'yyyy-MM-dd');
    const existingEntry = entries.find(e => 
      format(new Date(e.created_at), 'yyyy-MM-dd') === today
    );

    if (existingEntry) {
      alert('You already have a journal entry for today!');
      return;
    }

    // Check limits before creating
    const canCreate = await canCreateJournal();
    if (!canCreate) return;

    try {
      const entry = await writeupsApi.createWriteup({
        type: 'journal',
        title: newTitle.trim(),
        content: `Dear ${diaryName},\n\n`,
        mood: selectedMood,
        tags: [],
        metadata: {},
        user_id: user.id
      });

      // Increment usage for new journal entries
      await incrementUsage('journal_entries');

      setEntries(prev => [entry, ...prev]);
      setSelectedEntry(entry);
      setShowNewDialog(false);
      setNewTitle('Diary');
      setIsReadMode(false);
    } catch (error) {
      console.error('Error creating journal entry:', error);
    }
  };

  const handleSaveDiaryName = async () => {
    if (!diaryName.trim()) return;
    
    try {
      await updateProfile({ diary_name: diaryName });
      setShowDiaryNameDialog(false);
    } catch (error) {
      console.error('Error saving diary name:', error);
    }
  };

  const handleEditEntry = async () => {
    if (!selectedEntry) return;
    
    try {
      const updatedEntry = await writeupsApi.updateWriteup(selectedEntry.id, {
        title: newTitle,
        mood: selectedMood,
      });
      
      setEntries(prev =>
        prev.map(e => e.id === selectedEntry.id ? updatedEntry : e)
      );
      setSelectedEntry(updatedEntry);
      setShowEditDialog(false);
    } catch (error) {
      console.error('Error updating entry:', error);
    }
  };

  const handleDeleteEntry = async (entryId: string) => {
    try {
      await writeupsApi.deleteWriteup(entryId);
      setEntries(prev => prev.filter(e => e.id !== entryId));
      if (selectedEntry?.id === entryId) {
        setSelectedEntry(null);
        setIsReadMode(false);
      }
    } catch (error) {
      console.error('Error deleting entry:', error);
    }
  };

  const handleSave = () => {
    if (selectedEntry) {
      saveEntry(selectedEntry);
    }
  };

  const journalLimit = getLimit('journal_entries');
  const journalWordLimit = getLimit('journal_words_per_entry');
  const currentCount = entries.length;

  // Fixed navigation - replace current history entry to prevent back button loop
  const handleBackNavigation = () => {
    navigate('/writeups', { 
      state: { tab: 'journey' },
      replace: true // This replaces the current history entry instead of adding a new one
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FEE2E2] flex items-center justify-center">
        <div className="text-[#8B4769] text-xl font-semibold">Loading journal...</div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-cover bg-center font-['Quicksand']"
      style={{
        backgroundImage: selectedEntry 
          ? "url('https://res.cloudinary.com/db6un9uvp/image/upload/v1746428008/Daily_journal_bg_gieu1b.png')"
          : "url('https://res.cloudinary.com/db6un9uvp/image/upload/v1745916294/Journal_bg_ac51wb.png')",
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      {!selectedEntry ? (
        <div className="p-4">
          <div className="flex items-center justify-between mb-8">
            <Button 
              variant="ghost" 
              onClick={handleBackNavigation}
              className="text-[#8B4769] -ml-3"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <motion.div 
              className="text-center"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl font-extrabold text-[#8B4769] mb-2 tracking-wide font-['Indie Flower']">
                {diaryName}
              </h1>
              <div className="flex items-center justify-center gap-3">
                <div className="h-0.5 w-12 bg-gradient-to-r from-transparent via-pink-400 to-transparent" />
                <span className="text-pink-300">✨</span>
                <div className="h-0.5 w-12 bg-gradient-to-r from-transparent via-pink-400 to-transparent" />
              </div>
            </motion.div>
            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                onClick={() => navigate("/subscription", { state: { fromNavigation: true } })}
                className="text-[#8B4769]"
              >
                <Crown className="w-6 h-6" />
              </Button>
              <Button
                variant="ghost"
                onClick={() => setShowDiaryNameDialog(true)}
                className="text-[#8B4769]"
              >
                <Pencil className="w-5 h-5" />
              </Button>
            </div>
          </div>

          <div className="max-w-2xl mx-auto">
            {/* Usage Limit Display */}
            {!isUnlimited('journal_entries') && (
              <div className="mb-6">
                <UsageLimit
                  resourceType="Journal Entries"
                  current={currentCount}
                  limit={journalLimit}
                  unit="entries"
                />
              </div>
            )}

            <div className="grid gap-4">
              {entries.map((entry) => (
                <motion.div
                  key={entry.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`${
                    entry.mood === 'good' ? 'bg-green-50/80' : 'bg-red-50/80'
                  } rounded-xl p-6 cursor-pointer hover:bg-opacity-90 transition-all duration-300 hover:shadow-lg border-2 ${
                    entry.mood === 'good' ? 'border-green-200' : 'border-red-200'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1" onClick={() => setSelectedEntry(entry)}>
                      <h3 className="text-xl font-semibold text-[#8B4769] mb-3">{entry.title}</h3>
                      <div className="flex items-center gap-2 text-sm text-[#8B4769]/70">
                        <span>{format(new Date(entry.created_at), 'MMM d, yyyy')}</span>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem onClick={() => {
                          setNewTitle(entry.title);
                          setSelectedMood(entry.mood || 'good');
                          setSelectedEntry(entry);
                          setShowEditDialog(true);
                        }}>
                          <Pencil className="w-4 h-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleDeleteEntry(entry.id)}
                          className="text-red-600"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          <Button
            onClick={async () => {
              const canCreate = await canCreateJournal();
              if (canCreate) {
                setShowNewDialog(true);
              }
            }}
            className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-[#8B4769] hover:bg-[#96536F] shadow-lg"
          >
            <Plus className="w-6 h-6" />
          </Button>
        </div>
      ) : (
        <div className="h-screen flex flex-col">
          <div className="bg-white/80 p-4">
            <div className="flex items-center justify-between max-w-4xl mx-auto">
              <Button
                variant="ghost"
                onClick={() => {
                  setSelectedEntry(null);
                  setIsReadMode(false);
                  setSaveError(null); // Clear error when leaving entry
                }}
                className="text-[#8B4769]"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back to Journal
              </Button>
              <h2 className="text-xl font-semibold text-[#8B4769]">{selectedEntry.title}</h2>
              <div className="flex items-center gap-2">
                {!isReadMode && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleSave}
                    className="text-[#8B4769] h-8"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Save
                  </Button>
                )}
                <Button
                  variant="ghost"
                  onClick={() => setIsReadMode(!isReadMode)}
                  className="text-[#8B4769]"
                >
                  {isReadMode ? <Pencil className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </Button>
              </div>
            </div>
          </div>

          {/* Error message display */}
          {saveError && (
            <div className="bg-red-50/90 border border-red-200 p-3 mx-4 rounded-lg">
              <div className="flex items-center gap-2 text-red-700">
                <AlertCircle className="w-4 h-4" />
                <span className="text-sm">{saveError}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSaveError(null)}
                  className="ml-auto text-red-700 hover:text-red-800"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}

          {/* Word limit exceeded warning */}
          {wordLimitExceeded && !isReadMode && (
            <div className="bg-orange-50/90 border border-orange-200 p-3 mx-4 rounded-lg">
              <div className="flex items-center gap-2 text-orange-700">
                <AlertCircle className="w-4 h-4" />
                <span className="text-sm">Word limit exceeded. Please reduce your content to continue.</span>
              </div>
            </div>
          )}

          <div className="flex-1 overflow-auto">
            <div className="max-w-4xl mx-auto">
              <SimpleEditor
                content={selectedEntry.content}
                onChange={handleContentChange}
                placeholder="Write your thoughts..."
                readOnly={isReadMode}
                className="h-full"
                wordLimit={journalWordLimit > 0 ? journalWordLimit : undefined}
                onWordLimitExceeded={setWordLimitExceeded}
              />
            </div>
          </div>
        </div>
      )}

      {/* Upgrade Dialog */}
      <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
        <DialogContent className="w-[95vw] max-w-[400px] bg-white rounded-3xl p-6">
          <DialogHeader>
            <DialogTitle className="text-center text-xl font-semibold text-[#8B4769] mb-3">Upgrade Required</DialogTitle>
          </DialogHeader>
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <p className="text-[#8B4769]/80 mb-6">
              You've reached your journal limit of {journalLimit} entries. Upgrade to Velory Plus for 25 entries or Pro for unlimited.
            </p>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowUpgradeDialog(false)}
                className="flex-1 border-[#8B4769] text-[#8B4769]"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  setShowUpgradeDialog(false);
                  navigate('/subscription');
                }}
                className="flex-1 bg-[#8B4769] text-white hover:bg-[#96536F]"
              >
                <Crown className="w-4 h-4 mr-2" />
                Upgrade
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showNewDialog} onOpenChange={setShowNewDialog}>
        <DialogContent className="sm:max-w-[500px] bg-[#FEE2E2]/95">
          <DialogHeader>
            <DialogTitle className="text-[#8B4769]">New Journal Entry</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <input
              type="text"
              placeholder="Journal Name"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
            />

            <div>
              <label className="block text-sm font-medium mb-2 text-[#8B4769]">Mood</label>
              <div className="flex gap-4">
                <button
                  onClick={() => setSelectedMood('good')}
                  className={`flex-1 p-3 rounded-xl border-2 ${
                    selectedMood === 'good'
                      ? 'bg-green-100 border-green-300'
                      : 'bg-white/50 border-[#8B4769]/20'
                  }`}
                >
                  Good
                </button>
                <button
                  onClick={() => setSelectedMood('bad')}
                  className={`flex-1 p-3 rounded-xl border-2 ${
                    selectedMood === 'bad'
                      ? 'bg-red-100 border-red-300'
                      : 'bg-white/50 border-[#8B4769]/20'
                  }`}
                >
                  Bad
                </button>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowNewDialog(false);
                setNewTitle('Diary');
              }}
              className="border-[#8B4769] text-[#8B4769]"
            >
              Cancel
            </Button>
            <Button
              onClick={handleNewEntry}
              disabled={!newTitle.trim() || !user?.id}
              className="bg-[#8B4769] text-white hover:bg-[#96536F]"
            >
              Create
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showDiaryNameDialog} onOpenChange={setShowDiaryNameDialog}>
        <DialogContent className="sm:max-w-[500px] bg-[#FEE2E2]/95">
          <DialogHeader>
            <DialogTitle className="text-[#8B4769]">Name Your Diary</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <input
              type="text"
              placeholder="Enter diary name"
              value={diaryName}
              onChange={(e) => setDiaryName(e.target.value)}
              className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
            />
          </div>

          <DialogFooter>
            <Button
              onClick={handleSaveDiaryName}
              disabled={!diaryName.trim()}
              className="bg-[#8B4769] text-white hover:bg-[#96536F]"
            >
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="sm:max-w-[500px] bg-[#FEE2E2]/95">
          <DialogHeader>
            <DialogTitle className="text-[#8B4769]">Edit Entry</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <input
              type="text"
              placeholder="Entry Title"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
            />

            <div>
              <label className="block text-sm font-medium mb-2 text-[#8B4769]">Mood</label>
              <div className="flex gap-4">
                <button
                  onClick={() => setSelectedMood('good')}
                  className={`flex-1 p-3 rounded-xl border-2 ${
                    selectedMood === 'good'
                      ? 'bg-green-100 border-green-300'
                      : 'bg-white/50 border-[#8B4769]/20'
                  }`}
                >
                  Good
                </button>
                <button
                  onClick={() => setSelectedMood('bad')}
                  className={`flex-1 p-3 rounded-xl border-2 ${
                    selectedMood === 'bad'
                      ? 'bg-red-100 border-red-300'
                      : 'bg-white/50 border-[#8B4769]/20'
                  }`}
                >
                  Bad
                </button>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowEditDialog(false)}
              className="border-[#8B4769] text-[#8B4769]"
            >
              Cancel
            </Button>
            <Button
              onClick={handleEditEntry}
              disabled={!newTitle.trim()}
              className="bg-[#8B4769] text-white hover:bg-[#96536F]"
            >
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};