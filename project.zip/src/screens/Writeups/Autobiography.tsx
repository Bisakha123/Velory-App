import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { motion } from "framer-motion";
import { ArrowLeft, Plus, Pencil, Eye, X, Trash2, RefreshCw, AlertCircle, Crown, Lock } from 'lucide-react';
import { writeupsApi, type Writeup } from '../../lib/api';
import { useAuthContext } from '../../components/AuthProvider';
import { useProfile } from '../../hooks/useProfile';
import { useSubscription } from '../../hooks/useSubscription';
import { SubscriptionGate, UsageLimit } from '../../components/SubscriptionGate';

interface UserInfo {
  name: string;
  age: string;
  gender: string;
  occupation: string;
  hometown: string;
}

interface Card {
  id: string;
  title: string;
  items: string[];
}

export const Autobiography = () => {
  const navigate = useNavigate();
  const { user } = useAuthContext();
  const { profile } = useProfile();
  const { canUseFeature, checkLimit, incrementUsage, getLimit, isUnlimited, isFree } = useSubscription();
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showAddCardDialog, setShowAddCardDialog] = useState(false);
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [userInfo, setUserInfo] = useState<UserInfo>({
    name: '',
    age: '',
    gender: '',
    occupation: '',
    hometown: '',
  });
  const [cards, setCards] = useState<Writeup[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [newCard, setNewCard] = useState({ title: '', items: [''] });
  const [editingCard, setEditingCard] = useState<Writeup | null>(null);
  const [expandedCard, setExpandedCard] = useState<string | null>(null);
  const [userInfoEntry, setUserInfoEntry] = useState<Writeup | null>(null);

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const checkConnectivity = async (): Promise<boolean> => {
    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      if (!supabaseUrl) {
        throw new Error('Supabase URL not configured');
      }
      
      const response = await fetch(`${supabaseUrl}/rest/v1/`, {
        method: 'HEAD',
        headers: {
          'apikey': import.meta.env.VITE_SUPABASE_ANON_KEY || '',
        },
      });
      
      return response.ok || response.status === 401; // 401 is expected without proper auth
    } catch (error) {
      console.error('Connectivity check failed:', error);
      return false;
    }
  };

  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Check connectivity first
      const isConnected = await checkConnectivity();
      if (!isConnected) {
        throw new Error('Unable to connect to the server. Please check your internet connection.');
      }

      const autobiographyEntries = await writeupsApi.getWriteups('autobiography');
      
      // Separate user info entry from card entries
      const userInfoEntry = autobiographyEntries.find(entry => entry.title === '__USER_INFO__');
      const cardEntries = autobiographyEntries.filter(entry => entry.title !== '__USER_INFO__');
      
      setCards(cardEntries);
      setUserInfoEntry(userInfoEntry || null);
      
      // Load user info from the special entry or use defaults
      if (userInfoEntry) {
        try {
          const savedUserInfo = JSON.parse(userInfoEntry.content);
          setUserInfo({
            name: savedUserInfo.name || profile?.username || '',
            age: savedUserInfo.age || '',
            gender: savedUserInfo.gender || '',
            occupation: savedUserInfo.occupation || '',
            hometown: savedUserInfo.hometown || '',
          });
        } catch (parseError) {
          console.error('Error parsing user info:', parseError);
          setUserInfo({
            name: profile?.username || '',
            age: '',
            gender: '',
            occupation: '',
            hometown: '',
          });
        }
      } else {
        // Set default values from profile
        setUserInfo({
          name: profile?.username || '',
          age: '',
          gender: '',
          occupation: '',
          hometown: '',
        });
      }
    } catch (error) {
      console.error('Error loading autobiography data:', error);
      
      let errorMessage = 'Failed to load autobiography data. ';
      
      if (error instanceof TypeError && error.message.includes('fetch')) {
        errorMessage += 'Please check your internet connection and try again.';
      } else if (error instanceof Error) {
        errorMessage += error.message;
      } else {
        errorMessage += 'An unexpected error occurred.';
      }
      
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleRetry = () => {
    if (user) {
      loadData();
    }
  };

  const canCreateCard = async () => {
    const canCreate = await checkLimit('autobiography_cards');
    if (!canCreate) {
      setShowUpgradeDialog(true);
      return false;
    }
    return true;
  };

  const handleSaveUserInfo = async () => {
    if (!user?.id) return;
    
    try {
      const userInfoData = {
        type: 'autobiography' as const,
        title: '__USER_INFO__', // Special title to identify user info entry
        content: JSON.stringify(userInfo),
        tags: [],
        metadata: { isUserInfo: true },
        user_id: user.id
      };

      if (userInfoEntry) {
        // Update existing user info entry
        await writeupsApi.updateWriteup(userInfoEntry.id, userInfoData);
      } else {
        // Create new user info entry
        const newUserInfoEntry = await writeupsApi.createWriteup(userInfoData);
        setUserInfoEntry(newUserInfoEntry);
      }

      setShowEditDialog(false);
    } catch (error) {
      console.error('Error saving user info:', error);
    }
  };

  const handleSaveCard = async () => {
    if (!newCard.title.trim() || !newCard.items.some(item => item.trim()) || !user?.id) return;

    // Check limits for new cards
    if (!editingCard) {
      const canCreate = await canCreateCard();
      if (!canCreate) return;
    }

    try {
      const cardData = {
        type: 'autobiography' as const,
        title: newCard.title,
        content: JSON.stringify({
          title: newCard.title,
          items: newCard.items.filter(item => item.trim() !== '')
        }),
        tags: [],
        metadata: { isUserInfo: false },
        user_id: user.id
      };

      if (editingCard) {
        await writeupsApi.updateWriteup(editingCard.id, cardData);
      } else {
        await writeupsApi.createWriteup(cardData);
        // Increment usage for new autobiography cards
        await incrementUsage('autobiography_cards');
      }

      await loadData(); // Refresh the list
      setShowAddCardDialog(false);
      setNewCard({ title: '', items: [''] });
      setEditingCard(null);
    } catch (error) {
      console.error('Error saving card:', error);
    }
  };

  const handleDeleteCard = async (cardId: string) => {
    try {
      await writeupsApi.deleteWriteup(cardId);
      await loadData(); // Refresh the list
      if (expandedCard === cardId) {
        setExpandedCard(null);
      }
    } catch (error) {
      console.error('Error deleting card:', error);
    }
  };

  const parseCardContent = (content: string): Card => {
    try {
      return JSON.parse(content);
    } catch {
      return { id: '', title: 'Untitled', items: [content] };
    }
  };

  const handleAddItem = () => {
    setNewCard(prev => ({
      ...prev,
      items: [...prev.items, '']
    }));
  };

  const handleItemChange = (index: number, value: string) => {
    setNewCard(prev => ({
      ...prev,
      items: prev.items.map((item, i) => i === index ? value : item)
    }));
  };

  const handleRemoveItem = (index: number) => {
    setNewCard(prev => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== index)
    }));
  };

  const toggleCard = (cardId: string) => {
    setExpandedCard(expandedCard === cardId ? null : cardId);
  };

  const handleNewCard = async () => {
    const canCreate = await canCreateCard();
    if (canCreate) {
      setEditingCard(null);
      setNewCard({ title: '', items: [''] });
      setShowAddCardDialog(true);
    }
  };

  const autobiographyLimit = getLimit('autobiography_cards');
  const currentCount = cards.length;

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FEE2E2] flex items-center justify-center">
        <div className="text-[#8B4769] text-xl font-semibold">Loading autobiography...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-[#FEE2E2] flex items-center justify-center p-4">
        <div className="bg-white/90 rounded-3xl p-8 max-w-md w-full text-center border-2 border-[#8B4769]/20">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-[#8B4769] mb-4">Connection Error</h2>
          <p className="text-[#8B4769] mb-6">{error}</p>
          <div className="flex gap-3 justify-center">
            <Button
              onClick={() => navigate(-1)}
              variant="outline"
              className="border-[#8B4769] text-[#8B4769]"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Go Back
            </Button>
            <Button
              onClick={handleRetry}
              className="bg-[#8B4769] text-white hover:bg-[#96536F]"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Retry
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Show subscription gate for free users
  if (isFree()) {
    return (
      <div
        className="min-h-screen bg-cover bg-center p-4 font-['Quicksand']"
        style={{
          backgroundImage: "url('https://res.cloudinary.com/db6un9uvp/image/upload/v1746853682/Autobiography_screen_bg_sjb9g5.png')",
          backgroundBlendMode: 'multiply',
          backgroundColor: 'rgba(255, 192, 203, 0.7)'
        }}
      >
        <div className="flex items-center justify-between mb-8">
          <Button 
            variant="ghost" 
            onClick={() => navigate(-1)}
            className="text-[#8B4769] -ml-3"
          >
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <motion.div 
            className="text-center"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl font-extrabold text-[#8B4769] mb-2 tracking-wide font-['Indie Flower']">
              My Autobiography
            </h1>
          </motion.div>
          <Button 
            variant="ghost" 
            onClick={() => navigate("/subscription", { state: { fromNavigation: true } })}
            className="text-[#8B4769]"
          >
            <Crown className="w-6 h-6" />
          </Button>
        </div>

        <div className="max-w-2xl mx-auto flex items-center justify-center min-h-[60vh]">
          <SubscriptionGate
            feature="autobiography_cards"
            requiredPlan="plus"
            showUpgrade={true}
          >
            {/* This won't render for free users */}
          </SubscriptionGate>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-cover bg-center p-4 font-['Quicksand']"
      style={{
        backgroundImage: "url('https://res.cloudinary.com/db6un9uvp/image/upload/v1746853682/Autobiography_screen_bg_sjb9g5.png')",
        backgroundBlendMode: 'multiply',
        backgroundColor: 'rgba(255, 192, 203, 0.7)'
      }}
    >
      <div className="flex items-center justify-between mb-8">
        <Button 
          variant="ghost" 
          onClick={() => navigate(-1)}
          className="text-[#8B4769] -ml-3"
        >
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-4xl font-extrabold text-[#8B4769] mb-2 tracking-wide font-['Indie Flower']">
            My Autobiography
          </h1>
        </motion.div>
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            onClick={() => navigate("/subscription", { state: { fromNavigation: true } })}
            className="text-[#8B4769]"
          >
            <Crown className="w-6 h-6" />
          </Button>
          <Button
            variant="ghost"
            onClick={() => setShowEditDialog(true)}
            className="text-[#8B4769]"
          >
            <Pencil className="w-5 h-5" />
          </Button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto">
        {/* Usage Limit Display */}
        {!isUnlimited('autobiography_cards') && (
          <div className="mb-6">
            <UsageLimit
              resourceType="Autobiography Cards"
              current={currentCount}
              limit={autobiographyLimit}
              unit="cards"
            />
          </div>
        )}

        <motion.div 
          className="bg-white/80 rounded-3xl p-6 mb-8 text-center relative border-2 border-[#8B4769]/20"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="w-24 h-24 mx-auto mb-4 rounded-full border-4 border-[#8B4769]/20 overflow-hidden">
            <img
              src={profile?.avatar_url || 'https://res.cloudinary.com/db6un9uvp/image/upload/v1745916296/default_avatar_kq7bxn.png'}
              alt="Avatar"
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="space-y-2 text-[#8B4769]">
            <p className="text-xl">
              Hello, I'm {userInfo.name || '(name)'} 😊
            </p>
            <p>
              I'm {userInfo.age || '(age)'} years young ❤️
            </p>
            <p>
              I'm a {userInfo.gender || '(gender)'}, just so you know~ 😉
            </p>
            <p>
              Currently rocking life as a {userInfo.occupation || '(occupation)'} 💸
            </p>
            <p>
              And I come from the lovely town of {userInfo.hometown || '(hometown)'} 🏡✨
            </p>
          </div>
        </motion.div>

        {cards.map((card, index) => {
          const cardData = parseCardContent(card.content);
          return (
            <motion.div
              key={card.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/80 rounded-3xl p-6 mb-4 border-2 border-[#8B4769]/20"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold text-[#8B4769]">{cardData.title}</h2>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    onClick={() => toggleCard(card.id)}
                    className="text-[#8B4769]"
                  >
                    <Eye className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => {
                      setEditingCard(card);
                      setNewCard({ title: cardData.title, items: [...cardData.items] });
                      setShowAddCardDialog(true);
                    }}
                    className="text-[#8B4769]"
                  >
                    <Pencil className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => handleDeleteCard(card.id)}
                    className="text-red-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              {expandedCard === card.id && (
                <div className="space-y-2 mt-4">
                  {cardData.items.map((item, index) => (
                    <div
                      key={index}
                      className="bg-[#8B4769]/5 rounded-xl p-3 text-[#8B4769]"
                    >
                      {item}
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          );
        })}

        <Button
          onClick={handleNewCard}
          className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-[#8B4769] hover:bg-[#96536F] shadow-lg"
        >
          <Plus className="w-6 h-6" />
        </Button>
      </div>

      {/* Upgrade Dialog */}
      <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
        <DialogContent className="w-[95vw] max-w-[400px] bg-white rounded-3xl p-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-semibold text-[#8B4769] mb-3">Upgrade Required</h3>
            <p className="text-[#8B4769]/80 mb-6">
              You've reached your autobiography cards limit of {autobiographyLimit} cards. Upgrade to Velory Pro for unlimited cards.
            </p>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowUpgradeDialog(false)}
                className="flex-1 border-[#8B4769] text-[#8B4769]"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  setShowUpgradeDialog(false);
                  navigate('/subscription');
                }}
                className="flex-1 bg-[#8B4769] text-white hover:bg-[#96536F]"
              >
                <Crown className="w-4 h-4 mr-2" />
                Upgrade
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit User Info Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="sm:max-w-[500px] bg-[#FEE2E2]/95">
          <DialogHeader>
            <DialogTitle className="text-[#8B4769]">Edit Personal Info</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <input
              type="text"
              placeholder="Name"
              value={userInfo.name}
              onChange={(e) => setUserInfo({ ...userInfo, name: e.target.value })}
              className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
            />

            <input
              type="text"
              placeholder="Age"
              value={userInfo.age}
              onChange={(e) => setUserInfo({ ...userInfo, age: e.target.value })}
              className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
            />

            <input
              type="text"
              placeholder="Gender"
              value={userInfo.gender}
              onChange={(e) => setUserInfo({ ...userInfo, gender: e.target.value })}
              className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
            />

            <input
              type="text"
              placeholder="Occupation"
              value={userInfo.occupation}
              onChange={(e) => setUserInfo({ ...userInfo, occupation: e.target.value })}
              className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
            />

            <input
              type="text"
              placeholder="Hometown"
              value={userInfo.hometown}
              onChange={(e) => setUserInfo({ ...userInfo, hometown: e.target.value })}
              className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
            />
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowEditDialog(false)}
              className="border-[#8B4769] text-[#8B4769]"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSaveUserInfo}
              className="bg-[#8B4769] text-white hover:bg-[#96536F]"
            >
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add/Edit Card Dialog */}
      <Dialog open={showAddCardDialog} onOpenChange={setShowAddCardDialog}>
        <DialogContent className="sm:max-w-[500px] bg-[#FEE2E2]/95">
          <DialogHeader>
            <DialogTitle className="text-[#8B4769]">
              {editingCard ? 'Edit Card' : 'Add New Card'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <input
              type="text"
              placeholder="Card Title (e.g., Things I Love to Eat)"
              value={newCard.title}
              onChange={(e) => setNewCard({ ...newCard, title: e.target.value })}
              className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
            />

            {newCard.items.map((item, index) => (
              <div key={index} className="flex gap-2">
                <input
                  type="text"
                  placeholder={`Item ${index + 1}`}
                  value={item}
                  onChange={(e) => handleItemChange(index, e.target.value)}
                  className="flex-1 p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
                />
                {newCard.items.length > 1 && (
                  <Button
                    variant="outline"
                    onClick={() => handleRemoveItem(index)}
                    className="border-[#8B4769] text-[#8B4769]"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                )}
              </div>
            ))}

            <Button
              variant="outline"
              onClick={handleAddItem}
              className="w-full border-[#8B4769] text-[#8B4769]"
            >
              Add Item
            </Button>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowAddCardDialog(false);
                setNewCard({ title: '', items: [''] });
                setEditingCard(null);
              }}
              className="border-[#8B4769] text-[#8B4769]"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSaveCard}
              disabled={!newCard.title.trim() || !newCard.items.some(item => item.trim()) || !user?.id}
              className="bg-[#8B4769] text-white hover:bg-[#96536F]"
            >
              {editingCard ? 'Save Changes' : 'Add Card'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};