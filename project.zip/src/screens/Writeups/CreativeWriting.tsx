import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../../components/ui/dropdown-menu";
import { motion } from "framer-motion";
import { ArrowLeft, Plus, Eye, Image as ImageIcon, Clock, Save, Pencil, MoreVertical, Trash2, X, Crown, Lock } from 'lucide-react';
import { format } from 'date-fns';
import { SimpleEditor } from '../../components/SimpleEditor';
import { useSubscription } from '../../hooks/useSubscription';

interface Writing {
  id: string;
  title: string;
  content: string;
  tags: string[];
  createdAt: Date;
  updatedAt: Date;
  backgroundImage?: string;
}

const DEFAULT_BG = "https://res.cloudinary.com/db6un9uvp/image/upload/v1745916294/Journal_bg_ac51wb.png";

export const CreativeWriting = () => {
  const navigate = useNavigate();
  const { isFree, getLimit, isPlus, isPro } = useSubscription();
  const [writings, setWritings] = useState<Writing[]>([]);
  const [selectedWriting, setSelectedWriting] = useState<Writing | null>(null);
  const [isReadMode, setIsReadMode] = useState(false);
  const [showNewDialog, setShowNewDialog] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [customTag, setCustomTag] = useState('');
  const [savedTags, setSavedTags] = useState<string[]>([]);
  const [filterTag, setFilterTag] = useState<string | null>(null);
  const [bgImageUrl, setBgImageUrl] = useState<string>(DEFAULT_BG);
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const defaultTags = ['Poetry', 'Song Lyrics', 'Short Fiction', 'Letters', 'Novels', 'Journal', 'Dream Log'];

  // Memoize access check to prevent infinite re-renders
  const hasAccess = useMemo(() => {
    return isPlus() || isPro();
  }, [isPlus, isPro]);

  // Memoize creative limit to prevent unnecessary recalculations
  const creativeLimit = useMemo(() => {
    return getLimit('creative_writing');
  }, [getLimit]);

  useEffect(() => {
    // Load writings for Plus and Pro users
    if (hasAccess) {
      try {
        // Load saved writings
        const savedWritings = localStorage.getItem('creativeWritings');
        if (savedWritings) {
          const parsedWritings = JSON.parse(savedWritings).map((w: any) => ({
            ...w,
            createdAt: new Date(w.createdAt),
            updatedAt: new Date(w.updatedAt)
          }));
          setWritings(parsedWritings);
        }

        // Load saved custom tags
        const savedCustomTags = localStorage.getItem('customTags');
        if (savedCustomTags) {
          setSavedTags(JSON.parse(savedCustomTags));
        }
      } catch (error) {
        console.error('Error loading creative writing data:', error);
        // Reset to empty state on error
        setWritings([]);
        setSavedTags([]);
      }
    }
  }, [hasAccess]);

  // Update background when selectedWriting changes
  useEffect(() => {
    if (selectedWriting) {
      setBgImageUrl(selectedWriting.backgroundImage || DEFAULT_BG);
    } else {
      setBgImageUrl(DEFAULT_BG);
    }
  }, [selectedWriting]);

  const saveWritings = (newWritings: Writing[]) => {
    try {
      setWritings(newWritings);
      localStorage.setItem('creativeWritings', JSON.stringify(newWritings));
    } catch (error) {
      console.error('Error saving writings:', error);
    }
  };

  const saveCustomTags = (tags: string[]) => {
    try {
      setSavedTags(tags);
      localStorage.setItem('customTags', JSON.stringify(tags));
    } catch (error) {
      console.error('Error saving custom tags:', error);
    }
  };

  const allTags = [...defaultTags, ...savedTags];

  const handleContentChange = (content: string) => {
    if (selectedWriting) {
      const updatedWriting = {
        ...selectedWriting,
        content,
        updatedAt: new Date(),
      };
      const updatedWritings = writings.map(w => (w.id === selectedWriting.id ? updatedWriting : w));
      saveWritings(updatedWritings);
      setSelectedWriting(updatedWriting);
    }
  };

  const canCreateWriting = () => {
    return creativeLimit === -1 || writings.length < creativeLimit;
  };

  // Simplified: Plus and Pro users can change any background
  const canChangeBackground = () => {
    return hasAccess; // Both Plus and Pro users can change backgrounds
  };

  const handleNewWriting = () => {
    if (!hasAccess) {
      setShowUpgradeDialog(true);
      return;
    }

    if (!canCreateWriting()) {
      setShowUpgradeDialog(true);
      return;
    }

    if (!newTitle.trim()) return;

    const writing: Writing = {
      id: Date.now().toString(),
      title: newTitle.trim(),
      content: '',
      tags: selectedTags,
      createdAt: new Date(),
      updatedAt: new Date(),
      backgroundImage: DEFAULT_BG,
    };

    const newWritings = [writing, ...writings];
    saveWritings(newWritings);
    setSelectedWriting(writing);
    setShowNewDialog(false);
    setNewTitle('');
    setSelectedTags([]);
    setCustomTag('');
  };

  const handleDeleteWriting = (writingId: string) => {
    const updatedWritings = writings.filter(w => w.id !== writingId);
    saveWritings(updatedWritings);
    
    // If we're currently viewing the deleted writing, go back to list
    if (selectedWriting?.id === writingId) {
      setSelectedWriting(null);
      setIsReadMode(false);
      setBgImageUrl(DEFAULT_BG);
    }
  };

  const handleAddCustomTag = () => {
    if (customTag.trim() && !allTags.includes(customTag.trim())) {
      const newCustomTags = [...savedTags, customTag.trim()];
      saveCustomTags(newCustomTags);
      setSelectedTags([...selectedTags, customTag.trim()]);
      setCustomTag('');
    }
  };

  const handleBgImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file && selectedWriting) {
      if (!canChangeBackground()) {
        setShowUpgradeDialog(true);
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const imageUrl = reader.result as string;
        setBgImageUrl(imageUrl);
        if (selectedWriting) {
          const updatedWriting = {
            ...selectedWriting,
            backgroundImage: imageUrl,
            updatedAt: new Date(),
          };
          const updatedWritings = writings.map(w => (w.id === selectedWriting.id ? updatedWriting : w));
          saveWritings(updatedWritings);
          setSelectedWriting(updatedWriting);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDeleteBackground = () => {
    setBgImageUrl(DEFAULT_BG);
    if (selectedWriting) {
      const updatedWriting = {
        ...selectedWriting,
        backgroundImage: DEFAULT_BG,
        updatedAt: new Date(),
      };
      const updatedWritings = writings.map(w => (w.id === selectedWriting.id ? updatedWriting : w));
      saveWritings(updatedWritings);
      setSelectedWriting(updatedWriting);
    }
  };

  const handleSave = () => {
    if (selectedWriting) {
      const updatedWritings = writings.map(w => (w.id === selectedWriting.id ? selectedWriting : w));
      saveWritings(updatedWritings);
    }
  };

  const filteredWritings = filterTag
    ? writings.filter(w => w.tags.includes(filterTag))
    : writings;

  // Show subscription gate for free users
  if (isFree()) {
    return (
      <div
        className="min-h-screen bg-cover bg-center font-['Quicksand'] relative"
        style={{
          backgroundImage: `url('${DEFAULT_BG}')`,
          backgroundBlendMode: 'multiply',
          backgroundColor: 'rgba(0, 0, 0, 0.2)'
        }}
      >
        <div className="relative z-10 p-4">
          <div className="flex items-center justify-between mb-8">
            <Button 
              variant="ghost" 
              onClick={() => navigate(-1)}
              className="text-white -ml-3"
            >
              <ArrowLeft className="w-6 h-6" />
            </Button>
            <Button 
              variant="ghost" 
              onClick={() => navigate("/subscription", { state: { fromNavigation: true } })}
              className="text-white"
            >
              <Crown className="w-6 h-6" />
            </Button>
          </div>

          <motion.div 
            className="text-center mb-8"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl font-extrabold text-white mb-2 tracking-wide font-['Indie Flower']">
              Creative Writing
            </h1>
            <div className="flex items-center justify-center gap-3">
              <div className="h-0.5 w-12 bg-gradient-to-r from-transparent via-pink-400 to-transparent" />
              <span className="text-pink-300">✨</span>
              <div className="h-0.5 w-12 bg-gradient-to-r from-transparent via-pink-400 to-transparent" />
            </div>
          </motion.div>

          <div className="max-w-2xl mx-auto flex items-center justify-center min-h-[60vh]">
            <div className="bg-white/80 rounded-xl p-6 text-center border-2 border-[#8B4769]/20">
              <div className="mb-4">
                <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Crown className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-[#8B4769] mb-2">
                  Upgrade to Velory Plus
                </h3>
                <p className="text-[#8B4769]/70 mb-4">
                  Creative Writing is available with Velory Plus and Pro. Unleash your creativity with unlimited writing!
                </p>
              </div>
              
              <Button
                onClick={() => navigate('/subscription')}
                className="bg-gradient-to-r from-[#8B4769] to-[#96536F] text-white hover:from-[#96536F] hover:to-[#8B4769] px-6 py-2"
              >
                <Crown className="w-4 h-4 mr-2" />
                Upgrade Now
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-cover bg-center font-['Quicksand'] relative"
      style={{
        backgroundImage: selectedWriting ? `url('${bgImageUrl}')` : `url('${DEFAULT_BG}')`,
        backgroundBlendMode: 'multiply',
        backgroundColor: selectedWriting ? 'rgba(255, 255, 255, 0.9)' : 'rgba(0, 0, 0, 0.2)'
      }}
    >
      {/* Background overlay for selected writing */}
      {selectedWriting && bgImageUrl !== DEFAULT_BG && (
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-30 pointer-events-none"
          style={{ backgroundImage: `url('${bgImageUrl}')` }}
        />
      )}
      
      <div className="relative z-10">
        {!selectedWriting ? (
          <div className="p-4">
            <div className="flex items-center justify-between mb-8">
              <Button 
                variant="ghost" 
                onClick={() => navigate(-1)}
                className="text-white -ml-3"
              >
                <ArrowLeft className="w-6 h-6" />
              </Button>
              <Button 
                variant="ghost" 
                onClick={() => navigate("/subscription", { state: { fromNavigation: true } })}
                className="text-white"
              >
                <Crown className="w-6 h-6" />
              </Button>
            </div>

            <motion.div 
              className="text-center mb-8"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl font-extrabold text-white mb-2 tracking-wide font-['Indie Flower']">
                Creative Writing
              </h1>
              <div className="flex items-center justify-center gap-3">
                <div className="h-0.5 w-12 bg-gradient-to-r from-transparent via-pink-400 to-transparent" />
                <span className="text-pink-300">✨</span>
                <div className="h-0.5 w-12 bg-gradient-to-r from-transparent via-pink-400 to-transparent" />
              </div>
            </motion.div>

            <div className="max-w-2xl mx-auto">
              {/* Usage limit display */}
              {creativeLimit !== -1 && (
                <div className="mb-6">
                  <div className="bg-white/80 rounded-xl p-4 border-2 border-[#8B4769]/20">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-[#8B4769]">Creative Writing Usage</span>
                      <span className="text-sm text-[#8B4769]/70">
                        {writings.length} / {creativeLimit} writings
                      </span>
                    </div>
                    <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all duration-300 ${
                          writings.length >= creativeLimit ? 'bg-red-500' : 'bg-green-500'
                        }`}
                        style={{ width: `${Math.min((writings.length / creativeLimit) * 100, 100)}%` }}
                      />
                    </div>
                    {writings.length >= creativeLimit && (
                      <div className="text-center mt-2">
                        <p className="text-sm text-red-600 mb-2">Creative writing limit reached</p>
                        <Button
                          size="sm"
                          onClick={() => navigate('/subscription')}
                          className="bg-[#8B4769] text-white hover:bg-[#96536F]"
                        >
                          <Crown className="w-3 h-3 mr-1" />
                          Upgrade for More
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Feature info for Plus users */}
              {hasAccess && (
                <div className="mb-6">
                  <div className="bg-blue-50/80 rounded-xl p-4 border-2 border-blue-200">
                    <div className="text-sm text-blue-800">
                      <strong>✨ Creative Writing Features:</strong> You can create up to {creativeLimit === -1 ? 'unlimited' : creativeLimit} creative writings and customize background images for all your entries!
                    </div>
                  </div>
                </div>
              )}

              <div className="flex flex-wrap gap-2 mb-6">
                <button
                  onClick={() => setFilterTag(null)}
                  className={`px-3 py-1 rounded-full text-sm border-2 ${
                    filterTag === null
                      ? 'bg-white text-[#8B4769] border-white'
                      : 'bg-white/20 text-white border-white/30'
                  }`}
                >
                  All
                </button>
                {allTags.map(tag => (
                  <button
                    key={tag}
                    onClick={() => setFilterTag(filterTag === tag ? null : tag)}
                    className={`px-3 py-1 rounded-full text-sm border-2 ${
                      filterTag === tag
                        ? 'bg-white text-[#8B4769] border-white'
                        : 'bg-white/20 text-white border-white/30'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>

              <div className="grid gap-4">
                {filteredWritings.map((writing, index) => (
                  <motion.div
                    key={writing.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white/80 rounded-xl p-6 hover:bg-white/90 transition-all duration-300 hover:shadow-lg border-2 border-[#8B4769]/20"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 cursor-pointer" onClick={() => setSelectedWriting(writing)}>
                        <div className="flex items-center gap-2 mb-3">
                          <h3 className="text-xl font-semibold text-[#8B4769]">{writing.title}</h3>
                          <span className="bg-green-100 text-green-600 text-xs px-2 py-1 rounded-full">
                            Custom BG Available
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-2 mb-3">
                          {writing.tags.map(tag => (
                            <span
                              key={tag}
                              className="px-2 py-1 bg-[#8B4769]/10 rounded-full text-xs text-[#8B4769]"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-[#8B4769]/70">
                          <Clock className="w-4 h-4" />
                          <span>Last modified: {format(new Date(writing.updatedAt), 'MMM d, yyyy h:mm a')}</span>
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="text-[#8B4769]">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          <DropdownMenuItem onClick={() => setSelectedWriting(writing)}>
                            <Eye className="w-4 h-4 mr-2" />
                            View
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => handleDeleteWriting(writing.id)}
                            className="text-red-600"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            <Button
              onClick={() => {
                if (canCreateWriting()) {
                  setShowNewDialog(true);
                } else {
                  setShowUpgradeDialog(true);
                }
              }}
              className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-[#8B4769] hover:bg-[#96536F] shadow-lg"
            >
              <Plus className="w-6 h-6" />
            </Button>
          </div>
        ) : (
          <div className="h-screen flex flex-col">
            {/* Title at the top center */}
            <div className="bg-white/80 py-2 px-4 text-center border-b border-[#8B4769]/20 min-h-[32px] flex items-center justify-center">
              <h2 className="text-lg font-semibold text-[#8B4769]">{selectedWriting.title}</h2>
            </div>

            {/* Compact Toolbar */}
            <div className="bg-white/80 px-4 py-1 border-b border-[#8B4769]/20 min-h-[32px]">
              <div className="flex items-center justify-between max-w-4xl mx-auto">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setSelectedWriting(null);
                    setIsReadMode(false);
                    setBgImageUrl(DEFAULT_BG);
                  }}
                  className="text-[#8B4769] h-6 px-2 text-sm"
                >
                  <ArrowLeft className="w-3 h-3 mr-1" />
                  Back
                </Button>
                <div className="flex items-center gap-1">
                  {!isReadMode && (
                    <>
                      <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleBgImageChange}
                        accept="image/*"
                        className="hidden"
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => fileInputRef.current?.click()}
                        className="text-[#8B4769] h-6 w-6 p-0"
                        title="Change background"
                      >
                        <ImageIcon className="w-3 h-3" />
                      </Button>
                      {bgImageUrl !== DEFAULT_BG && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={handleDeleteBackground}
                          className="text-red-600 h-6 w-6 p-0"
                          title="Remove background"
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleSave}
                        className="text-[#8B4769] h-6 px-2 text-sm"
                      >
                        <Save className="w-3 h-3 mr-1" />
                        Save
                      </Button>
                    </>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsReadMode(!isReadMode)}
                    className="text-[#8B4769] h-6 w-6 p-0"
                    title={isReadMode ? "Edit mode" : "Read mode"}
                  >
                    {isReadMode ? <Pencil className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  </Button>
                </div>
              </div>
            </div>

            <div className="flex-1 overflow-auto">
              <div className="max-w-4xl mx-auto">
                <SimpleEditor
                  content={selectedWriting.content}
                  onChange={handleContentChange}
                  placeholder="Start writing your masterpiece..."
                  readOnly={isReadMode}
                  className="h-full"
                />
              </div>
            </div>

            <div className="bg-white/80 border-t border-[#8B4769]/20 py-2 px-4 min-h-[32px]">
              <div className="max-w-4xl mx-auto flex items-center justify-end">
                <div className="flex gap-1">
                  {selectedWriting.tags.map(tag => (
                    <span key={tag} className="px-2 py-0.5 bg-[#8B4769]/10 rounded-full text-xs text-[#8B4769]">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Upgrade Dialog */}
      <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
        <DialogContent className="w-[95vw] max-w-[400px] bg-white rounded-3xl p-6">
          <DialogHeader>
            <DialogTitle className="text-center text-xl font-semibold text-[#8B4769] mb-3">Upgrade Required</DialogTitle>
          </DialogHeader>
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <p className="text-[#8B4769]/80 mb-6">
              {!hasAccess 
                ? "Creative Writing is available with Velory Plus and Pro. Unleash your creativity with unlimited writing!"
                : `You've reached your creative writing limit of ${creativeLimit} writings. Upgrade to Pro for unlimited creative writing.`
              }
            </p>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowUpgradeDialog(false)}
                className="flex-1 border-[#8B4769] text-[#8B4769]"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  setShowUpgradeDialog(false);
                  navigate('/subscription');
                }}
                className="flex-1 bg-[#8B4769] text-white hover:bg-[#96536F]"
              >
                <Crown className="w-4 h-4 mr-2" />
                Upgrade
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showNewDialog} onOpenChange={setShowNewDialog}>
        <DialogContent className="sm:max-w-[500px] bg-[#FEE2E2]/95">
          <DialogHeader>
            <DialogTitle className="text-[#8B4769]">New Writing</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <input
              type="text"
              placeholder="Title"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
            />

            <div>
              <label className="block text-sm font-medium mb-2 text-[#8B4769]">Tags</label>
              <div className="flex flex-wrap gap-2 mb-3">
                {allTags.map(tag => (
                  <button
                    key={tag}
                    onClick={() => {
                      setSelectedTags(prev =>
                        prev.includes(tag)
                          ? prev.filter(t => t !== tag)
                          : [...prev, tag]
                      );
                    }}
                    className={`px-3 py-1 rounded-full text-sm border-2 ${
                      selectedTags.includes(tag)
                        ? 'bg-[#8B4769] text-white border-[#8B4769]'
                        : 'bg-white/50 text-[#8B4769] border-[#8B4769]/20'
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>
              
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Add custom tag"
                  value={customTag}
                  onChange={(e) => setCustomTag(e.target.value)}
                  className="flex-1 p-2 rounded-lg border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
                  onKeyPress={(e) => e.key === 'Enter' && handleAddCustomTag()}
                />
                <Button
                  onClick={handleAddCustomTag}
                  disabled={!customTag.trim() || allTags.includes(customTag.trim())}
                  className="bg-[#8B4769] text-white hover:bg-[#96536F]"
                >
                  Add
                </Button>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowNewDialog(false);
                setNewTitle('');
                setSelectedTags([]);
                setCustomTag('');
              }}
              className="border-[#8B4769] text-[#8B4769]"
            >
              Cancel
            </Button>
            <Button
              onClick={handleNewWriting}
              disabled={!newTitle.trim()}
              className="bg-[#8B4769] text-white hover:bg-[#96536F]"
            >
              Create
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};