import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, MoreVertical, ChevronDown, Search, X } from 'lucide-react';
import { format } from 'date-fns';
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "../../components/ui/dropdown-menu";
import { mediaApi, type MediaItem } from '../../lib/api';
import { useAuthContext } from '../../components/AuthProvider';

interface MediaTrackerProps {
  trackerId: string;
  trackerName: string;
  type: 'show' | 'book';
}

const ITEMS_PER_PAGE = 12;
const GENRES = ['Action', 'Drama', 'Comedy', 'Thriller', 'Romance', 'Fantasy', 'Sci-Fi', 'Mystery'];

export const MediaTracker: React.FC<MediaTrackerProps> = ({ trackerId, trackerName, type }) => {
  const { user } = useAuthContext();
  const [items, setItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<'pending' | 'ongoing' | 'completed'>('ongoing');
  const [sortBy, setSortBy] = useState<'title' | 'progress' | 'updated'>('updated');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MediaItem | null>(null);
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [progressModalOpen, setProgressModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<MediaItem | null>(null);
  const [tempProgress, setTempProgress] = useState<number>(0);

  // Check if this is a built-in tracker (uses string ID) or custom tracker (uses UUID)
  const isBuiltInTracker = trackerId === 'tv-shows' || trackerId === 'books';
  const actualTrackerId = isBuiltInTracker ? null : trackerId;

  // Reset form state when opening modal
  const [newItem, setNewItem] = useState<Partial<MediaItem>>({
    type,
    status: 'pending',
    genres: [],
    total_episodes: undefined,
    watched_episodes: undefined,
    title: '',
    description: '',
    total_seasons: undefined,
    tracker_id: actualTrackerId
  });

  useEffect(() => {
    if (user) {
      loadItems();
    }
  }, [user, trackerId]);

  const loadItems = async () => {
    try {
      setLoading(true);
      // Load items specific to this tracker, using null for built-in trackers
      const trackerItems = await mediaApi.getMediaItems(type, undefined, actualTrackerId);
      setItems(trackerItems);
    } catch (error) {
      console.error('Error loading media items:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateProgress = useCallback((item: MediaItem): number => {
    if (item.total_episodes && item.watched_episodes) {
      return Math.round((item.watched_episodes / item.total_episodes) * 100);
    }
    return 0;
  }, []);

  const handleProgressUpdate = useCallback(async (item: MediaItem, watchedEpisodes: number) => {
    if (!item.total_episodes) return;
    
    try {
      await mediaApi.updateProgress(item.id, Math.min(watchedEpisodes, item.total_episodes));
      await loadItems(); // Refresh the list
    } catch (error) {
      console.error('Error updating progress:', error);
    }
  }, []);

  const filteredAndSortedItems = useMemo(() => {
    let filtered = items.filter(item => 
      item.status === selectedStatus &&
      (searchQuery === '' || 
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.description?.toLowerCase().includes(searchQuery.toLowerCase()) ?? false))
    );

    if (selectedGenres.length > 0) {
      filtered = filtered.filter(item => 
        selectedGenres.every(genre => item.genres.includes(genre))
      );
    }

    return filtered.sort((a, b) => {
      switch (sortBy) {
        case 'title':
          return a.title.localeCompare(b.title);
        case 'progress':
          return calculateProgress(b) - calculateProgress(a);
        case 'updated':
          return new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime();
        default:
          return 0;
      }
    });
  }, [items, selectedStatus, searchQuery, selectedGenres, sortBy, calculateProgress]);

  const resetForm = () => {
    setNewItem({
      type,
      status: 'pending',
      genres: [],
      total_episodes: undefined,
      watched_episodes: undefined,
      title: '',
      description: '',
      total_seasons: undefined,
      tracker_id: actualTrackerId
    });
  };

  const handleSave = useCallback(async () => {
    if (!newItem.title || !user?.id) return;

    try {
      const itemToSave = {
        title: newItem.title,
        description: newItem.description || '',
        type,
        genres: newItem.genres || [],
        status: 'pending' as const,
        total_seasons: newItem.total_seasons,
        total_episodes: newItem.total_episodes,
        watched_episodes: newItem.watched_episodes || 0,
        user_id: user.id,
        tracker_id: actualTrackerId // Use null for built-in trackers, UUID for custom trackers
      };

      if (editingItem) {
        await mediaApi.updateMediaItem(editingItem.id, itemToSave);
      } else {
        await mediaApi.createMediaItem(itemToSave);
      }

      await loadItems(); // Refresh the list
      setIsAddModalOpen(false);
      setEditingItem(null);
      resetForm();
    } catch (error) {
      console.error('Error saving media item:', error);
    }
  }, [newItem, editingItem, type, user?.id, actualTrackerId]);

  const handleDelete = useCallback(async (id: string) => {
    try {
      await mediaApi.deleteMediaItem(id);
      await loadItems(); // Refresh the list
    } catch (error) {
      console.error('Error deleting media item:', error);
    }
  }, []);

  const handleOpenAddModal = () => {
    setEditingItem(null);
    resetForm();
    setIsAddModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsAddModalOpen(false);
    setEditingItem(null);
    resetForm();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FEE2E2] flex items-center justify-center">
        <div className="text-[#8B4769] text-xl font-semibold">Loading {trackerName}...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FEE2E2] p-4 font-['Quicksand']">
      <h1 className="text-2xl font-bold text-center text-[#8B4769] mb-6">
        {trackerName}
      </h1>

      <div className="flex flex-col gap-4 max-w-4xl mx-auto">
        <div className="flex items-center gap-4 bg-white/80 p-4 rounded-xl border-2 border-[#8B4769]/20">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#8B4769] w-5 h-5" />
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#8B4769] hover:text-[#96536F]"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {selectedStatus === 'ongoing' && (
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'title' | 'progress' | 'updated')}
              className="p-2 rounded-lg border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50 text-[#8B4769]"
            >
              <option value="updated">Last Updated</option>
              <option value="title">Title</option>
              <option value="progress">Progress</option>
            </select>
          )}
        </div>

        <Tabs value={selectedStatus} onValueChange={(value) => setSelectedStatus(value as typeof selectedStatus)}>
          <TabsList className="w-full bg-white/80 rounded-xl p-1 border-2 border-[#8B4769]/20">
            <TabsTrigger value="ongoing" className="flex-1 text-[#8B4769] font-semibold">Ongoing</TabsTrigger>
            <TabsTrigger value="pending" className="flex-1 text-[#8B4769] font-semibold">Pending</TabsTrigger>
            <TabsTrigger value="completed" className="flex-1 text-[#8B4769] font-semibold">Completed</TabsTrigger>
          </TabsList>

          <div className="flex flex-wrap gap-2 my-4">
            {GENRES.map(genre => (
              <button
                key={genre}
                onClick={() => setSelectedGenres(prev => 
                  prev.includes(genre) 
                    ? prev.filter(g => g !== genre)
                    : [...prev, genre]
                )}
                className={`px-3 py-1 rounded-full text-sm border-2 ${
                  selectedGenres.includes(genre)
                    ? 'bg-[#8B4769] text-white border-[#8B4769]'
                    : 'bg-white/80 text-[#8B4769] border-[#8B4769]/20'
                }`}
              >
                {genre}
              </button>
            ))}
          </div>

          <AnimatePresence mode="popLayout">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredAndSortedItems.map((item) => (
                <motion.div
                  key={item.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="bg-white/80 rounded-xl p-4 shadow-md relative border-2 border-[#8B4769]/20"
                >
                  <div className="absolute top-2 right-2">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="text-[#8B4769]">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem onClick={() => {
                          setSelectedItem(item);
                          setTempProgress(item.watched_episodes || 0);
                          setProgressModalOpen(true);
                        }}>
                          Update Progress
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => {
                          setEditingItem(item);
                          setNewItem({
                            ...item,
                            type,
                            status: 'pending',
                            genres: item.genres || [],
                            total_episodes: item.total_episodes,
                            watched_episodes: item.watched_episodes,
                            tracker_id: actualTrackerId
                          });
                          setIsAddModalOpen(true);
                        }}>
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          className="text-red-600"
                          onClick={() => handleDelete(item.id)}
                        >
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  <h3 className="font-bold text-lg text-[#8B4769] pr-8">{item.title}</h3>
                  {item.description && (
                    <p className="text-sm text-[#8B4769] line-clamp-2 mb-2">{item.description}</p>
                  )}

                  <div className="flex flex-wrap gap-1 mb-2">
                    {item.genres.map(genre => (
                      <span
                        key={genre}
                        className="px-2 py-0.5 bg-[#8B4769]/10 rounded-full text-xs text-[#8B4769] font-medium"
                      >
                        {genre}
                      </span>
                    ))}
                  </div>

                  <div className="mt-2 text-[#8B4769]">
                    {item.total_seasons && (
                      <div className="text-sm mb-2">
                        Total {type === 'show' ? 'Seasons' : 'Volumes'}: {item.total_seasons}
                      </div>
                    )}
                    
                    {item.total_episodes !== undefined && (
                      <>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Progress</span>
                          <span>{calculateProgress(item)}%</span>
                        </div>
                        <div className="w-full h-2 bg-[#8B4769]/20 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-[#8B4769] rounded-full transition-all duration-300"
                            style={{ width: `${calculateProgress(item)}%` }}
                          />
                        </div>
                        <div className="text-sm mt-1">
                          {item.watched_episodes} / {item.total_episodes} {type === 'show' ? 'Episodes' : 'Chapters'}
                        </div>
                      </>
                    )}
                  </div>

                  <div className="mt-2 text-xs text-[#8B4769]/80">
                    Last updated: {format(new Date(item.updated_at), 'MMM d, yyyy')}
                  </div>
                </motion.div>
              ))}
            </div>
          </AnimatePresence>
        </Tabs>

        {filteredAndSortedItems.length === 0 && (
          <div className="text-center py-8 text-[#8B4769]">
            No items found in this tracker
          </div>
        )}

        <Button
          onClick={handleOpenAddModal}
          className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-[#8B4769] hover:bg-[#96536F] shadow-lg"
        >
          <Plus className="w-6 h-6" />
        </Button>

        <Dialog open={isAddModalOpen} onOpenChange={handleCloseModal}>
          <DialogContent className="sm:max-w-[90vw] md:max-w-[500px] max-h-[90vh] overflow-y-auto bg-[#FEE2E2]/95">
            <DialogHeader>
              <DialogTitle className="text-[#8B4769]">
                {editingItem ? 'Edit' : 'Add New'} {type === 'show' ? 'TV Show' : 'Book'}
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-4">
              <input
                type="text"
                placeholder="Title"
                value={newItem.title || ''}
                onChange={(e) => setNewItem({ ...newItem, title: e.target.value })}
                className="w-full p-2 rounded-lg border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50 text-[#8B4769]"
              />

              <textarea
                placeholder="Description (optional)"
                value={newItem.description || ''}
                onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
                className="w-full p-2 rounded-lg border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50 text-[#8B4769] min-h-[80px] resize-none"
              />

              <div>
                <label className="block text-sm font-medium mb-2 text-[#8B4769]">
                  Total {type === 'show' ? 'Seasons' : 'Volumes'} (optional)
                </label>
                <input
                  type="number"
                  min="1"
                  value={newItem.total_seasons || ''}
                  onChange={(e) => setNewItem({ ...newItem, total_seasons: e.target.value ? parseInt(e.target.value) : undefined })}
                  className="w-full p-2 rounded-lg border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50 text-[#8B4769]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 text-[#8B4769]">
                  Total {type === 'show' ? 'Episodes' : 'Chapters'}
                </label>
                <input
                  type="number"
                  min="0"
                  value={newItem.total_episodes || ''}
                  onChange={(e) => setNewItem({ ...newItem, total_episodes: e.target.value ? parseInt(e.target.value) : undefined })}
                  className="w-full p-2 rounded-lg border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50 text-[#8B4769]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 text-[#8B4769]">Genres</label>
                <div className="flex flex-wrap gap-2">
                  {GENRES.map(genre => (
                    <button
                      key={genre}
                      onClick={() => {
                        const genres = newItem.genres || [];
                        setNewItem({
                          ...newItem,
                          genres: genres.includes(genre)
                            ? genres.filter(g => g !== genre)
                            : [...genres, genre]
                        });
                      }}
                      className={`px-3 py-1 rounded-full text-sm border-2 ${
                        (newItem.genres || []).includes(genre)
                          ? 'bg-[#8B4769] text-white border-[#8B4769]'
                          : 'bg-white/50 text-[#8B4769] border-[#8B4769]/20'
                      }`}
                    >
                      {genre}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <DialogFooter className="mt-6">
              <Button
                variant="outline"
                onClick={handleCloseModal}
                className="border-[#8B4769] text-[#8B4769]"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSave}
                disabled={!newItem.title || !user?.id}
                className="bg-[#8B4769] text-white hover:bg-[#96536F]"
              >
                {editingItem ? 'Save Changes' : 'Add'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog open={progressModalOpen} onOpenChange={setProgressModalOpen}>
          <DialogContent className="sm:max-w-[90vw] md:max-w-[400px] bg-[#FEE2E2]/95">
            <DialogHeader>
              <DialogTitle className="text-[#8B4769]">Update Progress</DialogTitle>
            </DialogHeader>

            {selectedItem && selectedItem.total_episodes !== undefined && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-[#8B4769]">
                    {type === 'show' ? 'Episodes' : 'Chapters'} Watched
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min="0"
                      max={selectedItem.total_episodes}
                      value={tempProgress}
                      onChange={(e) => {
                        const value = Math.min(
                          Math.max(0, parseInt(e.target.value) || 0),
                          selectedItem.total_episodes || 0
                        );
                        setTempProgress(value);
                      }}
                      className="w-20 p-2 rounded-lg border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50 text-[#8B4769]"
                    />
                    <span className="text-sm text-[#8B4769]">
                      / {selectedItem.total_episodes} {type === 'show' ? 'Episodes' : 'Chapters'}
                    </span>
                  </div>
                </div>
              </div>
            )}

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setProgressModalOpen(false);
                  setSelectedItem(null);
                }}
                className="border-[#8B4769] text-[#8B4769]"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  if (selectedItem) {
                    handleProgressUpdate(selectedItem, tempProgress);
                    setProgressModalOpen(false);
                    setSelectedItem(null);
                  }
                }}
                className="bg-[#8B4769] text-white hover:bg-[#96536F]"
              >
                Save Progress
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};