import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { motion } from "framer-motion";
import { ArrowLeft, Crown, Check, X, Tag, Sparkles, Gift } from 'lucide-react';
import { subscriptionsApi, type SubscriptionPlan, type CouponCode } from '../../lib/api/subscriptions';
import { useSubscription } from '../../hooks/useSubscription';
import { useAuthContext } from '../../components/AuthProvider';
import { PaymentDialog } from './PaymentDialog';
import type { CustomerInfo } from '../../lib/payments/types';

// Display pricing in USD for visual appeal (actual payment is in INR)
const displayPricing = {
  plus: {
    monthly: 1.19, // ~₹99
    yearly: 11.99  // ~₹999
  },
  pro: {
    monthly: 2.39, // ~₹199
    yearly: 23.99  // ~₹1999
  }
};

export const Subscription = () => {
  const navigate = useNavigate();
  const { user } = useAuthContext();
  const { subscriptionData, updateSubscription, loading: subscriptionLoading } = useSubscription();
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showCouponDialog, setShowCouponDialog] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<CouponCode | null>(null);
  const [couponError, setCouponError] = useState('');
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    loadPlans();
  }, []);

  const loadPlans = async () => {
    try {
      setLoading(true);
      const data = await subscriptionsApi.getPlans();
      setPlans(data);
    } catch (error) {
      console.error('Error loading plans:', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePlanSelect = (plan: SubscriptionPlan) => {
    if (plan.id === 'free') return;
    
    console.log('Plan selected:', plan.id, 'billing cycle:', billingCycle);
    setSelectedPlan(plan);
    setShowPaymentDialog(true);
  };

  const handleCouponApply = async () => {
    if (!couponCode.trim() || !selectedPlan) return;
    
    try {
      setCouponError('');
      const coupon = await subscriptionsApi.validateCoupon(couponCode.trim(), selectedPlan.id);
      
      if (coupon) {
        setAppliedCoupon(coupon);
        setCouponCode('');
      } else {
        setCouponError('Invalid or expired coupon code');
      }
    } catch (error) {
      setCouponError('Error validating coupon');
    }
  };

  const handleFreeAccessCoupon = async () => {
    if (!couponCode.trim()) return;
    
    try {
      setProcessing(true);
      setCouponError('');
      
      console.log('Applying free access coupon:', couponCode.trim());
      
      // Try to apply as free access coupon for Plus plan first
      await subscriptionsApi.applyFreeAccessCoupon(couponCode.trim(), 'plus');
      
      setShowCouponDialog(false);
      setCouponCode('');
      alert('Free access coupon applied successfully! You now have access to Velory Plus.');
      
      // Refresh the page to update subscription status
      window.location.reload();
      
    } catch (error) {
      // If Plus fails, try Pro
      try {
        await subscriptionsApi.applyFreeAccessCoupon(couponCode.trim(), 'pro');
        
        setShowCouponDialog(false);
        setCouponCode('');
        alert('Free access coupon applied successfully! You now have access to Velory Pro.');
        
        // Refresh the page to update subscription status
        window.location.reload();
        
      } catch (proError) {
        console.error('Coupon application error:', error);
        setCouponError('Invalid or expired coupon code');
      }
    } finally {
      setProcessing(false);
    }
  };

  const handlePaymentSuccess = async () => {
    try {
      if (selectedPlan) {
        console.log('Payment successful, updating subscription to:', selectedPlan.id, billingCycle);
        await updateSubscription(selectedPlan.id, billingCycle);
        alert('Subscription updated successfully! Welcome to ' + selectedPlan.display_name + '!');
        window.location.reload();
      }
    } catch (error) {
      console.error('Error updating subscription:', error);
      alert('Payment successful but failed to update subscription. Please contact support.');
    }
  };

  const getCustomerInfo = (): CustomerInfo => {
    return {
      email: user?.email || '',
      name: user?.user_metadata?.username || user?.email?.split('@')[0] || 'User',
      phone: user?.phone || undefined
    };
  };

  const getPlanFeatures = (planId: string) => {
    const features = {
      free: [
        '10 daily tasks',
        '5 important tasks',
        '10 journal entries (300 words each)',
        '5 thoughts entries (150 words total)',
        '10 gratitude days (100 words/day)',
        '2 goals',
        'Current month mood history',
        'Basic read-only offline access'
      ],
      plus: [
        '30 daily tasks',
        '20 important tasks',
        '25 journal entries (1,000 words each)',
        '20 thoughts entries (500 words total)',
        '20 gratitude days (300 words/day)',
        '10 goals',
        'Media trackers (8 items)',
        '10 autobiography cards',
        'Profile avatar upload',
        '10 creative writing entries',
        'Light analytics & yearly mood history'
      ],
      pro: [
        'Unlimited tasks & goals',
        'Unlimited journal & writing entries',
        'Unlimited media trackers',
        'Custom media trackers',
        'Unlimited autobiography cards',
        'Unlimited creative writing',
        'Full analytics & unlimited mood history',
        'Backup & restore functionality',
        'Full offline writing support',
        'Motivational popups'
      ]
    };
    
    return features[planId as keyof typeof features] || [];
  };

  const getDisplayPrice = (planId: string, cycle: 'monthly' | 'yearly') => {
    const pricing = displayPricing[planId as keyof typeof displayPricing];
    return pricing ? pricing[cycle] : 0;
  };

  const currentPlan = subscriptionData?.plan;

  if (loading || subscriptionLoading) {
    return (
      <div className="min-h-screen bg-[#FEE2E2] flex items-center justify-center">
        <div className="text-[#8B4769] text-xl font-semibold">Loading subscription plans...</div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-cover bg-center p-4 font-['Quicksand']"
      style={{
        backgroundImage: "url('https://res.cloudinary.com/db6un9uvp/image/upload/v1745916296/Autobiography_bg_fyshzv.png')",
        backgroundBlendMode: 'multiply',
        backgroundColor: 'rgba(255, 192, 203, 0.7)'
      }}
    >
      <div className="flex items-center justify-between mb-8">
        <Button 
          variant="ghost" 
          onClick={() => navigate(-1)}
          className="text-[#8B4769] -ml-3"
        >
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-4xl font-extrabold text-[#8B4769] mb-2 tracking-wide font-['Indie Flower']">
            Choose Your Plan
          </h1>
        </motion.div>
        <Button 
          variant="ghost" 
          onClick={() => setShowCouponDialog(true)}
          className="text-[#8B4769]"
        >
          <Gift className="w-6 h-6" />
        </Button>
      </div>

      {/* Current Plan Display */}
      {currentPlan && (
        <div className="max-w-4xl mx-auto mb-8">
          <div className="bg-white/80 rounded-xl p-4 border-2 border-[#8B4769]/20 text-center">
            <p className="text-[#8B4769] font-medium">
              Current Plan: <span className="font-bold">{currentPlan.display_name}</span>
            </p>
          </div>
        </div>
      )}

      {/* Billing Toggle */}
      <div className="max-w-4xl mx-auto mb-8">
        <div className="bg-white/80 rounded-xl p-4 border-2 border-[#8B4769]/20">
          <div className="flex items-center justify-center gap-4">
            <span className={`font-medium ${billingCycle === 'monthly' ? 'text-[#8B4769]' : 'text-[#8B4769]/50'}`}>
              Monthly
            </span>
            <button
              onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'yearly' : 'monthly')}
              className={`relative w-12 h-6 rounded-full transition-colors ${
                billingCycle === 'yearly' ? 'bg-[#8B4769]' : 'bg-gray-300'
              }`}
            >
              <div
                className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                  billingCycle === 'yearly' ? 'translate-x-7' : 'translate-x-1'
                }`}
              />
            </button>
            <span className={`font-medium ${billingCycle === 'yearly' ? 'text-[#8B4769]' : 'text-[#8B4769]/50'}`}>
              Yearly
            </span>
            {billingCycle === 'yearly' && (
              <span className="bg-green-100 text-green-600 px-2 py-1 rounded-full text-sm font-medium">
                Save 17%
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Plans Grid */}
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan, index) => {
          const displayPrice = getDisplayPrice(plan.id, billingCycle);
          const isCurrentPlan = currentPlan?.id === plan.id;
          const isPro = plan.id === 'pro';
          const isPlus = plan.id === 'plus';
          
          return (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`relative bg-white/90 rounded-2xl p-6 border-2 ${
                isPro 
                  ? 'border-purple-400 shadow-lg shadow-purple-200' 
                  : isPlus
                  ? 'border-blue-400 shadow-lg shadow-blue-200'
                  : 'border-[#8B4769]/20'
              } ${isCurrentPlan ? 'ring-2 ring-[#8B4769]' : ''}`}
            >
              {isPro && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-to-r from-purple-500 to-purple-600 text-white px-4 py-1 rounded-full text-sm font-medium flex items-center gap-1">
                    <Crown className="w-3 h-3" />
                    Most Popular
                  </div>
                </div>
              )}
              
              <div className="text-center mb-6">
                <h3 className={`text-2xl font-bold mb-2 ${
                  isPro ? 'text-purple-600' : isPlus ? 'text-blue-600' : 'text-[#8B4769]'
                }`}>
                  {plan.display_name}
                </h3>
                
                <div className="mb-4">
                  <span className={`text-4xl font-bold ${
                    isPro ? 'text-purple-600' : isPlus ? 'text-blue-600' : 'text-[#8B4769]'
                  }`}>
                    ${displayPrice.toFixed(2)}
                  </span>
                  <span className="text-gray-600">
                    /{billingCycle === 'yearly' ? 'year' : 'month'}
                  </span>
                </div>
                
                {billingCycle === 'yearly' && displayPrice > 0 && (
                  <p className="text-sm text-green-600 font-medium">
                    Save ${((getDisplayPrice(plan.id, 'monthly') * 12) - getDisplayPrice(plan.id, 'yearly')).toFixed(2)} per year
                  </p>
                )}
              </div>

              <div className="space-y-3 mb-6">
                {getPlanFeatures(plan.id).map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-2">
                    <Check className={`w-4 h-4 mt-0.5 flex-shrink-0 ${
                      isPro ? 'text-purple-600' : isPlus ? 'text-blue-600' : 'text-green-600'
                    }`} />
                    <span className="text-sm text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>

              <Button
                onClick={() => handlePlanSelect(plan)}
                disabled={isCurrentPlan || plan.id === 'free'}
                className={`w-full ${
                  isCurrentPlan
                    ? 'bg-gray-300 text-gray-600 cursor-not-allowed'
                    : isPro
                    ? 'bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white'
                    : isPlus
                    ? 'bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white'
                    : 'bg-[#8B4769] hover:bg-[#96536F] text-white'
                }`}
              >
                {isCurrentPlan ? 'Current Plan' : plan.id === 'free' ? 'Free Forever' : 'Choose Plan'}
              </Button>
            </motion.div>
          );
        })}
      </div>

      {/* Payment Dialog */}
      {selectedPlan && (
        <PaymentDialog
          open={showPaymentDialog}
          onOpenChange={setShowPaymentDialog}
          plan={selectedPlan}
          billingCycle={billingCycle}
          onSuccess={handlePaymentSuccess}
          customerInfo={getCustomerInfo()}
        />
      )}

      {/* Free Access Coupon Dialog */}
      <Dialog open={showCouponDialog} onOpenChange={setShowCouponDialog}>
        <DialogContent className="w-[95vw] max-w-[400px] bg-[#FEE2E2]/95">
          <DialogHeader>
            <DialogTitle className="text-[#8B4769] flex items-center gap-2">
              <Gift className="w-5 h-5" />
              Redeem Coupon Code
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <p className="text-[#8B4769]/80 text-sm">
              Have a coupon code? Enter it below to unlock free access to Velory Plus or Pro!
            </p>
            
            <div className="space-y-2">
              <input
                type="text"
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                placeholder="Enter coupon code"
                className="w-full p-3 rounded-xl border-2 border-[#8B4769]/20 focus:outline-none focus:ring-2 focus:ring-[#8B4769] bg-white/50 text-center font-mono text-lg"
              />
              
              {couponError && (
                <p className="text-red-600 text-sm text-center">{couponError}</p>
              )}
            </div>

            <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
              <p className="text-blue-800 text-xs">
                <strong>Note:</strong> Free access coupons will grant you temporary access to premium features. 
                The duration depends on the specific coupon code.
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowCouponDialog(false);
                setCouponCode('');
                setCouponError('');
              }}
              className="border-[#8B4769] text-[#8B4769]"
            >
              Cancel
            </Button>
            <Button
              onClick={handleFreeAccessCoupon}
              disabled={!couponCode.trim() || processing}
              className="bg-[#8B4769] text-white hover:bg-[#96536F]"
            >
              <Gift className="w-4 h-4 mr-2" />
              {processing ? 'Applying...' : 'Redeem Coupon'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};