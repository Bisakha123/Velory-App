import React, { useState, useEffect } from 'react';
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "../../components/ui/dialog";
import { motion } from "framer-motion";
import { CreditCard, Loader2, CheckCircle, AlertCircle, ArrowLeft, RefreshCw } from 'lucide-react';
import { PaymentMethodSelector } from '../../components/PaymentMethodSelector';
import { PaymentManager } from '../../lib/payments/PaymentManager';
import { paymentConfig, planPricing } from '../../lib/payments/config';
import type { PaymentMethod, PaymentResult, CustomerInfo } from '../../lib/payments/types';
import type { SubscriptionPlan } from '../../lib/api/subscriptions';

interface PaymentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  plan: SubscriptionPlan;
  billingCycle: 'monthly' | 'yearly';
  onSuccess: () => void;
  customerInfo: CustomerInfo;
}

export const PaymentDialog: React.FC<PaymentDialogProps> = ({
  open,
  onOpenChange,
  plan,
  billingCycle,
  onSuccess,
  customerInfo
}) => {
  const [paymentManager] = useState(() => new PaymentManager(paymentConfig));
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null);
  const [processing, setProcessing] = useState(false);
  const [step, setStep] = useState<'select' | 'processing' | 'success' | 'error'>('select');
  const [error, setError] = useState<string>('');
  const [userCountry] = useState('IN');
  const [userCurrency] = useState('INR');

  useEffect(() => {
    if (open) {
      initializePayment();
    }
  }, [open]);

  const initializePayment = async () => {
    try {
      console.log('🔄 Initializing payment for plan:', plan.id, 'cycle:', billingCycle);
      
      // Reset state
      setStep('select');
      setError('');
      setProcessing(false);
      
      // Get available payment methods
      const methods = paymentManager.getAvailablePaymentMethods();
      console.log('💳 Available payment methods:', methods.length);
      
      setPaymentMethods(methods);
      
      // Auto-select the first UPI method (most popular in India)
      const upiMethod = methods.find(m => m.type === 'upi' && m.isPopular);
      if (upiMethod) {
        setSelectedMethod(upiMethod);
        console.log('✅ Auto-selected UPI method:', upiMethod.name);
      } else if (methods.length > 0) {
        setSelectedMethod(methods[0]);
        console.log('✅ Auto-selected first method:', methods[0].name);
      }
    } catch (error) {
      console.error('❌ Error initializing payment:', error);
      setError('Failed to initialize payment methods. Please refresh and try again.');
    }
  };

  const getAmount = () => {
    const pricing = planPricing[plan.id as keyof typeof planPricing];
    if (!pricing) {
      console.error('❌ No pricing found for plan:', plan.id);
      return 0;
    }
    
    const amount = pricing[billingCycle];
    console.log('💰 Payment amount:', amount, 'for plan:', plan.id, 'cycle:', billingCycle);
    return amount;
  };

  const handlePayment = async () => {
    if (!selectedMethod) {
      setError('Please select a payment method');
      return;
    }

    console.log('🚀 Starting payment process with method:', selectedMethod.name);
    setProcessing(true);
    setStep('processing');
    setError('');

    try {
      const amount = getAmount();
      
      if (amount <= 0) {
        throw new Error('Invalid payment amount');
      }

      console.log('💳 Processing payment:', {
        provider: selectedMethod.providerId,
        amount,
        currency: userCurrency,
        plan: plan.id,
        cycle: billingCycle,
        customer: customerInfo.email,
        method: selectedMethod.id
      });
      
      const result: PaymentResult = await paymentManager.processPayment(
        selectedMethod.providerId,
        amount,
        userCurrency,
        plan.id,
        billingCycle,
        customerInfo,
        selectedMethod.id
      );

      console.log('📊 Payment result:', result);

      if (result.success) {
        console.log('✅ Payment successful! Transaction ID:', result.transactionId);
        setStep('success');
        
        // Call success callback after showing success state
        setTimeout(() => {
          onSuccess();
          onOpenChange(false);
        }, 2500);
      } else {
        console.error('❌ Payment failed:', result.error);
        setError(result.error || 'Payment failed. Please try again.');
        setStep('error');
      }
    } catch (error: any) {
      console.error('❌ Payment processing error:', error);
      setError(error.message || 'Payment processing failed. Please try again.');
      setStep('error');
    } finally {
      setProcessing(false);
    }
  };

  const resetDialog = () => {
    console.log('🔄 Resetting payment dialog');
    setStep('select');
    setError('');
    setProcessing(false);
    setSelectedMethod(paymentMethods.find(m => m.type === 'upi' && m.isPopular) || paymentMethods[0] || null);
  };

  const handleClose = () => {
    if (step === 'processing') {
      // Don't allow closing during payment processing
      return;
    }
    onOpenChange(false);
  };

  const amount = getAmount();

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="w-[95vw] max-w-[500px] max-h-[90vh] overflow-y-auto bg-[#FEE2E2]/95">
        <DialogHeader>
          <DialogTitle className="text-[#8B4769] flex items-center gap-2">
            {step === 'select' && <CreditCard className="w-5 h-5" />}
            {step === 'processing' && <Loader2 className="w-5 h-5 animate-spin" />}
            {step === 'success' && <CheckCircle className="w-5 h-5 text-green-600" />}
            {step === 'error' && <AlertCircle className="w-5 h-5 text-red-600" />}
            
            {step === 'select' && 'Complete Payment'}
            {step === 'processing' && 'Processing Payment...'}
            {step === 'success' && 'Payment Successful!'}
            {step === 'error' && 'Payment Failed'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {step === 'select' && (
            <>
              {/* Plan Summary */}
              <div className="bg-white/80 rounded-xl p-4 border-2 border-[#8B4769]/20">
                <h4 className="font-semibold text-[#8B4769] mb-2">{plan.display_name}</h4>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600 text-sm">
                    {billingCycle === 'yearly' ? 'Annual' : 'Monthly'} Plan
                  </span>
                  <div className="text-xl font-bold text-[#8B4769]">
                    ₹{amount.toFixed(0)}
                  </div>
                </div>
                
                {billingCycle === 'yearly' && (
                  <div className="mt-2 text-sm text-green-600 font-medium">
                    Save 17% with annual billing
                  </div>
                )}
              </div>

              {/* Payment Method Selection */}
              {paymentMethods.length > 0 ? (
                <PaymentMethodSelector
                  paymentMethods={paymentMethods}
                  onSelect={setSelectedMethod}
                  selectedMethod={selectedMethod}
                  amount={amount}
                  currency={userCurrency}
                  userCountry={userCountry}
                />
              ) : (
                <div className="text-center py-8">
                  <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2 text-[#8B4769]" />
                  <div className="text-[#8B4769]/70">Loading payment methods...</div>
                </div>
              )}
            </>
          )}

          {step === 'processing' && (
            <div className="text-center py-8">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                className="w-16 h-16 border-4 border-[#8B4769]/20 border-t-[#8B4769] rounded-full mx-auto mb-4"
              />
              <div className="text-[#8B4769] font-medium mb-2">Processing your payment...</div>
              <div className="text-sm text-[#8B4769]/70 mb-2">
                Complete the payment in the Razorpay window
              </div>
              <div className="text-xs text-[#8B4769]/50 bg-blue-50 p-3 rounded-lg">
                💡 <strong>Tip:</strong> If the payment window doesn't open, please disable your popup blocker and try again.
              </div>
            </div>
          )}

          {step === 'success' && (
            <div className="text-center py-8">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 200 }}
                className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4"
              >
                <CheckCircle className="w-8 h-8 text-green-600" />
              </motion.div>
              <div className="text-[#8B4769] font-medium mb-2">Payment Successful! 🎉</div>
              <div className="text-sm text-[#8B4769]/70 mb-2">
                Welcome to {plan.display_name}!
              </div>
              <div className="text-xs text-[#8B4769]/50">
                Your subscription is now active. Redirecting...
              </div>
            </div>
          )}

          {step === 'error' && (
            <div className="text-center py-8">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 200 }}
                className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4"
              >
                <AlertCircle className="w-8 h-8 text-red-600" />
              </motion.div>
              <div className="text-red-600 font-medium mb-2">Payment Failed</div>
              <div className="text-sm text-[#8B4769]/70 mb-4 px-4">{error}</div>
              
              <div className="flex gap-2 justify-center">
                <Button
                  onClick={resetDialog}
                  variant="outline"
                  className="border-[#8B4769] text-[#8B4769]"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Try Again
                </Button>
                <Button
                  onClick={() => window.location.reload()}
                  variant="outline"
                  className="border-blue-500 text-blue-600"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Refresh Page
                </Button>
              </div>
            </div>
          )}
        </div>

        {step === 'select' && (
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="border-[#8B4769] text-[#8B4769]"
            >
              Cancel
            </Button>
            <Button
              onClick={handlePayment}
              disabled={!selectedMethod || processing || amount <= 0}
              className="bg-[#8B4769] text-white hover:bg-[#96536F]"
            >
              {processing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  Pay ₹{amount.toFixed(0)}
                </>
              )}
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
};