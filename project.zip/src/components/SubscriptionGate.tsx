import React from 'react';
import { useSubscription } from '../hooks/useSubscription';
import { Button } from './ui/button';
import { useNavigate } from 'react-router-dom';
import { Crown, Lock } from 'lucide-react';

interface SubscriptionGateProps {
  feature: string;
  requiredPlan?: 'plus' | 'pro';
  children: React.ReactNode;
  fallback?: React.ReactNode;
  showUpgrade?: boolean;
}

export const SubscriptionGate: React.FC<SubscriptionGateProps> = ({
  feature,
  requiredPlan = 'plus',
  children,
  fallback,
  showUpgrade = true
}) => {
  const { canUseFeature, isPro, isPlus, isFree } = useSubscription();
  const navigate = useNavigate();

  const hasAccess = () => {
    if (requiredPlan === 'pro') {
      return isPro();
    }
    if (requiredPlan === 'plus') {
      return isPlus() || isPro();
    }
    return canUseFeature(feature);
  };

  if (hasAccess()) {
    return <>{children}</>;
  }

  if (fallback) {
    return <>{fallback}</>;
  }

  if (!showUpgrade) {
    return null;
  }

  const planName = requiredPlan === 'pro' ? 'Velory Pro' : 'Velory Plus';
  const planColor = requiredPlan === 'pro' ? 'text-purple-600' : 'text-blue-600';

  return (
    <div className="bg-white/80 rounded-xl p-6 text-center border-2 border-[#8B4769]/20">
      <div className="mb-4">
        <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-3">
          <Crown className="w-8 h-8 text-white" />
        </div>
        <h3 className="text-xl font-semibold text-[#8B4769] mb-2">
          Upgrade to {planName}
        </h3>
        <p className="text-[#8B4769]/70 mb-4">
          This feature requires a {planName} subscription to unlock.
        </p>
      </div>
      
      <Button
        onClick={() => navigate('/subscription')}
        className="bg-gradient-to-r from-[#8B4769] to-[#96536F] text-white hover:from-[#96536F] hover:to-[#8B4769] px-6 py-2"
      >
        <Crown className="w-4 h-4 mr-2" />
        Upgrade Now
      </Button>
    </div>
  );
};

// Usage limit component
interface UsageLimitProps {
  resourceType: string;
  current?: number;
  limit: number;
  unit?: string;
  showUpgrade?: boolean;
}

export const UsageLimit: React.FC<UsageLimitProps> = ({
  resourceType,
  current,
  limit,
  unit = 'items',
  showUpgrade = true
}) => {
  const navigate = useNavigate();
  const { getCurrentCount } = useSubscription();
  const [actualCurrent, setActualCurrent] = React.useState(current || 0);
  const [loading, setLoading] = React.useState(!current);

  React.useEffect(() => {
    if (current === undefined) {
      // Get actual count from database
      const loadCount = async () => {
        try {
          setLoading(true);
          const count = await getCurrentCount(resourceType);
          setActualCurrent(count);
        } catch (error) {
          console.error('Error loading current count:', error);
          setActualCurrent(0);
        } finally {
          setLoading(false);
        }
      };
      loadCount();
    } else {
      setActualCurrent(current);
      setLoading(false);
    }
  }, [current, resourceType, getCurrentCount]);

  if (loading) {
    return (
      <div className="bg-white/80 rounded-xl p-4 border-2 border-[#8B4769]/20">
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
          <div className="h-2 bg-gray-200 rounded w-full mb-3"></div>
        </div>
      </div>
    );
  }

  const isAtLimit = actualCurrent >= limit;
  const percentage = limit > 0 ? (actualCurrent / limit) * 100 : 0;

  return (
    <div className="bg-white/80 rounded-xl p-4 border-2 border-[#8B4769]/20">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium text-[#8B4769]">
          {resourceType} Usage
        </span>
        <span className="text-sm text-[#8B4769]/70">
          {actualCurrent} / {limit === -1 ? '∞' : limit} {unit}
        </span>
      </div>
      
      {limit > 0 && (
        <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden mb-3">
          <div
            className={`h-full transition-all duration-300 ${
              percentage >= 90 ? 'bg-red-500' : percentage >= 70 ? 'bg-yellow-500' : 'bg-green-500'
            }`}
            style={{ width: `${Math.min(percentage, 100)}%` }}
          />
        </div>
      )}
      
      {isAtLimit && showUpgrade && (
        <div className="text-center">
          <p className="text-sm text-red-600 mb-2">
            You've reached your {resourceType.toLowerCase()} limit
          </p>
          <Button
            size="sm"
            onClick={() => navigate('/subscription')}
            className="bg-[#8B4769] text-white hover:bg-[#96536F]"
          >
            <Lock className="w-3 h-3 mr-1" />
            Upgrade
          </Button>
        </div>
      )}
    </div>
  );
};