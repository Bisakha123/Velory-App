import React, { useState } from 'react';
import { Button } from './ui/button';
import { Gift, Loader2 } from 'lucide-react';
import { useAdMob } from '../hooks/useAdMob';

interface RewardedAdButtonProps {
  onReward?: (reward: { type: string; amount: number }) => void;
  onError?: (error: string) => void;
  className?: string;
  children?: React.ReactNode;
  disabled?: boolean;
}

export const RewardedAdButton: React.FC<RewardedAdButtonProps> = ({
  onReward,
  onError,
  className = '',
  children,
  disabled = false
}) => {
  const { isNative, isAvailable, showRewardedAd } = useAdMob();
  const [isLoading, setIsLoading] = useState(false);

  const handleClick = async () => {
    if (!isAvailable || disabled) {
      onError?.('Ads not available');
      return;
    }

    try {
      setIsLoading(true);
      const reward = await showRewardedAd();
      
      if (reward) {
        onReward?.(reward);
      } else {
        onError?.('No reward received');
      }
    } catch (error) {
      onError?.(error instanceof Error ? error.message : 'Failed to show ad');
    } finally {
      setIsLoading(false);
    }
  };

  // Don't show the button on web platform
  if (!isNative) {
    return null;
  }

  return (
    <Button
      onClick={handleClick}
      disabled={disabled || isLoading || !isAvailable}
      className={`${className} bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white`}
    >
      {isLoading ? (
        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
      ) : (
        <Gift className="w-4 h-4 mr-2" />
      )}
      {children || 'Watch Ad for Reward'}
    </Button>
  );
};