import { useState, useEffect } from 'react';
import { notificationManager, type NotificationPermission } from '../lib/notifications';

export function useNotifications() {
  const [permission, setPermission] = useState<NotificationPermission>({
    granted: false,
    denied: false,
    default: true
  });
  const [isSupported, setIsSupported] = useState(false);

  useEffect(() => {
    // Check if notifications are supported
    setIsSupported('Notification' in window);
    
    // Get initial permission status
    setPermission(notificationManager.getPermissionStatus());
  }, []);

  const requestPermission = async () => {
    const newPermission = await notificationManager.requestPermission();
    setPermission(newPermission);
    return newPermission;
  };

  const showTestNotification = async () => {
    if (permission.granted) {
      await notificationManager.testNotification();
    } else {
      console.warn('Notification permission not granted');
    }
  };

  const scheduleTaskReminders = (task: any) => {
    if (permission.granted) {
      notificationManager.scheduleTaskReminders(task);
    }
  };

  const clearTaskNotifications = (taskId: string) => {
    notificationManager.clearTaskNotifications(taskId);
  };

  const clearAllNotifications = () => {
    notificationManager.clearAllNotifications();
  };

  return {
    permission,
    isSupported,
    requestPermission,
    showTestNotification,
    scheduleTaskReminders,
    clearTaskNotifications,
    clearAllNotifications
  };
}