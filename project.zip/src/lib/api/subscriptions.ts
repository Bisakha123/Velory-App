import { supabase } from '../supabase';

export interface SubscriptionPlan {
  id: string;
  name: string;
  display_name: string;
  price_monthly: number;
  price_yearly: number;
  features: Record<string, any>;
  limits: Record<string, any>;
  is_active: boolean;
}

export interface UserSubscription {
  id: string;
  user_id: string;
  plan_id: string;
  status: 'active' | 'cancelled' | 'expired' | 'trial';
  billing_cycle: 'monthly' | 'yearly';
  current_period_start: string;
  current_period_end: string;
  trial_end?: string;
  cancelled_at?: string;
  metadata: Record<string, any>;
}

export interface SubscriptionUsage {
  id: string;
  user_id: string;
  resource_type: string;
  usage_count: number;
  period_start: string;
  period_end: string;
}

export interface CouponCode {
  id: string;
  code: string;
  discount_type: 'percentage' | 'fixed' | 'free_access';
  discount_value: number;
  max_uses?: number;
  used_count: number;
  valid_from: string;
  valid_until?: string;
  applicable_plans: string[];
  is_active: boolean;
  metadata: {
    free_access_duration_months?: number;
    description?: string;
  };
}

export const subscriptionsApi = {
  // Get all available subscription plans
  async getPlans(): Promise<SubscriptionPlan[]> {
    try {
      const { data, error } = await supabase
        .from('subscription_plans')
        .select('*')
        .eq('is_active', true)
        .order('price_monthly', { ascending: true });
      
      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching subscription plans:', error);
      throw error;
    }
  },

  // Get user's current subscription with enhanced error handling
  async getUserSubscription(): Promise<{ subscription: UserSubscription; plan: SubscriptionPlan } | null> {
    try {
      // Check if user is authenticated first
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError) {
        console.error('Session error:', sessionError);
        throw new Error('Authentication session error');
      }
      
      if (!session?.user) {
        console.log('No authenticated user found');
        // Return free plan for unauthenticated users
        return await this.getFreePlanFallback();
      }

      const user = session.user;
      console.log('Getting subscription for user:', user.id);

      // First try to get the user's subscription using the RPC function
      try {
        const { data: rpcData, error: rpcError } = await supabase.rpc('get_user_subscription_with_limits', {
          user_uuid: user.id
        });
        
        if (!rpcError && rpcData) {
          return {
            subscription: rpcData.subscription,
            plan: rpcData.plan
          };
        }
      } catch (rpcError) {
        console.log('RPC function not available, using fallback method');
      }

      // Fallback: manually get subscription and plan data
      const { data: subscriptionData, error: subError } = await supabase
        .from('user_subscriptions')
        .select('*')
        .eq('user_id', user.id)
        .eq('status', 'active')
        .gt('current_period_end', new Date().toISOString())
        .single();

      let planId = 'free'; // Default to free plan
      if (!subError && subscriptionData) {
        planId = subscriptionData.plan_id;
      }

      // Get the plan data
      const { data: planData, error: planError } = await supabase
        .from('subscription_plans')
        .select('*')
        .eq('id', planId)
        .single();

      if (planError) {
        console.error('Error fetching plan data:', planError);
        // Return free plan as fallback
        return await this.getFreePlanFallback(user.id);
      }

      // If no subscription exists, create a default one for free plan
      const subscription = subscriptionData || {
        id: 'default',
        user_id: user.id,
        plan_id: 'free',
        status: 'active' as const,
        billing_cycle: 'monthly' as const,
        current_period_start: new Date().toISOString(),
        current_period_end: new Date(Date.now() + 100 * 365 * 24 * 60 * 60 * 1000).toISOString(), // 100 years from now
        metadata: {}
      };

      return {
        subscription,
        plan: planData
      };
    } catch (error) {
      console.error('Error getting user subscription:', error);
      
      // Return free plan as fallback
      return await this.getFreePlanFallback();
    }
  },

  // Helper method to get free plan fallback
  async getFreePlanFallback(userId?: string): Promise<{ subscription: UserSubscription; plan: SubscriptionPlan }> {
    try {
      const { data: freePlan, error: freePlanError } = await supabase
        .from('subscription_plans')
        .select('*')
        .eq('id', 'free')
        .single();

      if (freePlanError) {
        // If we can't even get the free plan, return a hardcoded fallback
        const defaultFreePlan: SubscriptionPlan = {
          id: 'free',
          name: 'free',
          display_name: 'Free Plan',
          price_monthly: 0,
          price_yearly: 0,
          features: {},
          limits: {
            daily_tasks: 3,
            important_tasks: 1,
            journal_entries: 5,
            thoughts_entries: 3,
            gratitude_days: 7,
            goals_entries: 2,
            autobiography_cards: 5,
            custom_trackers: 1,
            creative_writing: 3,
            media_trackers: 10
          },
          is_active: true
        };

        return {
          subscription: {
            id: 'default',
            user_id: userId || '',
            plan_id: 'free',
            status: 'active' as const,
            billing_cycle: 'monthly' as const,
            current_period_start: new Date().toISOString(),
            current_period_end: new Date(Date.now() + 100 * 365 * 24 * 60 * 60 * 1000).toISOString(),
            metadata: {}
          },
          plan: defaultFreePlan
        };
      }

      return {
        subscription: {
          id: 'default',
          user_id: userId || '',
          plan_id: 'free',
          status: 'active' as const,
          billing_cycle: 'monthly' as const,
          current_period_start: new Date().toISOString(),
          current_period_end: new Date(Date.now() + 100 * 365 * 24 * 60 * 60 * 1000).toISOString(),
          metadata: {}
        },
        plan: freePlan
      };
    } catch (error) {
      console.error('Error getting free plan fallback:', error);
      throw error;
    }
  },

  // Check if user can perform an action by counting actual entries
  async checkLimit(resourceType: string): Promise<boolean> {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        return false;
      }

      const user = session.user;

      // Get subscription data to check limits
      const subscriptionData = await this.getUserSubscription();
      if (!subscriptionData) {
        return false;
      }

      const limit = subscriptionData.plan.limits[resourceType];
      
      // If limit is -1, it's unlimited
      if (limit === -1) {
        return true;
      }

      // If limit is 0, not allowed
      if (limit === 0) {
        return false;
      }

      // Count actual entries from the database based on resource type
      let currentCount = 0;

      switch (resourceType) {
        case 'daily_tasks':
          const { data: dailyTasks, error: dailyTasksError } = await supabase
            .from('tasks')
            .select('id')
            .eq('user_id', user.id)
            .eq('completed', false)
            .eq('important', false);
          
          if (!dailyTasksError) {
            currentCount = dailyTasks?.length || 0;
          }
          break;

        case 'important_tasks':
          const { data: importantTasks, error: importantTasksError } = await supabase
            .from('tasks')
            .select('id')
            .eq('user_id', user.id)
            .eq('completed', false)
            .eq('important', true);
          
          if (!importantTasksError) {
            currentCount = importantTasks?.length || 0;
          }
          break;

        case 'journal_entries':
          const { data: journalEntries, error: journalError } = await supabase
            .from('writeups')
            .select('id')
            .eq('user_id', user.id)
            .eq('type', 'journal');
          
          if (!journalError) {
            currentCount = journalEntries?.length || 0;
          }
          break;

        case 'thoughts_entries':
          const { data: thoughtsEntries, error: thoughtsError } = await supabase
            .from('writeups')
            .select('id')
            .eq('user_id', user.id)
            .eq('type', 'thoughts');
          
          if (!thoughtsError) {
            currentCount = thoughtsEntries?.length || 0;
          }
          break;

        case 'gratitude_days':
          const { data: gratitudeEntries, error: gratitudeError } = await supabase
            .from('writeups')
            .select('id')
            .eq('user_id', user.id)
            .eq('type', 'gratitude');
          
          if (!gratitudeError) {
            currentCount = gratitudeEntries?.length || 0;
          }
          break;

        case 'goals_entries':
          const { data: goalsEntries, error: goalsError } = await supabase
            .from('writeups')
            .select('id')
            .eq('user_id', user.id)
            .eq('type', 'goals');
          
          if (!goalsError) {
            currentCount = goalsEntries?.length || 0;
          }
          break;

        case 'autobiography_cards':
          const { data: autobiographyEntries, error: autobiographyError } = await supabase
            .from('writeups')
            .select('id')
            .eq('user_id', user.id)
            .eq('type', 'autobiography')
            .neq('title', '__USER_INFO__'); // Exclude user info entry
          
          if (!autobiographyError) {
            currentCount = autobiographyEntries?.length || 0;
          }
          break;

        case 'custom_trackers':
          const { data: customTrackers, error: trackersError } = await supabase
            .from('trackers')
            .select('id')
            .eq('user_id', user.id);
          
          if (!trackersError) {
            currentCount = customTrackers?.length || 0;
          }
          break;

        case 'creative_writing':
          // For creative writing, we check localStorage since it's stored locally
          const savedWritings = localStorage.getItem('creativeWritings');
          if (savedWritings) {
            const writings = JSON.parse(savedWritings);
            currentCount = writings.length || 0;
          }
          break;

        case 'media_trackers':
          // For media trackers, count actual media items
          const { data: mediaItems, error: mediaError } = await supabase
            .from('media_items')
            .select('id')
            .eq('user_id', user.id);
          
          if (!mediaError) {
            currentCount = mediaItems?.length || 0;
          }
          break;

        default:
          // For other resource types, fall back to usage tracking
          const { data: usageData, error: usageError } = await supabase
            .from('subscription_usage')
            .select('usage_count')
            .eq('user_id', user.id)
            .eq('resource_type', resourceType)
            .gte('period_start', new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString())
            .single();

          currentCount = usageError ? 0 : (usageData?.usage_count || 0);
          break;
      }
      
      return currentCount < limit;
    } catch (error) {
      console.error('Error checking limit:', error);
      return false; // Fail safe - don't allow if there's an error
    }
  },

  // Increment usage for a resource
  async incrementUsage(resourceType: string, incrementBy: number = 1): Promise<void> {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        return;
      }

      const user = session.user;

      // Try using the RPC function first
      try {
        const { error } = await supabase.rpc('increment_usage', {
          user_uuid: user.id,
          resource_type: resourceType,
          increment_by: incrementBy
        });
        
        if (!error) {
          return;
        }
      } catch (rpcError) {
        console.log('RPC function not available, using fallback method');
      }

      // Fallback: manual increment
      const periodStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
      const periodEnd = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0);

      const { error: upsertError } = await supabase
        .from('subscription_usage')
        .upsert({
          user_id: user.id,
          resource_type: resourceType,
          usage_count: incrementBy,
          period_start: periodStart.toISOString(),
          period_end: periodEnd.toISOString()
        }, {
          onConflict: 'user_id,resource_type,period_start',
          ignoreDuplicates: false
        });

      if (upsertError) {
        console.error('Error incrementing usage:', upsertError);
      }
    } catch (error) {
      console.error('Error incrementing usage:', error);
      // Don't throw error to prevent blocking user actions
    }
  },

  // Get current usage for all resources
  async getUsage(): Promise<SubscriptionUsage[]> {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        return [];
      }

      const user = session.user;

      const { data, error } = await supabase
        .from('subscription_usage')
        .select('*')
        .eq('user_id', user.id)
        .gte('period_start', new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString());
      
      if (error) {
        console.error('Error getting usage:', error);
        return [];
      }
      
      return data || [];
    } catch (error) {
      console.error('Error getting usage:', error);
      return [];
    }
  },

  // Get current count for a specific resource type
  async getCurrentCount(resourceType: string): Promise<number> {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        return 0;
      }

      const user = session.user;

      switch (resourceType) {
        case 'daily_tasks':
          const { data: dailyTasks, error: dailyTasksError } = await supabase
            .from('tasks')
            .select('id')
            .eq('user_id', user.id)
            .eq('completed', false)
            .eq('important', false);
          
          return dailyTasksError ? 0 : (dailyTasks?.length || 0);

        case 'important_tasks':
          const { data: importantTasks, error: importantTasksError } = await supabase
            .from('tasks')
            .select('id')
            .eq('user_id', user.id)
            .eq('completed', false)
            .eq('important', true);
          
          return importantTasksError ? 0 : (importantTasks?.length || 0);

        case 'journal_entries':
          const { data: journalEntries, error: journalError } = await supabase
            .from('writeups')
            .select('id')
            .eq('user_id', user.id)
            .eq('type', 'journal');
          
          return journalError ? 0 : (journalEntries?.length || 0);

        case 'thoughts_entries':
          const { data: thoughtsEntries, error: thoughtsError } = await supabase
            .from('writeups')
            .select('id')
            .eq('user_id', user.id)
            .eq('type', 'thoughts');
          
          return thoughtsError ? 0 : (thoughtsEntries?.length || 0);

        case 'gratitude_days':
          const { data: gratitudeEntries, error: gratitudeError } = await supabase
            .from('writeups')
            .select('id')
            .eq('user_id', user.id)
            .eq('type', 'gratitude');
          
          return gratitudeError ? 0 : (gratitudeEntries?.length || 0);

        case 'goals_entries':
          const { data: goalsEntries, error: goalsError } = await supabase
            .from('writeups')
            .select('id')
            .eq('user_id', user.id)
            .eq('type', 'goals');
          
          return goalsError ? 0 : (goalsEntries?.length || 0);

        case 'autobiography_cards':
          const { data: autobiographyEntries, error: autobiographyError } = await supabase
            .from('writeups')
            .select('id')
            .eq('user_id', user.id)
            .eq('type', 'autobiography')
            .neq('title', '__USER_INFO__');
          
          return autobiographyError ? 0 : (autobiographyEntries?.length || 0);

        case 'custom_trackers':
          const { data: customTrackers, error: trackersError } = await supabase
            .from('trackers')
            .select('id')
            .eq('user_id', user.id);
          
          return trackersError ? 0 : (customTrackers?.length || 0);

        case 'creative_writing':
          // For creative writing, check localStorage
          const savedWritings = localStorage.getItem('creativeWritings');
          if (savedWritings) {
            const writings = JSON.parse(savedWritings);
            return writings.length || 0;
          }
          return 0;

        case 'media_trackers':
          // For media trackers, count actual media items
          const { data: mediaItems, error: mediaError } = await supabase
            .from('media_items')
            .select('id')
            .eq('user_id', user.id);
          
          return mediaError ? 0 : (mediaItems?.length || 0);

        default:
          return 0;
      }
    } catch (error) {
      console.error('Error getting current count:', error);
      return 0;
    }
  },

  // Validate coupon code - FIXED VERSION
  async validateCoupon(code: string, planId: string): Promise<CouponCode | null> {
    try {
      console.log('Validating coupon:', { code, planId });
      
      const { data, error } = await supabase
        .from('coupon_codes')
        .select('*')
        .eq('code', code.toUpperCase())
        .eq('is_active', true)
        .single();
      
      if (error) {
        console.log('Coupon query error:', error);
        if (error.code === 'PGRST116') {
          console.log('Coupon not found');
          return null; // Not found
        }
        throw error;
      }

      console.log('Coupon found:', data);

      // Ensure metadata exists
      const couponData = {
        ...data,
        metadata: data.metadata || {}
      };

      // Check if coupon is valid for this plan (if applicable_plans is not empty)
      if (couponData.applicable_plans && couponData.applicable_plans.length > 0) {
        if (!couponData.applicable_plans.includes(planId)) {
          console.log('Coupon not applicable for plan:', planId);
          return null;
        }
      }

      // Check if coupon is still valid (expiry date)
      if (couponData.valid_until) {
        const expiryDate = new Date(couponData.valid_until);
        const now = new Date();
        if (expiryDate < now) {
          console.log('Coupon expired:', expiryDate, 'vs', now);
          return null;
        }
      }

      // Check if max uses exceeded
      if (couponData.max_uses && couponData.used_count >= couponData.max_uses) {
        console.log('Coupon max uses exceeded:', couponData.used_count, '>=', couponData.max_uses);
        return null;
      }

      console.log('Coupon validation successful');
      return couponData;
    } catch (error) {
      console.error('Error validating coupon:', error);
      return null;
    }
  },

  // Apply coupon to subscription
  async applyCoupon(couponId: string, subscriptionId: string): Promise<void> {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.user) {
      throw new Error('User not authenticated');
    }

    const user = session.user;

    const { error } = await supabase
      .from('coupon_usage')
      .insert({
        coupon_id: couponId,
        user_id: user.id,
        subscription_id: subscriptionId
      });
    
    if (error) throw error;

    // Increment coupon usage count
    const { error: incrementError } = await supabase
      .from('coupon_codes')
      .update({ used_count: supabase.sql`used_count + 1` })
      .eq('id', couponId);
    
    if (incrementError) {
      console.error('Error incrementing coupon usage:', incrementError);
    }
  },

  // Apply free access coupon - IMPROVED VERSION
  async applyFreeAccessCoupon(couponCode: string, planId: string): Promise<void> {
    try {
      console.log('Applying free access coupon:', { couponCode, planId });
      
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        throw new Error('User not authenticated');
      }

      const user = session.user;

      // Validate the coupon
      const coupon = await this.validateCoupon(couponCode, planId);
      if (!coupon) {
        throw new Error('Invalid or expired coupon code');
      }

      if (coupon.discount_type !== 'free_access') {
        throw new Error('This coupon is not a free access coupon');
      }

      console.log('Coupon validated, applying free access');

      // Calculate the end date based on the coupon's duration
      const durationMonths = coupon.metadata?.free_access_duration_months || 1;
      const endDate = new Date();
      endDate.setMonth(endDate.getMonth() + durationMonths);

      // First, check if user already has a subscription
      const { data: existingSubscription } = await supabase
        .from('user_subscriptions')
        .select('id')
        .eq('user_id', user.id)
        .single();

      let subscriptionResult;

      if (existingSubscription) {
        // Update existing subscription
        subscriptionResult = await supabase
          .from('user_subscriptions')
          .update({
            plan_id: planId,
            billing_cycle: 'monthly',
            status: 'active',
            current_period_start: new Date().toISOString(),
            current_period_end: endDate.toISOString(),
            metadata: {
              coupon_applied: couponCode,
              free_access: true,
              original_plan: 'free'
            }
          })
          .eq('user_id', user.id)
          .select()
          .single();
      } else {
        // Create new subscription
        subscriptionResult = await supabase
          .from('user_subscriptions')
          .insert({
            user_id: user.id,
            plan_id: planId,
            billing_cycle: 'monthly',
            status: 'active',
            current_period_start: new Date().toISOString(),
            current_period_end: endDate.toISOString(),
            metadata: {
              coupon_applied: couponCode,
              free_access: true,
              original_plan: 'free'
            }
          })
          .select()
          .single();
      }
      
      if (subscriptionResult.error) {
        console.error('Error updating subscription:', subscriptionResult.error);
        throw subscriptionResult.error;
      }

      console.log('Subscription updated successfully');

      // Record coupon usage
      await this.applyCoupon(coupon.id, subscriptionResult.data.id);
      
      console.log('Coupon usage recorded');
    } catch (error) {
      console.error('Error applying free access coupon:', error);
      throw error;
    }
  },

  // Update user subscription - IMPROVED VERSION
  async updateSubscription(planId: string, billingCycle: 'monthly' | 'yearly'): Promise<void> {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        throw new Error('User not authenticated');
      }

      const user = session.user;
      console.log('Updating subscription for user:', user.id, 'to plan:', planId);

      const periodEnd = billingCycle === 'yearly' 
        ? new Date(Date.now() + 365 * 24 * 60 * 60 * 1000)
        : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

      // First, check if user already has a subscription
      const { data: existingSubscription } = await supabase
        .from('user_subscriptions')
        .select('id')
        .eq('user_id', user.id)
        .single();

      let result;

      if (existingSubscription) {
        // Update existing subscription
        result = await supabase
          .from('user_subscriptions')
          .update({
            plan_id: planId,
            billing_cycle: billingCycle,
            status: 'active',
            current_period_start: new Date().toISOString(),
            current_period_end: periodEnd.toISOString(),
            metadata: {}
          })
          .eq('user_id', user.id);
      } else {
        // Create new subscription
        result = await supabase
          .from('user_subscriptions')
          .insert({
            user_id: user.id,
            plan_id: planId,
            billing_cycle: billingCycle,
            status: 'active',
            current_period_start: new Date().toISOString(),
            current_period_end: periodEnd.toISOString(),
            metadata: {}
          });
      }
      
      if (result.error) {
        console.error('Subscription update error:', result.error);
        throw result.error;
      }

      console.log('Subscription updated successfully');
    } catch (error) {
      console.error('Error in updateSubscription:', error);
      throw error;
    }
  }
};