import { supabase, type Task } from '../supabase';

export const tasksApi = {
  // Get all tasks for current user
  async getTasks() {
    const { data, error } = await supabase
      .from('tasks')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data as Task[];
  },

  // Get critical tasks (important or due soon)
  async getCriticalTasks() {
    const now = new Date();
    const eightHoursLater = new Date(now.getTime() + 8 * 60 * 60 * 1000);
    
    const { data, error } = await supabase
      .from('tasks')
      .select('*')
      .eq('completed', false)
      .or(`important.eq.true,deadline.lte.${eightHoursLater.toISOString()}`)
      .order('important', { ascending: false })
      .order('deadline', { ascending: true })
      .limit(3);
    
    if (error) throw error;
    return data as Task[];
  },

  // Create new task
  async createTask(task: Omit<Task, 'id' | 'created_at' | 'updated_at' | 'completed_at'>) {
    const { data, error } = await supabase
      .from('tasks')
      .insert([task])
      .select()
      .single();
    
    if (error) throw error;
    return data as Task;
  },

  // Update task
  async updateTask(id: string, updates: Partial<Task>) {
    const { data, error } = await supabase
      .from('tasks')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data as Task;
  },

  // Delete task
  async deleteTask(id: string) {
    const { error } = await supabase
      .from('tasks')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  },

  // Mark task as completed
  async completeTask(id: string) {
    return this.updateTask(id, { completed: true });
  },

  // Get task completion statistics
  async getTaskStats(days: number = 30) {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    const { data, error } = await supabase
      .from('tasks')
      .select('completed, completed_at, created_at, important')
      .gte('created_at', startDate.toISOString());
    
    if (error) throw error;
    return data;
  }
};