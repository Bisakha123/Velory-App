import { supabase, type Writeup } from '../supabase';

export const writeupsApi = {
  // Get writeups by type
  async getWriteups(type?: Writeup['type']) {
    let query = supabase
      .from('writeups')
      .select('*')
      .order('updated_at', { ascending: false });
    
    if (type) {
      query = query.eq('type', type);
    }
    
    const { data, error } = await query;
    
    if (error) throw error;
    return data as Writeup[];
  },

  // Get writeup by ID
  async getWriteup(id: string) {
    const { data, error } = await supabase
      .from('writeups')
      .select('*')
      .eq('id', id)
      .single();
    
    if (error) throw error;
    return data as Writeup;
  },

  // Create writeup
  async createWriteup(writeup: Omit<Writeup, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('writeups')
      .insert([writeup])
      .select()
      .single();
    
    if (error) throw error;
    return data as Writeup;
  },

  // Update writeup
  async updateWriteup(id: string, updates: Partial<Writeup>) {
    const { data, error } = await supabase
      .from('writeups')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data as Writeup;
  },

  // Delete writeup
  async deleteWriteup(id: string) {
    const { error } = await supabase
      .from('writeups')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  },

  // Search writeups
  async searchWriteups(query: string, type?: Writeup['type']) {
    let supabaseQuery = supabase
      .from('writeups')
      .select('*')
      .or(`title.ilike.%${query}%,content.ilike.%${query}%`)
      .order('updated_at', { ascending: false });
    
    if (type) {
      supabaseQuery = supabaseQuery.eq('type', type);
    }
    
    const { data, error } = await supabaseQuery;
    
    if (error) throw error;
    return data as Writeup[];
  },

  // Get writeups by tags
  async getWriteupsByTags(tags: string[], type?: Writeup['type']) {
    let query = supabase
      .from('writeups')
      .select('*')
      .overlaps('tags', tags)
      .order('updated_at', { ascending: false });
    
    if (type) {
      query = query.eq('type', type);
    }
    
    const { data, error } = await query;
    
    if (error) throw error;
    return data as Writeup[];
  }
};