import { supabase, type Tracker, type MediaItem } from '../supabase';

export const mediaApi = {
  // Trackers
  async getTrackers() {
    const { data, error } = await supabase
      .from('trackers')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (error) throw error;
    return data as Tracker[];
  },

  async createTracker(tracker: Omit<Tracker, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('trackers')
      .insert([tracker])
      .select()
      .single();
    
    if (error) throw error;
    return data as Tracker;
  },

  async updateTracker(id: string, updates: Partial<Tracker>) {
    const { data, error } = await supabase
      .from('trackers')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data as Tracker;
  },

  async deleteTracker(id: string) {
    const { error } = await supabase
      .from('trackers')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  },

  // Media Items
  async getMediaItems(type?: MediaItem['type'], status?: MediaItem['status'], trackerId?: string | null) {
    let query = supabase
      .from('media_items')
      .select('*')
      .order('updated_at', { ascending: false });
    
    if (type) {
      query = query.eq('type', type);
    }
    
    if (status) {
      query = query.eq('status', status);
    }
    
    // Handle tracker filtering
    if (trackerId !== undefined) {
      if (trackerId === null) {
        // Filter for built-in trackers (tracker_id is NULL)
        query = query.is('tracker_id', null);
      } else {
        // Filter for specific custom tracker UUID
        query = query.eq('tracker_id', trackerId);
      }
    }
    
    const { data, error } = await query;
    
    if (error) throw error;
    return data as MediaItem[];
  },

  async createMediaItem(item: Omit<MediaItem, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('media_items')
      .insert([item])
      .select()
      .single();
    
    if (error) throw error;
    return data as MediaItem;
  },

  async updateMediaItem(id: string, updates: Partial<MediaItem>) {
    const { data, error } = await supabase
      .from('media_items')
      .update(updates)
      .eq('id', id)
      .select()
      .single();
    
    if (error) throw error;
    return data as MediaItem;
  },

  async deleteMediaItem(id: string) {
    const { error } = await supabase
      .from('media_items')
      .delete()
      .eq('id', id);
    
    if (error) throw error;
  },

  // Update progress
  async updateProgress(id: string, watchedEpisodes: number) {
    return this.updateMediaItem(id, { watched_episodes: watchedEpisodes });
  },

  // Search media items
  async searchMediaItems(query: string, type?: MediaItem['type']) {
    let supabaseQuery = supabase
      .from('media_items')
      .select('*')
      .or(`title.ilike.%${query}%,description.ilike.%${query}%`)
      .order('updated_at', { ascending: false });
    
    if (type) {
      supabaseQuery = supabaseQuery.eq('type', type);
    }
    
    const { data, error } = await supabaseQuery;
    
    if (error) throw error;
    return data as MediaItem[];
  }
};