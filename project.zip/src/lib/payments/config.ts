import type { PaymentConfig } from './types';

// Payment configuration - these should be environment variables in production
export const paymentConfig: PaymentConfig = {
  environment: import.meta.env.VITE_PAYMENT_ENV === 'production' ? 'production' : 'sandbox',
  providers: {
    razorpay: {
      keyId: import.meta.env.VITE_RAZORPAY_KEY_ID || 'rzp_test_1DP5mmOlF5G5ag',
      keySecret: import.meta.env.VITE_RAZORPAY_KEY_SECRET || 'your_key_secret'
    }
  }
};

// Plan pricing in INR - Updated to ₹99/₹199
export const planPricing = {
  plus: {
    monthly: 99,
    yearly: 999  // 10 months price for yearly (17% discount)
  },
  pro: {
    monthly: 199,
    yearly: 1999  // 10 months price for yearly (17% discount)
  }
};