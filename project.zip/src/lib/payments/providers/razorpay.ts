import type { PaymentProvider, PaymentMethod, PaymentIntent, PaymentResult, CustomerInfo } from '../types';

declare global {
  interface Window {
    Razorpay: any;
  }
}

export class RazorpayProvider {
  private keyId: string;
  private keySecret: string;
  private environment: 'sandbox' | 'production';

  constructor(config: { keyId: string; keySecret: string; environment: 'sandbox' | 'production' }) {
    this.keyId = config.keyId;
    this.keySecret = config.keySecret;
    this.environment = config.environment;
  }

  static getProviderInfo(): PaymentProvider {
    return {
      id: 'razorpay',
      name: 'razorpay',
      displayName: 'Razorpay',
      logo: 'https://razorpay.com/assets/razorpay-logo.svg',
      supportedCountries: ['IN'],
      supportedCurrencies: ['INR'],
      isActive: true,
      config: {}
    };
  }

  static getPaymentMethods(): PaymentMethod[] {
    return [
      // Cards
      {
        id: 'razorpay_card',
        providerId: 'razorpay',
        type: 'card',
        name: 'Credit/Debit Cards',
        icon: '💳',
        isPopular: true
      },
      
      // Popular UPI Apps in India
      {
        id: 'google_pay_upi',
        providerId: 'razorpay',
        type: 'upi',
        name: 'Google Pay',
        icon: '🔵',
        isPopular: true
      },
      {
        id: 'phonepe_upi',
        providerId: 'razorpay',
        type: 'upi',
        name: 'PhonePe',
        icon: '💜',
        isPopular: true
      },
      {
        id: 'paytm_upi',
        providerId: 'razorpay',
        type: 'upi',
        name: 'Paytm',
        icon: '🔷',
        isPopular: true
      },
      {
        id: 'amazon_pay_upi',
        providerId: 'razorpay',
        type: 'upi',
        name: 'Amazon Pay',
        icon: '🟠'
      },
      {
        id: 'bhim_upi',
        providerId: 'razorpay',
        type: 'upi',
        name: 'BHIM UPI',
        icon: '🇮🇳'
      },
      {
        id: 'custom_upi',
        providerId: 'razorpay',
        type: 'upi',
        name: 'Other UPI Apps',
        icon: '📱'
      }
    ];
  }

  async loadScript(): Promise<boolean> {
    return new Promise((resolve) => {
      if (window.Razorpay) {
        resolve(true);
        return;
      }

      const script = document.createElement('script');
      script.src = 'https://checkout.razorpay.com/v1/checkout.js';
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.head.appendChild(script);
    });
  }

  async createPaymentIntent(
    amount: number,
    currency: string,
    planId: string,
    billingCycle: 'monthly' | 'yearly',
    customer: CustomerInfo
  ): Promise<PaymentIntent> {
    try {
      console.log('🔄 Creating Razorpay order via backend...');
      
      // Get auth token
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      if (!supabaseUrl) {
        throw new Error('Supabase URL not configured');
      }

      // Get user session for auth
      const { createClient } = await import('@supabase/supabase-js');
      const supabase = createClient(supabaseUrl, supabaseAnonKey);
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        throw new Error('User not authenticated');
      }

      // Call backend function to create order
      const response = await fetch(`${supabaseUrl}/functions/v1/create-order`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          amount,
          currency,
          planId,
          billingCycle,
          customerInfo: customer
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to create order');
      }

      const orderData = await response.json();
      
      if (!orderData.success) {
        throw new Error(orderData.error || 'Failed to create order');
      }

      console.log('✅ Razorpay order created:', orderData.order_id);
      
      return {
        id: orderData.order_id,
        amount,
        currency,
        planId,
        billingCycle,
        customerId: customer.email,
        metadata: { 
          orderId: orderData.order_id,
          keyId: orderData.key_id,
          planId,
          billingCycle,
          customerEmail: customer.email,
          environment: this.environment
        }
      };
    } catch (error) {
      console.error('❌ Error creating payment intent:', error);
      throw new Error(`Failed to create payment intent: ${error.message}`);
    }
  }

  async processPayment(
    paymentIntent: PaymentIntent,
    customer: CustomerInfo,
    paymentMethodId?: string
  ): Promise<PaymentResult> {
    console.log('🚀 Processing payment with Razorpay...');
    
    const scriptLoaded = await this.loadScript();
    if (!scriptLoaded) {
      return {
        success: false,
        error: 'Failed to load Razorpay SDK. Please check your internet connection and try again.'
      };
    }

    return new Promise((resolve) => {
      try {
        const options = {
          key: paymentIntent.metadata?.keyId || this.keyId,
          amount: Math.round(paymentIntent.amount * 100), // Convert to paise
          currency: paymentIntent.currency,
          name: 'Velory',
          description: `Velory ${paymentIntent.planId.charAt(0).toUpperCase() + paymentIntent.planId.slice(1)} - ${paymentIntent.billingCycle} subscription`,
          order_id: paymentIntent.metadata?.orderId,
          prefill: {
            name: customer.name,
            email: customer.email,
            contact: customer.phone || ''
          },
          theme: {
            color: '#8B4769'
          },
          method: this.getMethodPreference(paymentMethodId),
          handler: async (response: any) => {
            console.log('✅ Payment successful, verifying...', response);
            
            try {
              // Verify payment with backend
              const verificationResult = await this.verifyPayment(
                response.razorpay_order_id,
                response.razorpay_payment_id,
                response.razorpay_signature,
                paymentIntent.planId,
                paymentIntent.billingCycle
              );

              if (verificationResult.success) {
                resolve({
                  success: true,
                  paymentId: response.razorpay_payment_id,
                  transactionId: response.razorpay_order_id
                });
              } else {
                resolve({
                  success: false,
                  error: verificationResult.error || 'Payment verification failed'
                });
              }
            } catch (error) {
              console.error('❌ Payment verification error:', error);
              resolve({
                success: false,
                error: 'Payment verification failed. Please contact support.'
              });
            }
          },
          modal: {
            ondismiss: () => {
              console.log('❌ Payment cancelled by user');
              resolve({
                success: false,
                error: 'Payment was cancelled. Please try again when you\'re ready to complete your subscription.'
              });
            },
            confirm_close: true,
            escape: true,
            backdropclose: false
          },
          retry: {
            enabled: true,
            max_count: 3
          },
          timeout: 300, // 5 minutes
          remember_customer: false,
          readonly: {
            email: true,
            name: true,
            contact: true
          }
        };

        console.log('🔓 Opening Razorpay checkout...');

        const rzp = new window.Razorpay(options);
        
        // Handle payment failures
        rzp.on('payment.failed', (response: any) => {
          console.error('❌ Payment failed:', response.error);
          
          let errorMessage = 'Payment failed. Please try again.';
          
          if (response.error) {
            switch (response.error.code) {
              case 'BAD_REQUEST_ERROR':
                errorMessage = 'Invalid payment details. Please check and try again.';
                break;
              case 'GATEWAY_ERROR':
                errorMessage = 'Payment gateway error. Please try a different payment method.';
                break;
              case 'NETWORK_ERROR':
                errorMessage = 'Network error. Please check your connection and try again.';
                break;
              case 'SERVER_ERROR':
                errorMessage = 'Server error. Please try again in a few moments.';
                break;
              default:
                errorMessage = response.error.description || errorMessage;
            }
          }
          
          resolve({
            success: false,
            error: errorMessage
          });
        });

        // Open the payment modal
        rzp.open();
        
      } catch (error) {
        console.error('❌ Error opening Razorpay checkout:', error);
        resolve({
          success: false,
          error: 'Failed to open payment interface. Please refresh the page and try again.'
        });
      }
    });
  }

  private async verifyPayment(
    orderId: string,
    paymentId: string,
    signature: string,
    planId: string,
    billingCycle: 'monthly' | 'yearly'
  ): Promise<{ success: boolean; error?: string }> {
    try {
      console.log('🔍 Verifying payment with backend...');
      
      // Get auth token
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      if (!supabaseUrl) {
        throw new Error('Supabase URL not configured');
      }

      // Get user session for auth
      const { createClient } = await import('@supabase/supabase-js');
      const supabase = createClient(supabaseUrl, supabaseAnonKey);
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        throw new Error('User not authenticated');
      }

      // Call backend function to verify payment
      const response = await fetch(`${supabaseUrl}/functions/v1/verify-payment`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          razorpay_order_id: orderId,
          razorpay_payment_id: paymentId,
          razorpay_signature: signature,
          planId,
          billingCycle
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Payment verification failed');
      }

      const result = await response.json();
      
      if (!result.success) {
        throw new Error(result.error || 'Payment verification failed');
      }

      console.log('✅ Payment verified successfully');
      return { success: true };
      
    } catch (error) {
      console.error('❌ Payment verification error:', error);
      return { 
        success: false, 
        error: error.message || 'Payment verification failed' 
      };
    }
  }

  private getMethodPreference(paymentMethodId?: string) {
    if (!paymentMethodId) return undefined;

    switch (paymentMethodId) {
      case 'razorpay_card':
        return { card: true };
      case 'google_pay_upi':
      case 'phonepe_upi':
      case 'paytm_upi':
      case 'amazon_pay_upi':
      case 'bhim_upi':
      case 'custom_upi':
        return { upi: true };
      default:
        return undefined;
    }
  }
}