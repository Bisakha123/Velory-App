export interface PaymentProvider {
  id: string;
  name: string;
  displayName: string;
  logo: string;
  supportedCountries: string[];
  supportedCurrencies: string[];
  isActive: boolean;
  config: Record<string, any>;
}

export interface PaymentMethod {
  id: string;
  providerId: string;
  type: 'card' | 'upi';
  name: string;
  icon: string;
  isPopular?: boolean;
  minAmount?: number;
  maxAmount?: number;
}

export interface PaymentIntent {
  id: string;
  amount: number;
  currency: string;
  planId: string;
  billingCycle: 'monthly' | 'yearly';
  customerId?: string;
  metadata?: Record<string, any>;
}

export interface PaymentResult {
  success: boolean;
  paymentId?: string;
  transactionId?: string;
  error?: string;
  redirectUrl?: string;
  requiresAction?: boolean;
  nextAction?: {
    type: 'redirect' | 'verify_otp' | 'authenticate';
    url?: string;
    data?: Record<string, any>;
  };
}

export interface CustomerInfo {
  email: string;
  name: string;
  phone?: string;
  address?: {
    line1: string;
    line2?: string;
    city: string;
    state: string;
    country: string;
    postalCode: string;
  };
}

export interface PaymentConfig {
  environment: 'sandbox' | 'production';
  providers: {
    razorpay?: {
      keyId: string;
      keySecret: string;
    };
  };
}