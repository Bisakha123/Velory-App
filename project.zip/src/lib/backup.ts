// Backup and Restore System (Local Only)
export interface BackupData {
  version: string;
  timestamp: string;
  user: {
    id: string;
    email?: string;
  };
  data: {
    profile: any;
    tasks: any[];
    moods: any[];
    writeups: any[];
    trackers: any[];
    mediaItems: any[];
    achievements: any[];
  };
  metadata: {
    totalItems: number;
    dataSize: number;
    appVersion: string;
  };
}

export interface BackupOptions {
  includeProfile?: boolean;
  includeTasks?: boolean;
  includeMoods?: boolean;
  includeWriteups?: boolean;
  includeTrackers?: boolean;
  includeAchievements?: boolean;
}

class BackupManager {
  private static instance: BackupManager;

  private constructor() {}

  static getInstance(): BackupManager {
    if (!BackupManager.instance) {
      BackupManager.instance = new BackupManager();
    }
    return BackupManager.instance;
  }

  async createBackup(
    apis: any,
    user: any,
    options: BackupOptions = {}
  ): Promise<BackupData> {
    const defaultOptions: BackupOptions = {
      includeProfile: true,
      includeTasks: true,
      includeMoods: true,
      includeWriteups: true,
      includeTrackers: true,
      includeAchievements: true,
      ...options
    };

    console.log('Creating backup with options:', defaultOptions);

    const backupData: BackupData = {
      version: '1.0.0',
      timestamp: new Date().toISOString(),
      user: {
        id: user.id,
        email: user.email
      },
      data: {
        profile: null,
        tasks: [],
        moods: [],
        writeups: [],
        trackers: [],
        mediaItems: [],
        achievements: []
      },
      metadata: {
        totalItems: 0,
        dataSize: 0,
        appVersion: '1.0.3'
      }
    };

    try {
      // Collect data based on options
      if (defaultOptions.includeProfile) {
        try {
          backupData.data.profile = await apis.profilesApi.getProfile();
        } catch (error) {
          console.warn('Failed to backup profile:', error);
        }
      }

      if (defaultOptions.includeTasks) {
        try {
          backupData.data.tasks = await apis.tasksApi.getTasks();
        } catch (error) {
          console.warn('Failed to backup tasks:', error);
        }
      }

      if (defaultOptions.includeMoods) {
        try {
          backupData.data.moods = await apis.moodsApi.getMoodEntries();
        } catch (error) {
          console.warn('Failed to backup moods:', error);
        }
      }

      if (defaultOptions.includeWriteups) {
        try {
          const writeupTypes = ['journal', 'creative', 'thoughts', 'gratitude', 'goals', 'autobiography'];
          const allWriteups = [];
          for (const type of writeupTypes) {
            const writeups = await apis.writeupsApi.getWriteups(type);
            allWriteups.push(...writeups);
          }
          backupData.data.writeups = allWriteups;
        } catch (error) {
          console.warn('Failed to backup writeups:', error);
        }
      }

      if (defaultOptions.includeTrackers) {
        try {
          backupData.data.trackers = await apis.mediaApi.getTrackers();
          backupData.data.mediaItems = await apis.mediaApi.getMediaItems();
        } catch (error) {
          console.warn('Failed to backup trackers:', error);
        }
      }

      if (defaultOptions.includeAchievements) {
        try {
          backupData.data.achievements = await apis.achievementsApi.getAchievements();
        } catch (error) {
          console.warn('Failed to backup achievements:', error);
        }
      }

      // Calculate metadata
      backupData.metadata.totalItems = 
        (backupData.data.profile ? 1 : 0) +
        backupData.data.tasks.length +
        backupData.data.moods.length +
        backupData.data.writeups.length +
        backupData.data.trackers.length +
        backupData.data.mediaItems.length +
        backupData.data.achievements.length;

      const dataString = JSON.stringify(backupData);
      backupData.metadata.dataSize = new Blob([dataString]).size;

      console.log('Backup created successfully:', {
        totalItems: backupData.metadata.totalItems,
        dataSize: `${(backupData.metadata.dataSize / 1024).toFixed(2)} KB`
      });

      return backupData;
    } catch (error) {
      console.error('Error creating backup:', error);
      throw new Error(`Failed to create backup: ${error.message}`);
    }
  }

  async saveBackupLocally(backupData: BackupData): Promise<void> {
    try {
      const fileName = `my-organizer-backup-${format(new Date(), 'yyyy-MM-dd-HH-mm-ss')}.json`;
      const fileContent = JSON.stringify(backupData, null, 2);
      const blob = new Blob([fileContent], { type: 'application/json' });
      
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      link.click();
      
      URL.revokeObjectURL(url);
      console.log('Backup saved locally:', fileName);
    } catch (error) {
      console.error('Error saving backup locally:', error);
      throw new Error(`Failed to save backup locally: ${error.message}`);
    }
  }

  async loadBackupFromFile(file: File): Promise<BackupData> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const backupData = JSON.parse(e.target?.result as string);
          
          // Validate backup structure
          if (!this.validateBackupData(backupData)) {
            reject(new Error('Invalid backup file format'));
            return;
          }
          
          resolve(backupData);
        } catch (error) {
          reject(new Error('Failed to parse backup file'));
        }
      };
      
      reader.onerror = () => reject(new Error('Failed to read backup file'));
      reader.readAsText(file);
    });
  }

  private validateBackupData(data: any): boolean {
    return (
      data &&
      typeof data === 'object' &&
      data.version &&
      data.timestamp &&
      data.user &&
      data.data &&
      typeof data.data === 'object'
    );
  }

  async restoreFromBackup(
    backupData: BackupData,
    apis: any,
    user: any,
    options: { overwrite?: boolean; selective?: string[] } = {}
  ): Promise<{ success: boolean; restored: string[]; errors: string[] }> {
    const result = {
      success: false,
      restored: [] as string[],
      errors: [] as string[]
    };

    try {
      console.log('Starting restore from backup:', {
        version: backupData.version,
        timestamp: backupData.timestamp,
        totalItems: backupData.metadata?.totalItems
      });

      // Restore profile
      if (backupData.data.profile && (!options.selective || options.selective.includes('profile'))) {
        try {
          await apis.profilesApi.updateProfile(user.id, {
            username: backupData.data.profile.username,
            bio: backupData.data.profile.bio,
            diary_name: backupData.data.profile.diary_name
          });
          result.restored.push('Profile');
        } catch (error) {
          result.errors.push(`Profile: ${error.message}`);
        }
      }

      // Restore tasks
      if (backupData.data.tasks?.length && (!options.selective || options.selective.includes('tasks'))) {
        try {
          for (const task of backupData.data.tasks) {
            const taskData = {
              title: task.title,
              description: task.description,
              deadline: task.deadline,
              repeat_days: task.repeat_days || [],
              tag: task.tag || '',
              important: task.important || false,
              completed: task.completed || false,
              user_id: user.id
            };
            await apis.tasksApi.createTask(taskData);
          }
          result.restored.push(`Tasks (${backupData.data.tasks.length})`);
        } catch (error) {
          result.errors.push(`Tasks: ${error.message}`);
        }
      }

      // Restore moods
      if (backupData.data.moods?.length && (!options.selective || options.selective.includes('moods'))) {
        try {
          for (const mood of backupData.data.moods) {
            await apis.moodsApi.setMood(mood.date, mood.mood);
          }
          result.restored.push(`Moods (${backupData.data.moods.length})`);
        } catch (error) {
          result.errors.push(`Moods: ${error.message}`);
        }
      }

      // Restore writeups
      if (backupData.data.writeups?.length && (!options.selective || options.selective.includes('writeups'))) {
        try {
          for (const writeup of backupData.data.writeups) {
            const writeupData = {
              type: writeup.type,
              title: writeup.title,
              content: writeup.content,
              tags: writeup.tags || [],
              mood: writeup.mood,
              background_image: writeup.background_image,
              metadata: writeup.metadata || {},
              user_id: user.id
            };
            await apis.writeupsApi.createWriteup(writeupData);
          }
          result.restored.push(`Writeups (${backupData.data.writeups.length})`);
        } catch (error) {
          result.errors.push(`Writeups: ${error.message}`);
        }
      }

      // Restore trackers and media items
      if (backupData.data.trackers?.length && (!options.selective || options.selective.includes('trackers'))) {
        try {
          const trackerIdMap = new Map();
          
          // First restore trackers
          for (const tracker of backupData.data.trackers) {
            const trackerData = {
              name: tracker.name,
              type: tracker.type,
              image_url: tracker.image_url,
              user_id: user.id
            };
            const newTracker = await apis.mediaApi.createTracker(trackerData);
            trackerIdMap.set(tracker.id, newTracker.id);
          }
          
          // Then restore media items
          if (backupData.data.mediaItems?.length) {
            for (const item of backupData.data.mediaItems) {
              const itemData = {
                tracker_id: item.tracker_id ? trackerIdMap.get(item.tracker_id) : null,
                title: item.title,
                description: item.description,
                type: item.type,
                genres: item.genres || [],
                status: item.status,
                total_seasons: item.total_seasons,
                total_episodes: item.total_episodes,
                watched_episodes: item.watched_episodes || 0,
                user_id: user.id
              };
              await apis.mediaApi.createMediaItem(itemData);
            }
          }
          
          result.restored.push(`Trackers (${backupData.data.trackers.length})`);
          if (backupData.data.mediaItems?.length) {
            result.restored.push(`Media Items (${backupData.data.mediaItems.length})`);
          }
        } catch (error) {
          result.errors.push(`Trackers: ${error.message}`);
        }
      }

      // Restore achievements
      if (backupData.data.achievements?.length && (!options.selective || options.selective.includes('achievements'))) {
        try {
          for (const achievement of backupData.data.achievements) {
            const achievementData = {
              title: achievement.title,
              description: achievement.description,
              icon: achievement.icon,
              user_id: user.id
            };
            await apis.achievementsApi.createAchievement(achievementData);
          }
          result.restored.push(`Achievements (${backupData.data.achievements.length})`);
        } catch (error) {
          result.errors.push(`Achievements: ${error.message}`);
        }
      }

      result.success = result.restored.length > 0;
      console.log('Restore completed:', result);
      
      return result;
    } catch (error) {
      console.error('Error during restore:', error);
      result.errors.push(`General error: ${error.message}`);
      return result;
    }
  }
}

// Helper function to format dates
function format(date: Date, formatStr: string): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');

  return formatStr
    .replace('yyyy', String(year))
    .replace('MM', month)
    .replace('dd', day)
    .replace('HH', hours)
    .replace('mm', minutes)
    .replace('ss', seconds);
}

export const backupManager = BackupManager.getInstance();