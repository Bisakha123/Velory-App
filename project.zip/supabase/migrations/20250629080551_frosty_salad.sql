/*
  # Subscription System Schema

  1. New Tables
    - `subscription_plans`
      - Plan definitions (Free, Plus, Pro)
    - `user_subscriptions`
      - User subscription status and limits
    - `subscription_usage`
      - Track usage against limits
    - `coupon_codes`
      - Discount codes for subscriptions

  2. Security
    - Enable RLS on all subscription tables
    - Add policies for subscription management

  3. Functions
    - Check subscription limits
    - Apply usage tracking
*/

-- Subscription plans table
CREATE TABLE IF NOT EXISTS subscription_plans (
  id text PRIMARY KEY,
  name text NOT NULL,
  display_name text NOT NULL,
  price_monthly decimal(10,2) NOT NULL DEFAULT 0,
  price_yearly decimal(10,2) NOT NULL DEFAULT 0,
  features jsonb NOT NULL DEFAULT '{}',
  limits jsonb NOT NULL DEFAULT '{}',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- User subscriptions table
CREATE TABLE IF NOT EXISTS user_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  plan_id text REFERENCES subscription_plans(id) NOT NULL,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cancelled', 'expired', 'trial')),
  billing_cycle text NOT NULL DEFAULT 'monthly' CHECK (billing_cycle IN ('monthly', 'yearly')),
  current_period_start timestamptz NOT NULL DEFAULT now(),
  current_period_end timestamptz NOT NULL DEFAULT (now() + interval '1 month'),
  trial_end timestamptz,
  cancelled_at timestamptz,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Subscription usage tracking
CREATE TABLE IF NOT EXISTS subscription_usage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  resource_type text NOT NULL, -- 'tasks', 'journals', 'thoughts', 'gratitude', 'goals', 'trackers', 'autobiography', 'creative'
  usage_count integer NOT NULL DEFAULT 0,
  period_start timestamptz NOT NULL DEFAULT date_trunc('month', now()),
  period_end timestamptz NOT NULL DEFAULT (date_trunc('month', now()) + interval '1 month'),
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, resource_type, period_start)
);

-- Coupon codes table
CREATE TABLE IF NOT EXISTS coupon_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE NOT NULL,
  discount_type text NOT NULL CHECK (discount_type IN ('percentage', 'fixed')),
  discount_value decimal(10,2) NOT NULL,
  max_uses integer,
  used_count integer DEFAULT 0,
  valid_from timestamptz DEFAULT now(),
  valid_until timestamptz,
  applicable_plans text[] DEFAULT '{}',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Coupon usage tracking
CREATE TABLE IF NOT EXISTS coupon_usage (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  coupon_id uuid REFERENCES coupon_codes(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  subscription_id uuid REFERENCES user_subscriptions(id) ON DELETE CASCADE,
  used_at timestamptz DEFAULT now(),
  UNIQUE(coupon_id, user_id)
);

-- Enable RLS
ALTER TABLE subscription_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscription_usage ENABLE ROW LEVEL SECURITY;
ALTER TABLE coupon_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE coupon_usage ENABLE ROW LEVEL SECURITY;

-- Subscription plans policies (public read)
CREATE POLICY "Anyone can read active subscription plans"
  ON subscription_plans
  FOR SELECT
  TO public
  USING (is_active = true);

-- User subscriptions policies
CREATE POLICY "Users can read own subscription"
  ON user_subscriptions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own subscription"
  ON user_subscriptions
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Subscription usage policies
CREATE POLICY "Users can read own usage"
  ON subscription_usage
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own usage"
  ON subscription_usage
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own usage"
  ON subscription_usage
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Coupon codes policies (public read for validation)
CREATE POLICY "Anyone can read active coupons"
  ON coupon_codes
  FOR SELECT
  TO public
  USING (is_active = true AND (valid_until IS NULL OR valid_until > now()));

-- Coupon usage policies
CREATE POLICY "Users can read own coupon usage"
  ON coupon_usage
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own coupon usage"
  ON coupon_usage
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Insert default subscription plans
INSERT INTO subscription_plans (id, name, display_name, price_monthly, price_yearly, features, limits) VALUES
('free', 'free', 'Velory Free', 0.00, 0.00, 
 '{"basic_features": true, "read_only_offline": true}',
 '{
   "daily_tasks": 10,
   "important_tasks": 5,
   "journal_entries": 10,
   "journal_words_per_entry": 300,
   "thoughts_entries": 5,
   "thoughts_total_words": 150,
   "gratitude_days": 10,
   "gratitude_words_per_day": 100,
   "goals_entries": 2,
   "media_trackers": 0,
   "custom_trackers": false,
   "autobiography_cards": 0,
   "creative_writing": 0,
   "profile_avatar": false,
   "background_images": false,
   "analytics": false,
   "backups": false,
   "offline_writing": false,
   "motivational_popups": false,
   "mood_history_months": 1
 }'
),
('plus', 'plus', 'Velory Plus', 4.99, 49.99,
 '{"media_trackers": true, "light_analytics": true, "profile_avatar": true}',
 '{
   "daily_tasks": 30,
   "important_tasks": 20,
   "journal_entries": 25,
   "journal_words_per_entry": 1000,
   "thoughts_entries": 20,
   "thoughts_total_words": 500,
   "gratitude_days": 20,
   "gratitude_words_per_day": 300,
   "goals_entries": 10,
   "media_trackers": 8,
   "custom_trackers": false,
   "autobiography_cards": 10,
   "autobiography_items_per_card": 3,
   "autobiography_words_per_card": 100,
   "creative_writing": 1,
   "creative_background_images": 1,
   "profile_avatar": true,
   "analytics": true,
   "backups": false,
   "offline_writing": false,
   "motivational_popups": false,
   "mood_history_months": 12
 }'
),
('pro', 'pro', 'Velory Pro', 9.99, 99.99,
 '{"unlimited_access": true, "full_analytics": true, "offline_writing": true, "backups": true, "motivational_popups": true}',
 '{
   "daily_tasks": -1,
   "important_tasks": -1,
   "journal_entries": -1,
   "journal_words_per_entry": -1,
   "thoughts_entries": -1,
   "thoughts_total_words": -1,
   "gratitude_days": -1,
   "gratitude_words_per_day": -1,
   "goals_entries": -1,
   "media_trackers": -1,
   "custom_trackers": true,
   "autobiography_cards": -1,
   "autobiography_items_per_card": -1,
   "autobiography_words_per_card": -1,
   "creative_writing": -1,
   "creative_background_images": -1,
   "profile_avatar": true,
   "analytics": true,
   "backups": true,
   "offline_writing": true,
   "motivational_popups": true,
   "mood_history_months": -1
 }'
);

-- Insert sample coupon codes
INSERT INTO coupon_codes (code, discount_type, discount_value, max_uses, valid_until, applicable_plans) VALUES
('WELCOME20', 'percentage', 20.00, 1000, now() + interval '3 months', ARRAY['plus', 'pro']),
('STUDENT50', 'percentage', 50.00, 500, now() + interval '1 year', ARRAY['plus', 'pro']),
('NEWUSER', 'fixed', 5.00, 2000, now() + interval '6 months', ARRAY['plus', 'pro']);

-- Function to get user subscription with limits
CREATE OR REPLACE FUNCTION get_user_subscription_with_limits(user_uuid uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  subscription_data jsonb;
  plan_data jsonb;
BEGIN
  -- Get user subscription and plan data
  SELECT jsonb_build_object(
    'subscription', to_jsonb(us.*),
    'plan', to_jsonb(sp.*)
  ) INTO subscription_data
  FROM user_subscriptions us
  JOIN subscription_plans sp ON us.plan_id = sp.id
  WHERE us.user_id = user_uuid
  AND us.status = 'active'
  AND us.current_period_end > now();
  
  -- If no active subscription, return free plan
  IF subscription_data IS NULL THEN
    SELECT jsonb_build_object(
      'subscription', jsonb_build_object(
        'user_id', user_uuid,
        'plan_id', 'free',
        'status', 'active'
      ),
      'plan', to_jsonb(sp.*)
    ) INTO subscription_data
    FROM subscription_plans sp
    WHERE sp.id = 'free';
  END IF;
  
  RETURN subscription_data;
END;
$$;

-- Function to check if user can perform action
CREATE OR REPLACE FUNCTION check_subscription_limit(
  user_uuid uuid,
  resource_type text,
  action_type text DEFAULT 'create'
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  subscription_data jsonb;
  plan_limits jsonb;
  current_usage integer;
  limit_value integer;
BEGIN
  -- Get subscription data
  subscription_data := get_user_subscription_with_limits(user_uuid);
  plan_limits := subscription_data->'plan'->'limits';
  
  -- Get limit for resource type
  limit_value := (plan_limits->>resource_type)::integer;
  
  -- If limit is -1, it's unlimited
  IF limit_value = -1 THEN
    RETURN true;
  END IF;
  
  -- Get current usage
  SELECT COALESCE(usage_count, 0) INTO current_usage
  FROM subscription_usage
  WHERE user_id = user_uuid
  AND resource_type = check_subscription_limit.resource_type
  AND period_start = date_trunc('month', now());
  
  -- Check if under limit
  RETURN current_usage < limit_value;
END;
$$;

-- Function to increment usage
CREATE OR REPLACE FUNCTION increment_usage(
  user_uuid uuid,
  resource_type text,
  increment_by integer DEFAULT 1
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO subscription_usage (user_id, resource_type, usage_count, period_start, period_end)
  VALUES (
    user_uuid,
    resource_type,
    increment_by,
    date_trunc('month', now()),
    date_trunc('month', now()) + interval '1 month'
  )
  ON CONFLICT (user_id, resource_type, period_start)
  DO UPDATE SET
    usage_count = subscription_usage.usage_count + increment_by,
    updated_at = now();
END;
$$;

-- Function to create default subscription for new users
CREATE OR REPLACE FUNCTION create_default_subscription()
RETURNS trigger AS $$
BEGIN
  INSERT INTO user_subscriptions (user_id, plan_id, status, current_period_end)
  VALUES (
    new.id,
    'free',
    'active',
    now() + interval '100 years' -- Free plan never expires
  );
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to create default subscription
CREATE TRIGGER create_user_subscription_trigger
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION create_default_subscription();

-- Indexes for performance
CREATE INDEX IF NOT EXISTS user_subscriptions_user_id_idx ON user_subscriptions(user_id);
CREATE INDEX IF NOT EXISTS user_subscriptions_status_idx ON user_subscriptions(status);
CREATE INDEX IF NOT EXISTS subscription_usage_user_resource_idx ON subscription_usage(user_id, resource_type);
CREATE INDEX IF NOT EXISTS subscription_usage_period_idx ON subscription_usage(period_start, period_end);
CREATE INDEX IF NOT EXISTS coupon_codes_code_idx ON coupon_codes(code);
CREATE INDEX IF NOT EXISTS coupon_usage_user_coupon_idx ON coupon_usage(user_id, coupon_id);

-- Triggers for updated_at
CREATE TRIGGER update_user_subscriptions_updated_at
  BEFORE UPDATE ON user_subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_subscription_usage_updated_at
  BEFORE UPDATE ON subscription_usage
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_coupon_codes_updated_at
  BEFORE UPDATE ON coupon_codes
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();