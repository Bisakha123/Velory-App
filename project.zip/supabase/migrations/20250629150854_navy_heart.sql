/*
  # Update Velory Plus subscription limits

  1. Changes
    - Update Plus plan limits for creative writing (10 entries)
    - Update Plus plan limits for media trackers (8 items total: 4 TV shows + 4 books)
    - Remove goals analytics from Plus (only available in Pro)
    - Keep custom trackers disabled for Plus
*/

-- Update the Plus plan limits
UPDATE subscription_plans 
SET limits = '{
   "daily_tasks": 30,
   "important_tasks": 20,
   "journal_entries": 25,
   "journal_words_per_entry": 1000,
   "thoughts_entries": 20,
   "thoughts_total_words": 500,
   "gratitude_days": 20,
   "gratitude_words_per_day": 300,
   "goals_entries": 10,
   "media_trackers": 8,
   "custom_trackers": false,
   "autobiography_cards": 10,
   "autobiography_items_per_card": 3,
   "autobiography_words_per_card": 100,
   "creative_writing": 10,
   "creative_background_images": 1,
   "profile_avatar": true,
   "analytics": true,
   "goals_analytics": false,
   "backups": false,
   "offline_writing": false,
   "motivational_popups": false,
   "mood_history_months": 12
 }'
WHERE id = 'plus';

-- Update the Pro plan to explicitly include goals analytics
UPDATE subscription_plans 
SET limits = '{
   "daily_tasks": -1,
   "important_tasks": -1,
   "journal_entries": -1,
   "journal_words_per_entry": -1,
   "thoughts_entries": -1,
   "thoughts_total_words": -1,
   "gratitude_days": -1,
   "gratitude_words_per_day": -1,
   "goals_entries": -1,
   "media_trackers": -1,
   "custom_trackers": true,
   "autobiography_cards": -1,
   "autobiography_items_per_card": -1,
   "autobiography_words_per_card": -1,
   "creative_writing": -1,
   "creative_background_images": -1,
   "profile_avatar": true,
   "analytics": true,
   "goals_analytics": true,
   "backups": true,
   "offline_writing": true,
   "motivational_popups": true,
   "mood_history_months": -1
 }'
WHERE id = 'pro';