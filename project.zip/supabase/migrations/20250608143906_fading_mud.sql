/*
  # Writeups Schema

  1. New Tables
    - `writeups`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `type` (text) - journal, creative, thoughts, gratitude, goals, autobiography
      - `title` (text)
      - `content` (text)
      - `tags` (text array)
      - `mood` (text) - for journal entries
      - `background_image` (text)
      - `metadata` (jsonb) - for flexible additional data
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `writeups` table
    - Add policies for users to manage their own writeups

  3. Indexes
    - Index on user_id and type for efficient filtering
    - Index on created_at for chronological ordering
*/

CREATE TABLE IF NOT EXISTS writeups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  type text NOT NULL CHECK (type IN ('journal', 'creative', 'thoughts', 'gratitude', 'goals', 'autobiography')),
  title text NOT NULL,
  content text DEFAULT '',
  tags text[] DEFAULT '{}',
  mood text CHECK (mood IN ('good', 'bad') OR mood IS NULL),
  background_image text,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE writeups ENABLE ROW LEVEL SECURITY;

-- Writeups policies
CREATE POLICY "Users can read own writeups"
  ON writeups
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own writeups"
  ON writeups
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own writeups"
  ON writeups
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own writeups"
  ON writeups
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS writeups_user_id_idx ON writeups(user_id);
CREATE INDEX IF NOT EXISTS writeups_type_idx ON writeups(type);
CREATE INDEX IF NOT EXISTS writeups_user_type_idx ON writeups(user_id, type);
CREATE INDEX IF NOT EXISTS writeups_created_at_idx ON writeups(created_at DESC);
CREATE INDEX IF NOT EXISTS writeups_tags_idx ON writeups USING gin(tags);

-- Trigger for writeups updated_at
CREATE TRIGGER update_writeups_updated_at
  BEFORE UPDATE ON writeups
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();