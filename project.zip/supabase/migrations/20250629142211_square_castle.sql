/*
  # Fix Coupon Codes RLS Policies

  1. Changes
    - Add proper RLS policies for coupon management
    - Allow authenticated users to insert/update/delete coupons (for admin functionality)
    - Keep public read access for coupon validation
    - Add service role policies for admin operations
*/

-- Drop existing restrictive policies
DROP POLICY IF EXISTS "Anyone can read active coupons" ON coupon_codes;

-- Create new comprehensive policies

-- Allow public read access for active coupons (for validation)
CREATE POLICY "Public can read active coupons"
  ON coupon_codes
  FOR SELECT
  TO public
  USING (is_active = true AND (valid_until IS NULL OR valid_until > now()));

-- Allow authenticated users to read all coupons (for admin interface)
CREATE POLICY "Authenticated users can read all coupons"
  ON coupon_codes
  FOR SELECT
  TO authenticated
  USING (true);

-- Allow authenticated users to insert coupons (for admin functionality)
CREATE POLICY "Authenticated users can insert coupons"
  ON coupon_codes
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Allow authenticated users to update coupons (for admin functionality)
CREATE POLICY "Authenticated users can update coupons"
  ON coupon_codes
  FOR UPDATE
  TO authenticated
  USING (true);

-- Allow authenticated users to delete coupons (for admin functionality)
CREATE POLICY "Authenticated users can delete coupons"
  ON coupon_codes
  FOR DELETE
  TO authenticated
  USING (true);

-- Grant necessary permissions to authenticated role
GRANT ALL ON coupon_codes TO authenticated;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO authenticated;